# Run Coverity Historical Action

This GitHub Action runs the Coverity Historical script for processing Coverity CIDs with defined parameters.

## Inputs

| **Input Name**           | **Description**                                                                         | **Required** | **Default**                    |
|--------------------------|-----------------------------------------------------------------------------------------|--------------|--------------------------------|
| `coverity_api_token`     | Coverity API token (used for authentication when accessing Coverity API)                | **Yes**      | N/A                            |
| `gh_api_token`           | GitHub token (used for authentication when accessing GitHub APIs)                       | **Yes**      | N/A                            |
| `team_name`              | Team name (template)                                                                    | **Yes**      | N/A                            |
| `organization`           | GitHub organization name                                                                | **No**       | N/A                            |
| `repository`             | GitHub repository name                                                                  | **No**       | N/A                            |
| `branch`                 | GitHub branch name                                                                      | **No**       | `main`                         |
| `cids`                   | List of CIDs (comma-separated integers and/or ranges, e.g., 1123, 1130-1135, 1147)      | **No**       | N/A                            |
| `from_date`              | Start date in ISO format (e.g. 2025-03-15T00:00:00Z)                                   | **No**       | N/A                            |
| `to_date`                | End date in ISO format (e.g. 2025-03-15T00:00:00Z)                                     | **No**       | N/A                            |
| `projects`               | Coverity projects (comma-separated)                                                     | **No**       | N/A                            |
| `trigger_event`          | Trigger event type                                                                      | **Yes**      | N/A                            |

## Usage

### Direct Action Usage

To use this action directly in your workflow, include it as a step:

```yaml
- name: Call Coverity Historical action
  uses: AMD-GH-Actions/ai-pr-platform-actions-lib/.github/actions/coverity_historical@main
  with:
    coverity_api_token: ${{ secrets.coverity_api_token }}
    gh_api_token: ${{ secrets.gh_api_token }}
    team_name: ${{ inputs.team_name }}
    organization: ${{ inputs.organization }}
    repository: ${{ inputs.repository }}
    branch: ${{ inputs.branch }}
    cids: ${{ inputs.cids }}
    from_date: ${{ inputs.from_date }}
    to_date: ${{ inputs.to_date }}
    projects: ${{ inputs.projects }}
    trigger_event: ${{ inputs.trigger_event }}
```

### Reusable Workflow Usage

To use the reusable workflow, call it from another workflow:

```yaml
- name: Call Coverity Historical workflow
  uses: AMD-GH-Actions/ai-pr-platform-actions-lib/.github/workflows/reusable_coverity_historical.yml@main
  with:
    team_name: ${{ inputs.team_name }}
    organization: ${{ inputs.organization }}
    repository: ${{ inputs.repository }}
    branch: ${{ inputs.branch }}
    cids: ${{ inputs.cids }}
    from_date: ${{ inputs.from_date }}
    to_date: ${{ inputs.to_date }}
    projects: ${{ inputs.projects }}
    trigger_event: ${{ inputs.trigger_event }}
  secrets:
    coverity_api_token: ${{ secrets.coverity_api_token }}
    gh_token: ${{ secrets.gh_token }}
```

## Date Range Behavior

- If `from_date` only is defined - CIDs will be filtered from defined date to now.
- If `to_date` only is defined - CIDs will be filtered from first record to defined date.
- If both `from_date` and `to_date` are defined - CIDs will be filtered from within defined range.
- If `cids` is defined - only defined CIDs will be processed.

## Description

The **Coverity Historical Action** performs the following steps:

1. **Code Checkout**: The action checks out the specified repository and branch into the `CoverityHistorical` directory using `actions/checkout@v4.1.1`.

2. **Execute Coverity Historical Script**: Runs the `coverity_historical.py` script using CID input parameters and team defined formatting template.

## Notes

- **Secret Management**: Ensure that `coverity_api_token` and `gh_api_token` are stored securely as secrets in your GitHub repository settings.
- **Python Environment**: The runner must have Python installed and accessible via the `python` command.
- **Date Validation**: The reusable workflow includes date validation to ensure date ranges don't exceed 15 days.

## Troubleshooting

- **Authentication Errors**: If you receive authentication errors, confirm that the `coverity_api_token` and `gh_api_token` are correct and have the necessary permissions.
- **Date Range Errors**: Ensure that start date is before end date and the range doesn't exceed 15 days when using the reusable workflow.

---
