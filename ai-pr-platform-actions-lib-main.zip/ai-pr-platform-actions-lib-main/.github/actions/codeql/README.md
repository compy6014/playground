# Run CodeQL Action

This GitHub Action runs the CodeQL script for processing GitHub alerts with defined parameters.

## Inputs

| **Input Name**      | **Description**                                                                         | **Required** | **Default**                    |
|---------------------|-----------------------------------------------------------------------------------------|--------------|--------------------------------|
| `codeql_api_token`  | CodeQL token (used for authentication when accessing CodeQL API)                        | **Yes**      | N/A                            |
| `gh_api_token`      | GitHub token (used for authentication when accessing GitHub APIs)                       | **Yes**      | N/A                            |
| `team_name`         | Team to process alerts for                                                              | **Yes**      | N/A                            |
| `alerts`            | (Optional) Comma-separated list of alert IDs to be processed by CodeQL                  | **No**       | N/A                            |
| `from_date`         | (Optional) Start date (ISO format) to search recorded alerts (e.g.2025-03-15T00:00:00Z) | **No**       | N/A                            |
| `to_date`           | (Optional) End date (ISO format) to search recorded alerts (e.g.2025-03-15T00:00:00Z)   | **No**       | N/A                            |

## Usage

To use this action in your workflow, include it as a step:

```yaml
- name: Call CodeQL action
  uses: AMD-GH-Actions/ai-pr-platform-actions-lib/.github/actions/codeql@main
  with:
    codeql_api_token: ${{ secrets.codeql_api_token }} #Actual secret name
    gh_api_token: ${{ secrets.gh_api_token }} #Actual secret name
    team_name: ${{ inputs.team_name }}
    alerts: ${{ inputs.alerts }}
    from_date: ${{ inputs.from_date }}
    to_date: ${{ inputs.to_date }}
```
- If from_date only is defined - alerts will be filtered from defined date to now. 
- If to_date only is defined - alerts will be filtered from first record to defined date. 
- If both from_date and to_date are defined - alerts will be filtered from within defined range. 
- If alerts is defined - only defined alerts will be processed.


## Description

The **CodeQL Action** performs the following steps:

1. **Code Checkout**: The action checks out the specified repository and branch into the `CodeQL` directory using `actions/checkout@v4.1.1`.

2. **Execute CodeQL Script**: Runs the `codeql.py` script using alert input parameters and team defined formatting template.


## Notes

- **Secret Management**: Ensure that `codeql_api_token` and `gh_api_token` are stored securely as secrets in your GitHub repository settings.
- **Python Environment**: The runner must have Python installed and accessible via the `python` command.

## Troubleshooting

- **Authentication Errors**: If you receive authentication errors, confirm that the `codeql_api_token` and `gh_api_token` are correct and have the necessary permissions.

---
