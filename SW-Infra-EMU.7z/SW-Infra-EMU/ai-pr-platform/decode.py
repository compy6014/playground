import base64


def decode_password(encoded_password):
    xor_constant = 0x53
    pwd_bytes = encoded_password.encode('utf-8')
    password_bytes = bytearray(base64.b64decode(pwd_bytes))
    for i in range(0, len(password_bytes)):
        password_bytes[i] ^= xor_constant
    decoded_password = password_bytes.decode('utf-8')
    return decoded_password


def encode_password(password):
    xor_constant = 0x53
    bytes = password.encode('utf-8')
    password_bytes = bytearray(bytes)
    for i in range(0, len(password_bytes)):
        password_bytes[i] ^= xor_constant
    encoded_password = base64.b64encode(password_bytes)
    return encoded_password


enpass = "OTcyOAR5djI3PDEkOgwk"
print(decode_password(enpass))