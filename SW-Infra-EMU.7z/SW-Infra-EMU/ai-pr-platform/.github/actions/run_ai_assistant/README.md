# Run AI Assistant Action

This GitHub Action runs the AI Assistant script with specified parameters, and can optionally check out a repository before executing the script.

## Inputs

| **Input Name**     | **Description**                                                                      | **Required** | **Default**                    |
|--------------------|--------------------------------------------------------------------------------------|--------------|--------------------------------|
| `assistant_type`   | Assistant type (specifies the type of AI assistant to run)                           | **Yes**      | N/A                            |
| `params`           | Parameters for the AI assistant script (as JSON string, including `llm_token`)       | **Yes**      | N/A                            |
| `ghe_token`        | GitHub token (used for authentication when accessing GitHub APIs)                    | **Yes**      | N/A                            |
| `api_token`        | API Token (secret) (passed as an environment variable `API_TOKEN` to the script)     | **Yes**      | N/A                            |
| `checkout_repo`    | GitHub repository to checkout (e.g., `owner/repo`)                                   | No           | `AMD-SW-Infra/ai-pr-platform`  |
| `checkout_branch`  | Branch to checkout                                                                   | No           | `main`                         |
| `checkout_code`    | Whether to checkout the code (`true`/`false`)                                        | No           | `true`                         |

## Usage

To use this action in your workflow, include it as a step:

```yaml
- name: Run AI Assistant
  uses: your-org/your-repo/.github/actions/run_ai_assistant@v1
  with:
    assistant_type: 'your_assistant_type'
    params: '{"llm_token": "your_llm_token", "other_param": "value"}'
    ghe_token: ${{ secrets.GHE_TOKEN }}
    api_token: ${{ secrets.API_TOKEN }}
    checkout_repo: 'AMD-SW-Infra/ai-pr-platform'   # Optional
    checkout_branch: 'your_branch'                 # Optional
    checkout_code: 'true'                          # Optional, defaults to 'true'
```

## Description

The **Run AI Assistant Action** performs the following steps:

1. **Conditional Code Checkout**: If `checkout_code` is set to `true`, the action checks out the specified repository and branch into the `ai-pr-platform` directory using `actions/checkout@v3`.

2. **Execute AI Assistant Script**: Runs the `run_ai_assistant.py` script with the provided `assistant_type` and `params`. If code was checked out, it changes the working directory to `ai-pr-platform` before execution.

## Inputs Explanation

- **assistant_type**: Specifies the type of AI assistant to run.
- **params**: A JSON string containing parameters for the AI assistant script. Must include `llm_token` and any other required parameters for the script.
- **ghe_token**: GitHub token used for authentication when accessing GitHub APIs.
- **api_token**: A secret API token required by the AI assistant script. This is passed as an environment variable.
- **checkout_repo**: The repository to clone. Defaults to `AMD-SW-Infra/ai-pr-platform` if not specified.
- **checkout_branch**: The branch of the repository to clone. Defaults to `main`.
- **checkout_code**: Determines whether the repository should be checked out. Set to `false` if the code is already present or not required.

## Environment Variables

- **API_TOKEN**: The `api_token` input is exported as an environment variable for use within the AI assistant script.

## Example

Here's an example of how to use the action in a job:

```yaml
jobs:
  run-ai-assistant:
    runs-on: ubuntu-latest
    steps:
      - name: Run AI Assistant
        uses: your-org/your-repo/.github/actions/run_ai_assistant@v1
        with:
          assistant_type: 'text-generation'
          params: '{"llm_token": "abcd1234", "prompt": "Hello, world!"}'
          ghe_token: ${{ secrets.GHE_TOKEN }}
          api_token: ${{ secrets.API_TOKEN }}
          checkout_repo: 'your_org/your_repo'        # Optional
          checkout_branch: 'develop'                 # Optional
          checkout_code: 'false'                     # Optional
```

## Notes

- **Secret Management**: Ensure that `ghe_token` and `api_token` are stored securely as secrets in your GitHub repository settings.
- **Python Environment**: The runner must have Python installed and accessible via the `python` command.
- **Script Location**: The `run_ai_assistant.py` script should be present in the root directory if `checkout_code` is `false`, or within the cloned repository if `checkout_code` is `true`.

## Troubleshooting

- **Missing Scripts**: If you encounter errors about missing scripts, verify that `checkout_code` is set correctly and that the script exists in the expected location.
- **Invalid JSON in Params**: Ensure that the `params` input is a valid JSON string. Incorrect JSON formatting can cause the script to fail.
- **Authentication Errors**: If you receive authentication errors, confirm that the `ghe_token` and `api_token` are correct and have the necessary permissions.

## License

This action is provided "as is" without warranty of any kind. Use at your own risk.

---

# Short Overview

The **Run AI Assistant Action** allows you to execute AI assistant scripts within your GitHub workflows by specifying an `assistant_type` and providing the necessary parameters and tokens. It handles optional code checkout and script execution, ensuring a streamlined integration of AI capabilities into your CI/CD pipelines.

---
