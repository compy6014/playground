from coverity import Coverity
from decode import decode_password
import pandas as pd

def load_coverity():
    print("Retrieving projects for AMD Classic")
    # amd_coverity = Coverity(
    #     host=config['secrets']['coverity']['amd_coverity_host'], 
    #     port=config['secrets']['coverity']['amd_coverity_port'], 
    #     ssl=False,
    #     username=config['secrets']['coverity']['amd_nt_userid'],
    #     password=decode_password(config['secrets']['coverity']["AMD_NT_PASSWORD"])
    # )
    amd_coverity = Coverity(
        host="coverity.amd.com", 
        port="80", 
        ssl=False,
        username="a1_code_gen",
        password="jdakX*%adobwi_w"
    )
    print("Projects retrieved successfully")

    return amd_coverity

def get_coverity_issues(projects, project_name: str, start_date):
    """
    Retrieve all Coverity issues (CIDs) for a given project.
    """
    # Find the project by name
    project = next((p for p in projects if p.project_name == project_name), None)
    if not project:
        print(f"Project '{project_name}' not found.")
        return []

    # Prepare to fetch issues
    issues = []
    page_size = 50
    start_index = 0
    # for stream_name in project.stream_names:
    try:
        projectId = amd_coverity.defect_service_client.client.factory.create('projectIdDataObj')
        projectId.name = project.project_name

        response = amd_coverity.defect_service_client.client.service.getMergedDefectsForProjectScope(
            projectId=projectId,
            filterSpec={
                "impactNameList": "High",
                # dates in format "2013-03-18T12:42:19.384-07:00",
                "firstDetectedStartDate": start_date.strftime("%Y-%m-%dT00:00:00.000-07:00"),
            },
            pageSpec={
                "pageSize": page_size,
                "sortAscending": False,
            }
        )

        if not hasattr(response, "mergedDefects") or not response.mergedDefects:
            print("No issues found for the selected criteria.")
            return []


        for defect in response.mergedDefects:
            issues.append({
                "id": defect.cid,
                "type": defect.displayType,
                "impact": defect.displayImpact,
                "checkerName": defect.checkerName,
                "filePathname": defect.filePathname,
                "created": defect.firstDetected
            })             

        start_index += len(response)

        # Remove duplicates based on 'id'
        issues = {issue['id']: issue for issue in issues}.values()
        # Convert to list and sort by creation date
        issues = list(issues)
        # Convert 'created' to datetime for sorting
        for issue in issues:
            issue['created'] = pd.to_datetime(issue['created']).date()

        # Sort issues by creation date
        issues.sort(key=lambda x: x['created'], reverse=False)

        cache_key = f'coverity_issues_{project_name}'
        
        print(f"Coverity issues retrieved successfully for {project_name}")

    except Exception as e:
        print(f"Error retrieving issues : {e}")

    return issues


amd_coverity = load_coverity()
projects = amd_coverity.get_projects()
project_names_list = [project.project_name for project in projects]
selected_project = "KMD"
start_date = pd.Timestamp.now().date() - pd.Timedelta(days=365)
issues = get_coverity_issues(projects, selected_project, start_date)
print(issues)