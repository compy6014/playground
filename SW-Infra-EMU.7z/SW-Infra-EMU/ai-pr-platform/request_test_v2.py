import requests
import json

def github_api_request(url, token, use_quotes=False):
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}"
    }
    
    # The main difference here is whether we're passing the URL directly or as a string
    # In Python requests, this doesn't actually matter in the way it does for curl
    # But we'll demonstrate both approaches for comparison
    
    if use_quotes:
        # This simulates the first curl command with quoted URL
        response = requests.get(url, headers=headers)
    else:
        # This simulates the second curl command without quotes
        response = requests.get(url, headers=headers)
    
    return response

def main():
    # Replace with your actual GitHub token
    token = "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"
    
    # The URL for both requests
    url = "https://api.github.com/repos/AMD-Radeon-Driver/drivers/code-scanning/alerts"
    
    # Query parameters
    params = {
        "ref": "amd/stg/kmd",
        "per_page": 100,
        "state": "open",
        "sort": "created",
        "order": "desc",
        "page": 3
    }
    
    # Construct the full URL with parameters
    full_url = url + "?" + "&".join([f"{k}={v}" for k, v in params.items()])
    
    print("Testing with 'quoted' URL:")
    response1 = github_api_request(full_url, token, use_quotes=True)
    print(f"Status Code: {response1.status_code}")
    print(f"Response Length: {len(response1.text)}")
    #print("First 100 chars of response:", response1.text[:100] if response1.text else "Empty response")
    #print(response1.text)
    
    print("\nTesting with unquoted URL:")
    response2 = github_api_request(full_url, token, use_quotes=False)
    print(f"Status Code: {response2.status_code}")
    print(f"Response Length: {len(response2.text)}")
    #print("First 100 chars of response:", response2.text[:100] if response2.text else "Empty response")
    #print(response2)
    
    # Compare the responses
    print("\nResponses are equal:", response1.text == response2.text)
    
    # If you want to see the full responses as JSON
    try:
        print("\nFirst response (quoted URL):")
        print(json.dumps(response1.json(), indent=2)[:5000] + "...")  # Show first 500 chars
        
    #     print("\nSecond response (unquoted URL):")
    #     print(json.dumps(response2.json(), indent=2)[:500] + "...")  # Show first 500 chars
    except json.JSONDecodeError:
        print("Responses are not valid JSON")

if __name__ == "__main__":
    main()
