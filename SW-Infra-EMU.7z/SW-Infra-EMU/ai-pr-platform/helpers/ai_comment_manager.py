from helpers.utils import remove_line_numbers
import logging

class AICommentManager:
    """Helper class for handling comment preparation."""

    def __init__(self):
        pass

    def prepare_suggestion_comment(
        self, 
        header: str, 
        code_suggestion: str, 
        explanation: str, 
        commitable_suggestion: bool = True
    ) -> str:
        """
        Prepare the suggestion review comment.
    
        :param header: The header text for the comment.
        :param code_suggestion: The code suggestion.
        :param explanation: The explanation for the suggestion.
        :param commitable_suggestion: If True, wraps code in ```suggestion\n```, else in ```\n```.
        :return: Formatted review comment as a string.
        """
        code_suggestion = remove_line_numbers(code_suggestion)
        if commitable_suggestion:
            code_block = f"```suggestion\n{code_suggestion}\n```"
        else:
            code_block = f"```\n{code_suggestion}\n```"
        
        comment = (
            f"### {header}\n"
            "<details><summary>Click for details</summary>\n\n"
            f"{code_block}\n\n"
            f"**Code Fix Explanation:** {explanation}</details>"
        )
        
        return comment
    
    def prepare_general_suggestion_comment(
        self,
        header: str,
        original_source_code: str,
        code_suggestion: str,
        explanation: str
    ) -> str:
        """
        Prepare a general suggestion review comment.
    
        :param header: Header text for the comment.
        :param original_source_code: The original source code snippet.
        :param code_suggestion: The suggested code modification.
        :param explanation: Explanation for the suggestion.
        :return: Formatted review comment as a string.
        """
        comment = (
            f"### {header}\n\n"
            "After reviewing the comment and the corresponding file, the AI has generated a suggested code fix addressing the review comment. Below, you'll find this suggested fix, which you can copy or directly commit to the code using the link provided in the review comment. For your reference, we've also included the original code block\n\n"
            "<details><summary>Click for details</summary>\n\n"
            "**Original source code:**\n"
            f"```\n{original_source_code}\n```\n"
            "**Code Fix Suggestion**\n"
            f"```\n{code_suggestion}\n```\n\n"
            f"**Code Fix Explanation:** {explanation}</details>"
        )
        return comment
    
    def create_comment_body_for_position(self, comment, commit_id, file_path, line_position, position) -> dict:
        """Creates a comment body for position-based comments.

        Args:
            comment: The comment object containing the text and filename.
            start_line (int): The starting line number of the comment.
            end_line (int): The ending line number of the comment.
            position (str): The side of the diff ("LEFT" or "RIGHT").

        Returns:
            dict: A dictionary containing the necessary information for post_review_comment.
        """
        start_line, end_line = line_position
        comment_body = {
            "body": comment,
            'commit_id': commit_id,
            'path': file_path,
            'line': start_line,
            'side': position
        }
        if end_line > start_line:
            comment_body['start_line'] = start_line
            comment_body['line'] = end_line

        return comment_body
                                   
    def is_within_scope(self, provided_lines: list, scope_lines: list) -> bool:
        """
        Check if the provided line numbers [first, last] are within the comment scope lines [first, last].

        :param provided_lines: List containing the first and last line numbers of the provided lines.
        :param scope_lines: List containing the first and last line numbers of the scope lines.
        :return: True if the provided lines are within the scope lines, False otherwise.
        """
        provided_first, provided_last = provided_lines
        scope_first, scope_last = scope_lines

        return scope_first <= provided_first <= provided_last <= scope_last
