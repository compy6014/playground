import requests
import base64
import re
from helpers.logger import get_module_logger
from requests.exceptions import HTTPError
from typing import List, Dict, Tuple, Optional

class GitHubHelper:
    """Helper class for interacting with the GitHub API."""

    BASE_URL = 'https://github.amd.com/api/v3'
    ACCEPT_HEADER = 'application/vnd.github.v3+json'

    def __init__(self, ghe_token: str, base_url: str = BASE_URL):
        self.ghe_token = ghe_token
        self.base_url = base_url
        self.logger = get_module_logger('GitHubHelper')

        self.diff_header = {
            "Accept": "application/vnd.github.diff",
            "Authorization": f"Bearer {ghe_token}"
        }

        self.comment_header = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {ghe_token}"
        }

    def _get_headers(self, raw: bool = False) -> Dict[str, str]:
        accept = self.ACCEPT_HEADER + ('.raw' if raw else '')
        return {
            'Authorization': f'Bearer {self.ghe_token}',
            'Accept': accept
        }

    def get_commit_by_id(self, owner: str, repo: str, commit_id: str) -> Dict:
        """Fetches a single commit based on the commit ID."""
        url = f"{self.base_url}/repos/{owner}/{repo}/commits/{commit_id}"
        self.logger.info(f"Fetching commit {commit_id} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"Error occurred while fetching commit {commit_id}: {str(e)}")
        return {}

    def get_new_commits(self, owner: str, repo: str, branch: str, since: Optional[str] = None) -> List[Dict]:
        """Fetches new commits for the specified branch in a repository."""
        url = f"{self.base_url}/repos/{owner}/{repo}/commits?sha={branch}&per_page=100"
        if since:
            url += f"&since={since}"
        self.logger.info(f"Fetching commits for branch {branch} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"Error occurred while fetching commits for branch {branch}: {str(e)}")
        return []

    def get_latest_commit_sha(self, owner: str, repo: str, branch_name: str) -> str:
        """Fetches the latest commit SHA for a given branch."""
        url = f"{self.base_url}/repos/{owner}/{repo}/branches/{branch_name}"
        self.logger.info(f"Fetching latest commit SHA for repo: {repo}, branch: {branch_name}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()['commit']['sha']
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_file_content(self, owner: str, repo: str, branch_sha: str, file_path: str) -> str:
        """Fetches the content of a file from a repository."""
        url = f"{self.base_url}/repos/{owner}/{repo}/contents/{file_path}?ref={branch_sha}"
        self.logger.info(f"Fetching file content for repo: {repo}, branch_sha: {branch_sha}, file_path: {file_path}")
        try:
            response = requests.get(url, headers=self._get_headers(raw=True))
            response.raise_for_status()
            file_info = response.json()
            return base64.b64decode(file_info['content']).decode()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_diff(self, owner: str, repo: str, commit_id: str) -> str:
        """Fetch the diff for a specific commit."""
        url = f"{self.base_url}/repos/{owner}/{repo}/commits/{commit_id}"
        self.logger.info(f"Fetching diff for commit {commit_id} from {url}")
        try:
            response = requests.get(url, headers=self.diff_header)
            response.raise_for_status()
            return response.text
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def create_branch(self, owner: str, repo: str, base_sha: str, new_branch: str) -> None:
        """Create a new branch in the repository."""
        url = f"{self.base_url}/repos/{owner}/{repo}/git/refs"
        new_ref = {"ref": f"refs/heads/{new_branch}", "sha": base_sha}
        try:
            response = requests.post(url, json=new_ref, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Branch '{new_branch}' created successfully.")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_file_sha(self, owner: str, repo: str, branch: str, file_path: str) -> Optional[str]:
        """Retrieve the SHA of a file in the specified branch."""
        url = f"{self.base_url}/repos/{owner}/{repo}/contents/{file_path}?ref={branch}"
        try:
            response = requests.get(url, headers=self._get_headers())
            if response.status_code == 200:
                return response.json()['sha']
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def commit_file(self, owner: str, repo: str, branch: str, file_path: str, file_content: str, commit_message: str) -> None:
        """Commit a file to the specified branch."""
        url = f"{self.base_url}/repos/{owner}/{repo}/contents/{file_path}"
        file_sha = self.get_file_sha(owner, repo, branch, file_path)
        encoded_content = base64.b64encode(file_content.encode()).decode()
        commit_data = {"message": commit_message, "content": encoded_content, "branch": branch}
        if file_sha:
            commit_data["sha"] = file_sha
        try:
            response = requests.put(url, json=commit_data, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"File '{file_path}' committed successfully.")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def create_pull_request(self, owner: str, repo: str, base: str, head: str, title: str, body: str, isDraft: bool) -> str:
        """Create a new pull request."""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls"
        pr_data = {"title": title, "body": body, "head": head, "base": base, "draft": isDraft}
        try:
            response = requests.post(url, json=pr_data, headers=self._get_headers())
            response.raise_for_status()
            pr_url = response.json()['html_url']
            self.logger.info(f"Pull request created successfully. PR url: {pr_url}")
            return pr_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def add_labels_to_pr(self, pr_url: str, labels: List[str]) -> None:
        """Add labels to a pull request."""
        owner, repo, pr_number = self.extract_pr_details(pr_url)
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{pr_number}/labels"
        try:
            response = requests.post(url, json={"labels": labels}, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Labels added successfully to PR #{pr_number}")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def add_reviewers_to_pr(self, pr_url: str, reviewers: List[str]) -> None:
        """Add reviewers to a pull request."""
        if not reviewers:
            self.logger.info(f"No reviewers to add for PR {pr_url}")
            return
        owner, repo, pr_number = self.extract_pr_details(pr_url)
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/requested_reviewers"
        try:
            response = requests.post(url, json={"reviewers": reviewers}, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Reviewers added successfully to PR #{pr_number}")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def extract_pr_details(self, pr_url: str) -> Tuple[str, str, str]:
        """Extracts owner, repo, and PR number from a PR URL."""
        patterns = {
            "internal": re.compile(r"https://github\.amd\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)"),
            "external": re.compile(r"https://github\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)")
        }
        for pattern in patterns.values():
            match = pattern.match(pr_url)
            if match:
                return match.groups()
        raise ValueError(f"Invalid PR URL: {pr_url}")

    # Comment related methods

    def get_pr_review_comment(self, owner: str, repo: str, pr_number: str, comment_id: str) -> Dict:
        """Fetches the review comment from a pull request based on comment ID."""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/comments/{comment_id}"
        self.logger.info(f"Fetching review comment {comment_id} from PR #{pr_number} at {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_reply_comment(self, owner: str, repo: str, pr_number: str, comment_id: str, body: str) -> str:
        """Posts a reply comment to a review comment on a pull request."""
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/comments/{comment_id}/replies"
        comment_data = {"body": body}
        try:
            response = requests.post(url, json=comment_data, headers=self._get_headers())
            response.raise_for_status()
            comment_url = response.json().get('html_url')
            self.logger.info(f"Reply comment posted successfully on PR #{pr_number}. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_pr_review_comment(self, owner: str, repo: str, pr_number: str, comment_body: Dict) -> str:
        """Post a positional review comment on a pull request diff using the provided comment_body.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param pr_number: Pull request number.
        :param comment_body: Dictionary containing the comment data.
        :return: URL of the posted comment.
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/comments"
        self.logger.info(f"Posting review comment to PR #{pr_number} at {url}")
        self.logger.debug(f"Comment body to post as review comment: {comment_body}")
        try:
            response = requests.post(url, json=comment_body, headers=self.comment_header)
            #self.logger.info(f"Response: {response.json()}")
            response.raise_for_status()
            comment_url = response.json().get('html_url', '')
            self.logger.info(f"Review comment posted successfully. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_commit_comment(self, owner: str, repo: str, commit_id: str, comment_body: Dict) -> str:
        """Post a comment on a commit using the provided comment_body.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param commit_id: Commit SHA.
        :param comment_body: Dictionary containing the comment data.
        :return: URL of the posted comment.
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/commits/{commit_id}/comments"
        self.logger.info(f"Posting comment to commit {commit_id} at {url}")
        self.logger.debug(f"Comment body to post as commit comment: {comment_body}")
        try:
            response = requests.post(url, json=comment_body, headers=self.comment_header)
            response.raise_for_status()
            comment_url = response.json().get('html_url', '')
            self.logger.info(f"Commit comment posted successfully. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    # Utility methods

    def is_line_range_in_hunk(self, hunk_header, line_range):
        """
        Function to check if given line numbers [first_line, last_line] are within
        the diff hunk on the right side (new file), based on the hunk header.

        Parameters:
            hunk_header (str): The diff hunk header line (e.g., "@@ -13987,17 +14040,30 @@").
            line_range (list[int]): A list containing [first_line, last_line].

        Returns:
            bool: True if the line range is within the hunk, False otherwise.
        """
        first_line, last_line = line_range

        try:
            first_line = int(first_line)
            last_line = int(last_line)
        except ValueError:
            print(f"Invalid line numbers provided: {line_range}")
            return False

        if first_line > last_line:
            first_line, last_line = last_line, first_line

        # Regular expression to match hunk headers
        hunk_header_regex = re.compile(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@')

        hunk_header_match = hunk_header_regex.match(hunk_header.strip())
        if not hunk_header_match:
            print(f"Invalid hunk header: {hunk_header}")
            return False

        # Extract starting line number and line count from hunk header (right side)
        start_line = int(hunk_header_match.group(1))
        length_str = hunk_header_match.group(2)
        if length_str is not None:
            length = int(length_str)
        else:
            length = 1  # Default length if not specified

        end_line = start_line + length - 1

        # Check if the given line range overlaps with the hunk range
        if last_line < start_line:
            return False
        elif first_line > end_line:
            return False
        else:
            return True

    #def is_line_range_in_added_lines(self, diff_hunk: str, line_range: tuple[int, int]) -> bool:
    #    """
    #    Check if the given line range [start_line, end_line] is entirely within
    #    a continuous block of added lines in the diff hunk.
#
    #    Args:
    #        diff_hunk (str): The diff hunk string.
    #        line_range (tuple[int, int]): A tuple containing start and end line numbers.
#
    #    Returns:
    #        bool: True if the entire line_range is within an added block in the diff hunk.
    #    """
    #    # Pre-compiled regex pattern for performance
    #    hunk_header_pattern = re.compile(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@')
#
    #    # Parse the diff hunk header
    #    header_match = hunk_header_pattern.match(diff_hunk)
    #    if not header_match:
    #        self.logger.warning("Invalid diff hunk format.")
    #        return False
#
    #    # Extract starting line number for the new file
    #    start_line_new = int(header_match.group(1))
#
    #    # Initialize variables
    #    current_line_num = start_line_new
    #    added_ranges = []
    #    in_added_block = False
    #    start_added_line = None
#
    #    # Split the diff hunk into lines, skipping the header
    #    lines = diff_hunk.split('\n')[1:]
#
    #    # Process each line in the diff hunk
    #    for line in lines:
    #        if line.startswith('+') and not line.startswith('+++'):
    #            # Start of an added block
    #            if not in_added_block:
    #                in_added_block = True
    #                start_added_line = current_line_num
    #            current_line_num += 1
    #        elif line.startswith('-') and not line.startswith('---'):
    #            # Removed line; do not increment line number of new file
    #            pass
    #        else:
    #            # Context line
    #            if in_added_block:
    #                # End of the current added block
    #                end_added_line = current_line_num - 1
    #                added_ranges.append((start_added_line, end_added_line))
    #                in_added_block = False
    #                start_added_line = None
    #            current_line_num += 1
#
    #    # Check if we ended within an added block
    #    if in_added_block:
    #        end_added_line = current_line_num - 1
    #        added_ranges.append((start_added_line, end_added_line))
#
    #    # Check if the line_range is entirely within any of the added ranges
    #    start_line, end_line = line_range
    #    for added_start, added_end in added_ranges:
    #        if start_line >= added_start and end_line <= added_end:
    #            return True
#
    #    return False

    def is_line_range_in_added_lines(self, diff_hunk: str, line_range: tuple[int, int]) -> bool:
        """
        Check if the given line range [start_line, end_line] is entirely within
        added lines in the diff hunk. Handles new file additions and insertions
        where the original line count is zero.

        Args:
            diff_hunk (str): The diff hunk string.
            line_range (tuple[int, int]): A tuple containing start and end line numbers.

        Returns:
            bool: True if the entire line_range is within added lines in the diff hunk.
        """
        hunk_header_pattern = re.compile(r'^@@ -(\d+),?(\d+)? \+(\d+),?(\d+)? @@')

        lines = diff_hunk.rstrip('\n').split('\n')
        if not lines:
            self.logger.info("Empty diff hunk.")
            return False

        header_match = hunk_header_pattern.match(lines[0])
        if not header_match:
            self.logger.info("Invalid diff hunk format.")
            return False

        # Extracting line numbers and counts from the hunk header
        original_line_start = int(header_match.group(1))
        original_line_count = header_match.group(2)
        new_line_start = int(header_match.group(3))
        new_line_count = header_match.group(4)

        # If counts are not specified, default to 1
        original_line_count = int(original_line_count) if original_line_count else 1
        new_line_count = int(new_line_count) if new_line_count else 1

        start_line, end_line = line_range
        if end_line < start_line:
            self.logger.info("End line is smaller than start line.")
            return False

        # Check for insertion (original_line_count == 0)
        if original_line_count == 0 and new_line_count > 0:

            # Calculate the end line number in the new file
            new_file_end_line = new_line_start + new_line_count - 1

            # If both start_line and end_line are within the range of added lines
            if new_line_start <= start_line <= end_line <= new_file_end_line:
                self.logger.info("Line range is within the inserted lines.")
                return True
            else:
                self.logger.info("Line range is outside the inserted lines.")
                return False

        # Check for deletion (new_line_count == 0)
        if new_line_count == 0 and original_line_count > 0:
            # Deletions don't add lines to the new file, so the line range cannot be within added lines
            return False

        # Existing logic for modifications
        new_line_num = new_line_start - 1  # Initialize to one less for correct incrementing

        total_lines_in_range = end_line - start_line + 1
        lines_in_range_checked = 0

        # Process each line in the hunk
        for index, line in enumerate(lines[1:], start=1):
            if line.startswith('+++') or line.startswith('---') or line.startswith('@@'):
                continue

            if line.startswith('+') and not line.startswith('+++'):
                # Added line: line is present in new file
                new_line_num += 1
                if start_line <= new_line_num <= end_line:
                    lines_in_range_checked += 1
                    if lines_in_range_checked == total_lines_in_range:
                        return True
                elif new_line_num > end_line:
                    break
            elif line.startswith('-') and not line.startswith('---'):
                # Removed line: line is from original file
                pass
            else:
                # Context line
                new_line_num += 1
                if start_line <= new_line_num <= end_line:
                    return False
                elif new_line_num > end_line:
                    break

        # If the loop ends and we have not checked all lines in range, return False
        if lines_in_range_checked == total_lines_in_range:
            self.logger.info("All lines in the range were added lines.")
            return True
        else:
            self.logger.info("Did not find all lines in the range or encountered non-added lines.")
            return False
