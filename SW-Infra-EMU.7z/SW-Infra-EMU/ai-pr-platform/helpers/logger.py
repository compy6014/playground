import logging
import os
LOG_LEVEL = logging.DEBUG

def get_module_logger(module_name:str) -> logging.Logger:
    """Configures and returns a logger for the specified module.

    This function creates a logger with a specified name (typically the module name)
    and sets up both console and file logging. The log messages include log level,
    module name, timestamp, and the message.

    Args:
        module_name (str): The name of the logger, usually the module name.

    Returns:
        logging.Logger: A configured logger instance with both console and file handlers.
    """
    output_location = 'debug/global.log'

    logger = logging.getLogger(module_name)
    logger.propagate = False

    handler_stream = logging.StreamHandler()
    os.makedirs(os.path.dirname(output_location), exist_ok=True)
    handler_file = logging.FileHandler(output_location, mode='a')

    formatter = logging.Formatter(
            '[%(asctime)s][%(name)s][%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    handler_stream.setFormatter(formatter)
    handler_file.setFormatter(formatter)

    logger.addHandler(handler_stream)
    logger.addHandler(handler_file)
    logger.setLevel(LOG_LEVEL)
    return logger
