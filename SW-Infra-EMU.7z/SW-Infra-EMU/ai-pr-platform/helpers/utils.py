# helpers/utils.py
import os
import re

def save_to_file(content: str, file_path: str) -> None:
    """Save content to a file at the specified file path."""
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def extract_pr_info(pr_url: str) -> dict:
    """Extract owner, repo, and PR number from a PR URL."""
    pattern = r'https://github\.amd\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)/pull/(?P<pr_number>\d+)'
    match = re.match(pattern, pr_url)
    if match:
        return match.groupdict()
    else:
        return {"error": "URL does not match the expected pattern"}
    
def get_suggestion_line_numbers(suggestion: str) -> list[int]:
    """Return the first and last line number from a code suggestion."""
    line_numbers = re.findall(r'^\s*(\d+)', suggestion, re.MULTILINE)
    if line_numbers:
        first_line = int(line_numbers[0])
        last_line = int(line_numbers[-1])
        return [first_line, last_line]
    else:
        return []
    

def remove_line_numbers(suggestion: str, offset: int = -1) -> str:
    """
    Remove line numbers and leading spaces from a code suggestion while adjusting indentation based on offset.

    Args:
        suggestion (str): The code suggestion string containing line numbers.
        offset (int, optional): The number of spaces to adjust indentation.
                                Negative values remove spaces, positive values add spaces.
                                Defaults to -1.

    Returns:
        str: The code suggestion with line numbers and leading spaces removed, and indentation adjusted.
    """
    lines = suggestion.split('\n')
    processed_lines = []
    for line in lines:
        # Match leading spaces, digits, spaces, rest of line
        match = re.match(r'^(\s*)(\d+)(\s+)(.*)', line)
        if match:
            # Spaces after the line number
            spaces_after_line_number = match.group(3)
            code = match.group(4)
            # Reconstruct the line without leading spaces and line number
            processed_line = spaces_after_line_number + code
        else:
            processed_line = line

        # Adjust indentation based on offset
        if offset != 0:
            if offset > 0:
                # Add spaces to the beginning
                processed_line = (' ' * offset) + processed_line
            else:
                # Remove spaces from the beginning, up to the absolute value of offset
                remove_spaces = -offset
                # Count leading spaces
                leading_spaces_match = re.match(r'^ *', processed_line)
                leading_spaces_count = len(leading_spaces_match.group(0))
                # Determine how many spaces to remove
                spaces_to_remove = min(remove_spaces, leading_spaces_count)
                # Remove the spaces
                processed_line = processed_line[spaces_to_remove:]
        processed_lines.append(processed_line)
    return '\n'.join(processed_lines)
