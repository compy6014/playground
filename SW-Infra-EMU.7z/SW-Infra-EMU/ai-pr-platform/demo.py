from scripts.workflow_executor import WorkflowExecutor


context = {
    #"alert_numbers": [1440, 1435, 1441],
    "from_date": "2024-05-09T00:00:00Z",
    "to_date": "2024-05-11T23:59:59Z",
    "team_name": "demo"
}
executor = WorkflowExecutor(workflow_name="demo_codeql", team_name="demo")
executor.execute(context)
