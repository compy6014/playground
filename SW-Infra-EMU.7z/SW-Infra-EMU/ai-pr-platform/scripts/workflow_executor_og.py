import os
from scripts.base_api import BaseAPI
from scripts.specific_api import SpecificAPI
from scripts.template_formatter import Formatter
from utils.config_loader import ConfigLoader
from utils.utility_functions import FunctionLibrary
from enum import Enum  
from typing import Dict, List, Optional, Set  
  
class HookType(Enum):  
    """Defines where custom code should be inserted"""  
    BEFORE = "before"  
    AFTER = "after"  
    OVERRIDE = "override"  
  
class WorkflowPhase:  
    """Handles phase validation and relationships"""  
    def __init__(self, phases: List[str]):  
        self._phases = set(phases)  
  
    def is_valid_phase(self, phase: str) -> bool:  
        """Check if a phase is defined in the workflow"""  
        return phase in self._phases  
  
    def get_all_phases(self) -> Set[str]:  
        """Get all defined phases"""  
        return self._phases.copy()  
  
class WorkflowExecutor:  
    PHASE_START_MARKER = "#[PHASE:"  
    PHASE_END_MARKER = "#[END_PHASE]"  
  
    def __init__(self, workflow_name: str, team_name: str):  
        self.workflow_name = workflow_name  
        self.team_name = team_name  
        self.workflow_template = ConfigLoader.load_workflow_template(workflow_name, team_name)  
          
        # Initialize phases  
        workflow_phases = self.workflow_template.get("phases", [])  
        if not workflow_phases:  
            raise ValueError(f"No phases defined for workflow '{workflow_name}'")  
        self.phases = WorkflowPhase(workflow_phases)  
          
        self.execution_context = {}  
        self.after_hooks_positions = {}  
  
    def load_workflow_script(self, script_path: str) -> str:  
        """Loads workflow script from file"""  
        if not os.path.exists(script_path):  
            raise FileNotFoundError(f"Workflow script '{script_path}' not found")  
          
        with open(script_path) as f:  
            return f.read()  
  
    def validate_phase_name(self, phase_name: str) -> None:  
        """Validate that a phase is defined in the workflow"""  
        if not self.phases.is_valid_phase(phase_name):  
            raise ValueError(  
                f"Phase '{phase_name}' is not defined in workflow '{self.workflow_name}'. "  
                f"Available phases: {sorted(self.phases.get_all_phases())}"  
            )  
  
    def get_phase_indentation(self, lines: List[str], phase_start_index: int) -> str:  
        """Get the indentation level for a phase"""  
        # Look at the next non-empty line after phase marker  
        i = phase_start_index + 1  
        while i < len(lines) and not lines[i].strip():  
            i += 1  
        if i < len(lines):  
            return lines[i][:len(lines[i]) - len(lines[i].lstrip())]  
        return ""  
  
    def prepare_workflow_code(self, script_code: str) -> str:  
        """Prepare workflow code by inserting custom hooks with proper indentation"""  
        lines = script_code.splitlines()  
        modified_lines = []  
        i = 0  
          
        while i < len(lines):  
            line = lines[i]  
            modified_lines.append(line)  
              
            if line.strip().startswith(self.PHASE_START_MARKER):  
                # Extract phase name  
                phase_name = line.strip()[len(self.PHASE_START_MARKER):].strip(']} ')  
                self.validate_phase_name(phase_name)  
                base_indent = self.get_phase_indentation(lines, i)  
                  
                # Get team customizations for this phase  
                team_specific = self.workflow_template.get(self.team_name, {})  
                if isinstance(team_specific, dict):  
                    phase_config = team_specific.get(phase_name, {})  
                      
                    if isinstance(phase_config, dict):  
                        if phase_config.get(HookType.OVERRIDE.value):  
                            # Skip until END_PHASE marker for override  
                            while i < len(lines) and not lines[i].strip().startswith(self.PHASE_END_MARKER):  
                                i += 1  
                            if i < len(lines):  
                                modified_lines = modified_lines[:-1]  # Remove the PHASE marker  
                                # Add override code with proper indentation  
                                for hook in phase_config[HookType.OVERRIDE.value]:  
                                    modified_lines.append(f"{base_indent}{hook}")  
                        else:  
                            # Add before hooks  
                            if phase_config.get(HookType.BEFORE.value):  
                                for hook in phase_config[HookType.BEFORE.value]:  
                                    modified_lines.append(f"{base_indent}{hook}")  
                              
                            # Find the end of the phase to add after hooks  
                            phase_end_index = i + 1  
                            while phase_end_index < len(lines) and not lines[phase_end_index].strip().startswith(self.PHASE_END_MARKER):  
                                phase_end_index += 1  
                              
                            if phase_config.get(HookType.AFTER.value):  
                                self.after_hooks_positions[phase_end_index] = [  
                                    f"{base_indent}{hook}"   
                                    for hook in phase_config[HookType.AFTER.value]  
                                ]  
                    elif isinstance(phase_config, list):  # Legacy format  
                        # Add as before hooks  
                        for hook in phase_config:  
                            modified_lines.append(f"{base_indent}{hook}")  
              
            elif i in self.after_hooks_positions:  
                # Add after hooks before the END_PHASE marker  
                modified_lines.extend(self.after_hooks_positions[i])  
              
            i += 1  
          
        return '\n'.join(modified_lines)  
  
    def execute(self, context: dict) -> dict:  
        """Executes workflow from loaded template with provided context"""  
        try:  
            # Initialize execution context  
            self.execution_context = {'__builtins__': __builtins__}  
              
            # Add a custom globals function that returns our execution context  
            def get_globals():  
                return self.execution_context  
            self.execution_context['globals'] = get_globals  
              
            # Add provided context  
            self.execution_context.update(context)  
  
            # Execute imports  
            imports = self.workflow_template.get("imports", [])  
            import_block = "\n".join(imports)  
            exec(import_block, self.execution_context, self.execution_context)  
  
            # Load and prepare the workflow script  
            general = self.workflow_template.get("general", "")  
            if isinstance(general, str) and general.startswith("external:"):  
                script_path = general.replace("external:", "").strip()  
                original_script = self.load_workflow_script(script_path)  
                  
                # Reset after hooks positions  
                self.after_hooks_positions = {}  
                  
                # Prepare the complete workflow code  
                modified_script = self.prepare_workflow_code(original_script)  
                exec(modified_script, self.execution_context, self.execution_context)  
  
            return self.execution_context  
  
        except Exception as e:  
            raise RuntimeError(f"Workflow execution failed: {str(e)}") from e  
