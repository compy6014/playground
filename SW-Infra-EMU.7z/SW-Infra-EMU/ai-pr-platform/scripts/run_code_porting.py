import argparse
import sys
from assistants.create_pr.code_porting import CodePortingAssistant

def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description='Run CodePorting Assistant')
    parser.add_argument('-g', '--ghe_token', required=True, help='GHE token')
    parser.add_argument('-c', '--code_porting_token', required=True, help='CodePorting API token')
    parser.add_argument('-f', '--from_date', type=str, default='2024-09-10T00:00:00Z', help='Date to filter commits')
    parser.add_argument('-i', '--commit_id', type=str, help="Commit ID for manual run; won't fetch commits for target branches")
    parser.add_argument('-d', '--draft_pr', action='store_true', help='Indicates whether the pull request is a draft')
    parser.add_argument('-ll', '--label_list', type=str, default='', help='Comma-separated list of labels to add to the PR')
    parser.add_argument('-rl', '--reviewer_list', type=str, default='', help='Comma-separated list of reviewers to add to the PR')
    parser.add_argument('-t', '--ticket_id', type=str, default="", help='Jira ticket ID')
    parser.add_argument('-b', '--target_branch', type=str, required=True, help='Target branch for the PR')
    parser.add_argument('-s', '--source_branch', type=str, required=True, help='Source branch for the PR')
    parser.add_argument('-o', '--owner', type=str, required=True, help='Repository owner')
    parser.add_argument('-r', '--repo', type=str, required=True, help='Repository name')
    parser.add_argument('-out', '--output_file', type=str, default='codeporting_result.html', help='Output HTML file to save the results')
    return parser.parse_args()

def main():
    """Main function to run the CodePorting Assistant."""
    try:
        args = parse_arguments()
        assistant = CodePortingAssistant(
            ghe_token=args.ghe_token,
            code_porting_token=args.code_porting_token,
            from_date=args.from_date,
            commit_id=args.commit_id,
            draft_pr=args.draft_pr,
            label_list=args.label_list,
            reviewer_list=args.reviewer_list,
            ticket_id=args.ticket_id,
            target_branch=args.target_branch,
            source_branch=args.source_branch,
            owner=args.owner,
            repo=args.repo,
            output_file=args.output_file,
        )

        print("CodePorting Assistant started...")
        assistant.assist()
        print("CodePorting Assistant completed successfully.")
        sys.exit(0)  # Exit with status code 0 for success
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(-1)

if __name__ == "__main__":
    main()
