# run_ai_assistant.py

import argparse
import json
import sys
import os
from typing import Any, Dict, Optional

from assistants.ai_assistant import AIAssistant
from assistants.create_pr.code_porting import CodePortingAssistant
from assistants.create_pr.codeql import CodeQLAssistant
from assistants.post_comment.coverity import CoverityAssistant
from assistants.post_comment.human_review_fix import AIReviewCommentFixAssistant

def create_ai_assistant(assistant_type: str, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False) -> AIAssistant:
    assistant_classes = {
        'CodeQL': CodeQLAssistant,
        'Coverity': CoverityAssistant,
        'CodePorting': CodePortingAssistant,
        'AIReviewCommentFix': AIReviewCommentFixAssistant
    }
    assistant_class = assistant_classes.get(assistant_type)
    if assistant_class is None:
        raise ValueError(f"Unknown AIAssistantType: {assistant_type}")

    return assistant_class(ghe_token, json_in_params, use_dev)

def main():
    parser = argparse.ArgumentParser(description='AI Assistant Entry Point')
    parser.add_argument('assistant_type', choices=['CodeQL', 'Coverity', 'CodePorting', 'AIReviewCommentFix'],
                        help='Type of AI Assistant to create')
    parser.add_argument('-t', '--ghe_token', required=True, help='GitHub Enterprise authentication token')
    parser.add_argument('-p', '--params', type=str, default='{}', help='JSON input parameters as a string')
    parser.add_argument('-d', '--use_dev', action='store_true', help='Use the development environment')
    args = parser.parse_args()

    try:
        json_in_params = json.loads(args.params)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON parameters: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        ai_assistant = create_ai_assistant(args.assistant_type, args.ghe_token, json_in_params, args.use_dev)
        result = ai_assistant.perform_task()
    except Exception as e:
        print(f"An error occurred: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
