import os
import sys
import json
import argparse

# Add the parent directory to sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
sys.path.insert(0, parent_dir)

from run_ai_assistant import create_ai_assistant

def run_assistant_from_script(assistant_type, ghe_token, params, use_dev):
    try:
        json_in_params = json.loads(params)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON parameters: {e}")
        return

    try:
        ai_assistant = create_ai_assistant(assistant_type, ghe_token, json_in_params, use_dev)
        result = ai_assistant.perform_task()
    except Exception as e:
        print(f"An error occurred: {e}")
        return

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run AI Assistant Script')
    parser.add_argument('--ghe_token', required=True, help='GitHub Enterprise token')
    args = parser.parse_args()

    assistant_type = 'AIReviewCommentFix'
    params = {
        "pr_url": "https://github.amd.com/AMD-Radeon-Driver/drivers/pull/108495",
        "comment_id": "866246",
        "llm_token": "8808a937be11417e981281ca50b70e9e",
        "api_token": "K3bSE70SXhRiO-dW7DbkRAMqwWsxSTlNMR_OtIt2pOw"
    }
    use_dev = False

    run_assistant_from_script(assistant_type, args.ghe_token, json.dumps(params), use_dev)
