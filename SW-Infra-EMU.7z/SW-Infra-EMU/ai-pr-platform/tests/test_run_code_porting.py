import os
import sys
import json
import argparse

# Add the parent directory to sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
sys.path.insert(0, parent_dir)

from run_ai_assistant import create_ai_assistant

def run_assistant_from_script(assistant_type, ghe_token, params):
    try:
        json_in_params = json.loads(params)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON parameters: {e}")
        return

    try:
        ai_assistant = create_ai_assistant(assistant_type, ghe_token, json_in_params)
        result = ai_assistant.perform_task()
        print(result)
    except Exception as e:
        print(f"An error occurred: {e}")
        return

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run Code Porting Assistant Script')
    parser.add_argument('--ghe_token', required=True, help='GitHub Enterprise token')
    args = parser.parse_args()

    assistant_type = 'CodePorting'  # Example assistant type
    params = {
        "owner": "AMD-Radeon-Driver",
        "repo": "drivers",
        # "source_branch": "your_source_branch",  # Replace with your actual source branch
        "target_branch": "amd/stg/kmd",
        "ticket_id": "SWDEV-494219",
        "from_date": "2021-01-01",
        "commit_id": "911df89",
        "draft_pr": True,
        "label_list": "codeporting",
        "output_file": "codeporting_result.html"
    }

    run_assistant_from_script(assistant_type, args.ghe_token, json.dumps(params))
