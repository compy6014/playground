import argparse  
from scripts.workflow_executor import WorkflowExecutor  
from utils.utility_functions import FunctionLibrary
  

def parse_arguments():  
    parser = argparse.ArgumentParser(description='Execute workflow with specified parameters')  
      
    parser.add_argument('--commit-id', type=str, help='Commit ID')
    parser.add_argument('--from-date', type=str, help='From date in ISO format (e.g., 2025-03-15T00:00:00Z)')
    parser.add_argument('--source-branch', type=str, help='Source branch for CodePorting - overrides config')
    parser.add_argument('--target-branch', type=str, help='Target branch for CodePorting - overrides config')
    parser.add_argument('--repo-url', type=str, help='Full repo URL for instance, organization and repository extraction')
  
    return parser.parse_args()  
  
def main():  
    args = parse_arguments()  

    team_names = FunctionLibrary.get_team_names_from_github_paths(args.target_branch)
    target_branches = [branch.strip() for branch in args.target_branch.split(',')]
    for i, github_path in enumerate(target_branches):
        team_name = team_names[i]
        context = {
            "commit_id": args.commit_id,  
            "from_date": args.from_date,  
            "team_name": team_name,
            "source_branch": args.source_branch,
            "target_branch": github_path,
            "repo_url": args.repo_url
        }  

        executor = WorkflowExecutor(workflow_name="testing_codeporting", team_name=team_name)  
        executor.execute(context)  
  
if __name__ == "__main__":  
    main() 