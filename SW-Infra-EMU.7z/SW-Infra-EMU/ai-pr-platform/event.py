GREEN_EVENT_TAGS = [
    "cond_true",
    "cond_false",
    "loop",
    "loop_begin",
    "loop_end",
    "continue",
    "else_branch",
    "if_fallthrough"
    "if_end",
    "break",
    "switch",
    "switch_case",
]

class Event:
    def __init__(self, tag: str, description: str, file_path: str, line_number: int, is_main: bool):
        self.tag = tag
        self.description = description
        self.file_path = file_path
        self.line_number = line_number
        self.is_main = is_main

    def __repr__(self) -> str:
        return f"Event(tag={self.tag}, description={self.description}, file_path={self.file_path}, line_number={self.line_number}, is_main={self.is_main})"
