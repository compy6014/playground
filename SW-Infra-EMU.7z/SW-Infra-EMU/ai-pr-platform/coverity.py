import base64
import datetime
import zlib

from suds.client import Client
from suds.wsse import Security, UsernameToken

from event import Event, GREEN_EVENT_TAGS


class WebServiceClient:
    def __init__(self, webservice_type: str, host: str, port: str, ssl: bool, username: str, password: str) -> None:
        url_prefix = 'https://' if ssl else 'http://'
        url = url_prefix + host + ':' + port
        
        if webservice_type == 'configuration':
            self.wsdlFile = url + '/ws/v9/configurationservice?wsdl'
        elif webservice_type == 'defect':
            self.wsdlFile = url + '/ws/v9/defectservice?wsdl'
        else:
            raise "unknown web service type: " + webservice_type

        self.client = Client(self.wsdlFile)
        self.security = Security()
        self.token = UsernameToken(username, password)
        self.security.tokens.append(self.token)
        self.client.set_options(wsse=self.security)

    def get_wsdl(self) -> None:
        print(self.client)


class DefectServiceClient(WebServiceClient):
    def __init__(self, host: str, port: str, ssl: bool, username: str, password: str) -> None:
        super().__init__('defect', host, port, ssl, username, password)


class ConfigServiceClient(WebServiceClient):
    def __init__(self, host: str, port: str, ssl: bool, username: str, password: str) -> None:
        super().__init__('configuration', host, port, ssl, username, password)


class Project:
    def __init__(self, stream_names: list[str], project_key: str, project_name: str) -> None:
        self.stream_names = stream_names
        self.project_key = project_key
        self.project_name = project_name


class Coverity:
    def __init__(self, host: str, port: str, ssl: bool, username: str, password: str) -> None:
        self.defect_service_client = DefectServiceClient(host, port, ssl, username, password)
        self.config_service_client = ConfigServiceClient(host, port, ssl, username, password)
        self.projects = self.get_projects()


    def get_projects(self) -> list[Project]:
        """Retrieve all projects from the Coverity server"""
        project_filter = self.config_service_client.client.factory.create('projectFilterSpecDataObj')
        project_filter.namePattern='*'
        retrieved_projects = self.config_service_client.client.service.getProjects(project_filter)
        
        projects = []
        for retrieved_project in retrieved_projects:
            # Consider only projects with streams (we need stream name to get defects)
            if 'streams' in retrieved_project:
                project = Project(
                    stream_names=[stream.id.name for stream in retrieved_project.streams],
                    project_key=retrieved_project.projectKey,
                    project_name=str(retrieved_project.id.name)
                )
                projects.append(project)
        
        return projects


    def get_project_for_cid(self, cid: int, projects: list[Project], logger) -> Project:
        """Get the project that the CID belongs to"""
        
        latest_defect_created = datetime.datetime(1, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)

        for project in projects:
            stream_defects = self.get_stream_defects(cid, project.stream_names)
            
            if stream_defects:
                defect_created = stream_defects[0].history[0].dateCreated
                logger.info(f"Defect created for CID {cid} in project {project.project_name} is {defect_created}")

                try:
                    defect_created = defect_created.astimezone(datetime.timezone.utc)
                except Exception as e:
                    # If the date is not in UTC, it will raise an exception
                    # Return the first matching project
                    logger.error(f"Error while converting date to UTC: {e}. Project for CID {cid} is {project.project_name}")
                    return project

                # AECG Coverity Admin: give priority to rubik_adv_java. Else, consider the project with latest defect created.
                if "rubik_adv_java" in project.stream_names: 
                    project_for_cid = project
                    break
                elif defect_created > latest_defect_created:
                    project_for_cid = project
                    latest_defect_created = defect_created

        logger.info(f"Project for CID {cid} is {project_for_cid.project_name}")
        return project_for_cid


    def get_red_events_and_loc(self, cid: int, stream_names: list[str]) -> tuple[list[Event], list[str]]:
        """Get events and lines of code"""
        stream_defects = self.get_stream_defects(cid, stream_names)
        events = stream_defects[0].defectInstances[0].events

        red_events = []
        for event in events:
            # Record the red events
            if event.eventTag not in GREEN_EVENT_TAGS:
                red_event = Event(
                    tag=event.eventTag, 
                    description=str(event.eventDescription), 
                    file_path=str(event.fileId.filePathname),
                    line_number=event.lineNumber,
                    is_main=event.main
                    )
                red_events.append(red_event)


            # Obtain the lines of code
            if event.main:
                streamIdDO = self.defect_service_client.client.factory.create('streamIdDataObj')
                streamIdDO.name= stream_defects[0].streamId.name

                fileIdDO = self.defect_service_client.client.factory.create('fileIdDataObj')
                fileIdDO.filePathname = event.fileId.filePathname
                fileIdDO.contentsMD5 = event.fileId.contentsMD5

                file_contents = self.defect_service_client.client.service.getFileContents(streamIdDO, fileIdDO)
                decompressed_content=zlib.decompress(bytes(bytearray(base64.b64decode(file_contents['contents']))), 15+32)

                code_string  = decompressed_content.decode('utf-8')
                lines_of_code = ["index_0_placeholder"] + code_string.splitlines() # Add a placeholder to make the index match the actual line numbers
                for i in range(1, len(lines_of_code)):
                    lines_of_code[i] = f"{i}\t {lines_of_code[i]}"

        return red_events, lines_of_code


    def get_stream_defects(self, cid: int, stream_names: list[str]):
        mergedDefectIdDO = self.defect_service_client.client.factory.create('mergedDefectIdDataObj')
        mergedDefectIdDO.cid = cid

        streamIdListDO = []
        for stream_name in stream_names:
            streamIdDO = self.defect_service_client.client.factory.create('streamIdDataObj')
            streamIdDO.name = stream_name
            streamIdListDO.append(streamIdDO)

        filterSpecDO = self.defect_service_client.client.factory.create('streamDefectFilterSpecDataObj')
        filterSpecDO.includeDefectInstances = True
        filterSpecDO.includeHistory = True
        filterSpecDO.streamIdList = streamIdListDO

        stream_defects = self.defect_service_client.client.service.getStreamDefects(mergedDefectIdDO, filterSpecDO)

        return stream_defects
