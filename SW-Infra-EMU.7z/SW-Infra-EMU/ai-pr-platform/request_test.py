import requests
import json
from urllib.parse import quote

def test_github_api(token):
    # Base URL and headers
    base_url = "https://api.github.com/repos/AMD-Radeon-Driver/drivers/code-scanning/alerts"
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}"
    }
    
    # Test 1: URL with parameters as in the first curl command (quoted URL)
    url1 = f"{base_url}?ref=amd%2Fstg%2Fkmd&per_page=5&state=open&sort=created&order=desc&page=3"
    #url1 = f"'{base_url}?ref=amd%2Fstg%2Fkmd&per_page=5&state=open&sort=created&order=desc&page=3'"
    print(f"Making request to: {url1}")
    response1 = requests.get(url1, headers=headers)
    
    # Test 2: URL with parameters as in the second curl command (unquoted URL)
    # In curl, unquoted URLs can sometimes be interpreted differently, especially with special characters
    # Let's try with a raw, unencoded URL to simulate potential differences
    url2 = f"{base_url}?ref=amd/stg/kmd&per_page=5&state=open&sort=created&order=desc&page=3"
    print(f"Making request to: {url2}")
    response2 = requests.get(url2, headers=headers)
    
    # Print results
    print("\nQuoted URL Response:")
    print(f"Status Code: {response1.status_code}")
    print(f"Response Length: {len(response1.text)}")
    
    print("\nUnquoted URL Response:")
    print(f"Status Code: {response2.status_code}")
    print(f"Response Length: {len(response2.text)}")
    
    # Compare the responses
    print("\nResponses are equal:", response1.text == response2.text)
    
    # Output small sample of each response for comparison
    try:
        json1 = response1.json()
        json2 = response2.json()
        
        print("\nFirst few items from quoted URL response:")
        print(json.dumps(json1[:2] if isinstance(json1, list) and len(json1) > 0 else json1, indent=2))
        
        print("\nFirst few items from unquoted URL response:")
        print(json.dumps(json2[:2] if isinstance(json2, list) and len(json2) > 0 else json2, indent=2))
    except Exception as e:
        print(f"Error parsing JSON: {e}")
        print("Raw response samples:")
        print("Quoted URL:", response1.text[:200])
        print("Unquoted URL:", response2.text[:200])

if __name__ == "__main__":
    token = "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"  # Replace with your actual token
    test_github_api(token)



