import os
from config_loader import ConfigLoader
from base_api import BaseAPI
from specific_api import SpecificAPI
from template_formatter import Formatter
from utility_functions import FunctionLibrary


class WorkflowExecutor:
    def __init__(self, workflow_name, team_name):
        """Initializes workflow executor fro a specific team"""
        self.workflow_name = workflow_name
        self.team_name = team_name
        self.workflow_template = ConfigLoader.load_workflow_template(workflow_name, team_name)


    def load_workflow_script(self, script_path):
        if not os.path.exists(script_path):
            raise FileNotFoundError(f"Workflow script '{script_path}' not found")
        
        with open(script_path) as f:
            return f.read()


    def execute(self, context):
        """Executes workflow from loaded template with provided in context"""
        execution_context = {**context} # User defined context
        
        # Extract imports form workflow template
        imports = self.workflow_template.get("imports", [])
        for import_statement in imports:
            exec(import_statement, execution_context)

        # Execute general workflow commands
        general = self.workflow_template.get("general", [])
        # for step in general:
        if isinstance(general, str) and general.startswith("external:"):
            script_path = general.replace("external:", "").strip()
            script_code = self.load_workflow_script(script_path)
            exec(script_code, execution_context)
        
        # Execute team specific workflow commands if available
        team_specific = self.workflow_template.get(self.team_name, [])
        for step in team_specific:
            exec(step, execution_context)