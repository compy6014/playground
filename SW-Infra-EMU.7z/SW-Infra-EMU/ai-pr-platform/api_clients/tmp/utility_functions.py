import json
import base64
import re
import logging
import os
import subprocess
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class FunctionLibrary:
    LOG_LEVEL = logging.DEBUG
    @staticmethod
    def base64_encode(data):
        if not isinstance(data, str):
            raise ValueError("Data must be a string")
        return base64.b64encode(data.encode()).decode()
    
    @staticmethod
    def base64_decode(data):
        if not isinstance(data, str):
            raise ValueError("Data must be string")
        return base64.b64decode(data).decode()
    
    @classmethod
    def _apply_diff(self, original_lines: list[str], diff_lines: list[str]) -> tuple[list[str], int, list[int], list[tuple[int, str]]]:
        """Helper method to apply a diff to lines."""
        diff_pattern = re.compile(r'@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@')
        new_lines = []
        old_line_idx = 0  # Index in original_lines
        diff_line_idx = 0  # Index in diff_lines

        added_lines = []
        removed_lines = []
        start_line = 0

        while diff_line_idx < len(diff_lines):
            line = diff_lines[diff_line_idx]
            diff_line_idx += 1

            match = diff_pattern.match(line)
            if match:
                # Parse hunk header
                old_line_no = int(match.group(1)) - 1  # zero-based index
                new_line_no = int(match.group(2)) - 1
                start_line = new_line_no
                hunk_added_lines = []
                hunk_removed_lines = []

                # Add unchanged lines before the hunk
                while old_line_idx < old_line_no:
                    new_lines.append(original_lines[old_line_idx])
                    old_line_idx += 1

                # Process hunk lines
                while diff_line_idx < len(diff_lines):
                    diff_line = diff_lines[diff_line_idx]
                    if diff_line.startswith('@@'):
                        # Next hunk header, break to outer loop
                        break
                    diff_line_idx += 1

                    if diff_line.startswith(' '):
                        # Context line, copy from original
                        if old_line_idx < len(original_lines):
                            new_lines.append(original_lines[old_line_idx])
                            old_line_idx += 1
                        else:
                            # Original file ended unexpectedly
                            pass
                    elif diff_line.startswith('-') and not diff_line.startswith('---'):
                        # Line removed from original
                        if old_line_idx < len(original_lines):
                            # Record removed line number (1-based)
                            hunk_removed_lines.append(old_line_idx + 1)
                            old_line_idx += 1
                        else:
                            # Original file ended unexpectedly
                            pass
                    elif diff_line.startswith('+') and not diff_line.startswith('+++'):
                        # Line added to new file
                        new_lines.append(diff_line[1:] + '\n')
                        # Record added line position (1-based)
                        hunk_added_lines.append((len(new_lines), diff_line[1:] + '\n'))
                    else:
                        # Should not happen
                        pass

                # Extend overall added and removed lines
                added_lines.extend(hunk_added_lines)
                removed_lines.extend(hunk_removed_lines)
            else:
                # Non-hunk line (should be headers), skip
                pass

        # Append any remaining lines from the original file
        while old_line_idx < len(original_lines):
            new_lines.append(original_lines[old_line_idx])
            old_line_idx += 1

        return new_lines, start_line, removed_lines, added_lines

    @classmethod
    def apply_diff_to_file(self, original_file: str, file_name: str, code_diff: str) -> str:
        """Apply a diff to a specific file."""
        lines = original_file.splitlines(keepends=True)
        file_pattern = re.compile(r'^--- a/(\S+)')
        code_diff = code_diff.replace('\n\n', '\n \n') # Fix for empty lines in diff
        diff_lines = code_diff.split('\n')

        apply_changes = False

        for i, line in enumerate(diff_lines):
            file_match = file_pattern.match(line)
            if file_match:
                current_file = file_match.group(1)
                apply_changes = (current_file == file_name)
                continue

            if apply_changes:
                updated_lines, start_line, removed_lines, added_lines = self._apply_diff(lines, diff_lines[i:])
                print(f"Applied diff to file: {file_name}, start_line: {start_line}, removed_lines: {removed_lines}, added_lines: {added_lines}")
                return ''.join(updated_lines)

        return original_file
    
    
    @classmethod
    def get_rule_based_commit_text(self, rule_id: str, default_commit_header: str, default_commit_description: str) -> tuple[str, str]:
        """
        Returns a commit header and description based on a given rule_id.
        """
        # Map specific rule IDs or groups of IDs to a header and description
        rule_map = {
            ("cpp/comparison-with-wider-type",): (
                "Do not compare integers with different widths",
                "Avoid comparing integers with different widths"
            ),
            ("cpp/missing-null-test", "cpp/inconsistent-null-check", "cpp/inconsistent-nullness-testing"): (
                "Handle potential null pointer",
                "Make sure to check for null"
            ),
            ("cpp/memory-never-freed", "cpp/memory-may-not-be-freed"): (
                "Free memory allocation",
                "Free memory to avoid memory leak"
            )
        }

        for group, (header_text, description_text) in rule_map.items():
            if rule_id in group:
                return header_text, description_text

        # Fallback if no match
        return default_commit_header, f"Fix for: {default_commit_description}"
    
    def get_last_modifier(repo_path, file_path, line_number):
        result = subprocess.run(['git', '-C', repo_path, 'blame', '-L', f'{line_number},{line_number}', '--', file_path], capture_output=True, text=True)
        return result.stdout.strip()

    @staticmethod
    def get_module_logger(module_name:str) -> logging.Logger:
        """Configures and returns a logger for the specified module.
        This function creates a logger with a specified name (typically the module name)
        and sets up both console and file logging. The log messages include log level,
        module name, timestamp, and the message.
        Args:
            module_name (str): The name of the logger, usually the module name.
        Returns:
            logging.Logger: A configured logger instance with both console and file handlers.
        """
        output_location = 'debug/global.log'

        logger = logging.getLogger(module_name)
        logger.propagate = False

        handler_stream = logging.StreamHandler()
        os.makedirs(os.path.dirname(output_location), exist_ok=True)
        handler_file = logging.FileHandler(output_location, mode='a')

        formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        handler_stream.setFormatter(formatter)
        handler_file.setFormatter(formatter)

        logger.addHandler(handler_stream)
        logger.addHandler(handler_file)
        logger.setLevel(FunctionLibrary.LOG_LEVEL)
        
        return logger
    
    @staticmethod
    def send_email(smtp_server, smtp_port, from_email, subject, body, to_email):
        # Create MIMEText object to represent email
        msg = MIMEMultipart()
        msg['From'] = from_email
        msg['To'] = to_email
        msg['Subject'] = subject

        # Attach email body to MIMEText object
        msg.attach(MIMEText(body, 'html'))

        try:
            # Create SMTP session and send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.send_message(msg)
            server.quit()
            print("Email sent successfully")
        except Exception as e:
            print(f"Failed to send email: {e}")
        

    def get_last_modifier(file_path: str, line_number: int, repo_path: str = ".") -> str:
        """Returns user who last modified the given line in file"""
        try:
            result = subprocess.run(
                ["git", "-C", repo_path, "blame", "-L", f"{line_number},{line_number}", "--line-porcelain", file_path],
                capture_output=True,
                text=True,
                check=True
            )
            output = result.stdout.splitlines()
            for line in output:
                if line.startswith("author "):
                    return line[len("author "):]
            raise ValueError("Author not found in blame output")
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Git blame failed: {e.stderr}")
        except Exception as e:
            raise RuntimeError(f"Failed to get last modifier: {e}")
        

    
    def blame_for_lines(blame_ranges, start_line, end_line):
        reviewers = set()
        for r in blame_ranges:
            if r["endingLine"] >= start_line and r["startingLine"] <= end_line:
                user = r["commit"]["author"].get("user")
                if user and user.get("login"):
                    reviewers.add(user["login"])
        return ", ".join(sorted(reviewers))
