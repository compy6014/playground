import json
from config_loader import ConfigLoader
from urllib.parse import urlencode
from datetime import datetime, timezone


class SpecificAPI(BaseAPI):
    def __init__(self, api_name, environment=None):
        super().__init__(api_name, environment)


    def _extract_value(self, data, filter_path):  
        """Extracts value from a nested structure using dot-separated keys."""  
        if not data or not filter_path:  
            return None  
  
        keys = filter_path.split(".")  
        value = data  
  
        for i, key in enumerate(keys):  
            if value is None:  
                return None  
  
            if isinstance(value, dict):  
                value = value.get(key)  
            elif isinstance(value, list):  
                # Handle list indexing  
                if key.isdigit():  
                    index = int(key)  
                    if index < len(value):  
                        value = value[index]  
                    else:  
                        return None  
                else:  
                    # For lists, try to extract the specified field from all items  
                    remaining_path = ".".join(keys[i:])  
                    extracted_values = []  
                    for item in value:  
                        extracted = self._extract_value(item, remaining_path)  
                        if extracted is not None:  
                            if isinstance(extracted, list):  
                                extracted_values.extend(extracted)  
                            else:  
                                extracted_values.append(extracted)  
                    return extracted_values if extracted_values else None  
            else:  
                return None  
  
        return value  
  

    def _filter_response(self, response, response_filter):  
        """Filters response based on response_filter in request_templates.json"""  
        if not response_filter:  
            return response  
  
        if not isinstance(response_filter, list):  
            response_filter = [response_filter]  # Ensure it’s a list  
  
        extracted_values = []  
  
        def extract_from_item(item):  
            """Extracts all filter values from a single response item (dict or list)"""  
            item_values = []  
  
            for filter_path in response_filter:  
                value = self._extract_value(item, filter_path)  
              
                if value is not None:  # Accept both True and False, avoid None  
                    item_values.append(value)  
  
            # If values are found, return them; otherwise return an appropriate type  
            if len(item_values) == 0:  
                return None if isinstance(item, dict) else []  # Respect the type of item  
          
            return item_values if len(item_values) > 1 else item_values[0]  # Return a singular value or list  
  
        # Process the response based on its type  
        if isinstance(response, list):  
            extracted_values = [extract_from_item(item) for item in response if item]  
        else:  
            extracted_values = [extract_from_item(response)]  # Wrap in a list if not a list  
  
        # Handle what to return based on the collected results  
        if not extracted_values:  
            return None if isinstance(response, dict) else []  # Return None or empty list as needed  
  
        return extracted_values if len(extracted_values) > 1 else extracted_values[0]  # Return a single item or list  
    

    def _apply_post_filters(self, response, post_filters, params):  
        """Applies multiple post processing filters in order, with support for nested structures"""  
        if not post_filters:  
            return response  
      
        filtered_response = response  
  
        def find_and_filter_ranges(data, field_path, expected_value, match_mode):  
            """Filter nested data structures based on field values"""  
            if isinstance(data, dict):  
                result = {}  
                for key, value in data.items():  
                    # Get the field value using the field_path  
                    if isinstance(value, (dict, list)):  
                        field_value = self._extract_value(data, field_path)  
                        if field_value is not None:  
                            if not isinstance(field_value, list):  
                                field_value = [field_value]  
                      
                            # Check if any value matches the expected value  
                            should_include = False  
                            if match_mode:  
                                should_include = any(val == expected_value[0] for val in field_value)  
                            else:  
                                should_include = all(val != expected_value[0] for val in field_value)  
                      
                            if should_include:  
                                result[key] = find_and_filter_ranges(value, field_path, expected_value, match_mode)  
                        else:  
                            filtered_value = find_and_filter_ranges(value, field_path, expected_value, match_mode)  
                            if filtered_value:  # Only include non-empty results  
                                result[key] = filtered_value  
                    else:  
                        result[key] = value  
                return result if result else None  
  
            elif isinstance(data, list):  
                filtered_list = []  
                for item in data:  
                    field_value = self._extract_value(item, field_path)  
                    if field_value is not None:  
                        if not isinstance(field_value, list):  
                            field_value = [field_value]  
                  
                        # Check if any value matches the expected value  
                        should_include = False  
                        if match_mode:  
                            should_include = any(val == expected_value[0] for val in field_value)  
                        else:  
                            should_include = all(val != expected_value[0] for val in field_value)  
                  
                        if should_include:  
                            filtered_list.append(item)  
                    else:  
                        filtered_item = find_and_filter_ranges(item, field_path, expected_value, match_mode)  
                        if filtered_item:  # Only include non-empty results  
                            filtered_list.append(filtered_item)  
                return filtered_list if filtered_list else None  
  
            return data  
  
        def find_and_filter_dates(data, field_path, from_date, to_date):  
            """Find the ranges list and filter it by date"""  
            if isinstance(data, dict):  
                result = {}  
                for key, value in data.items():  
                    # Get the date value using the field_path  
                    if isinstance(value, (dict, list)):  
                        date_value = self._extract_value(data, field_path)  
                        if date_value:  
                            try:  
                                item_date = datetime.strptime(date_value, "%Y-%m-%dT%H:%M:%SZ")  
                          
                                # Check if the date is within range  
                                if from_date:  
                                    parsed_from_date = datetime.strptime(from_date, "%Y-%m-%dT%H:%M:%SZ")  
                                    if item_date < parsed_from_date:  
                                        continue  
                          
                                if to_date:  
                                    parsed_to_date = datetime.strptime(to_date, "%Y-%m-%dT%H:%M:%SZ")  
                                    if item_date > parsed_to_date:  
                                        continue  
                          
                                result[key] = find_and_filter_dates(value, field_path, from_date, to_date)  
                            except (ValueError, TypeError):  
                                result[key] = find_and_filter_dates(value, field_path, from_date, to_date)  
                        else:  
                            result[key] = find_and_filter_dates(value, field_path, from_date, to_date)  
                    else:  
                        result[key] = value  
                return result  
            elif isinstance(data, list):  
                filtered_list = []  
                for item in data:  
                    date_value = self._extract_value(item, field_path)  
                    if date_value:  
                        try:  
                            item_date = datetime.strptime(date_value, "%Y-%m-%dT%H:%M:%SZ")  
                      
                            # Check if the date is within range  
                            should_include = True  
                            if from_date:  
                                parsed_from_date = datetime.strptime(from_date, "%Y-%m-%dT%H:%M:%SZ")  
                                if item_date < parsed_from_date:  
                                    should_include = False  
                      
                            if to_date:  
                                parsed_to_date = datetime.strptime(to_date, "%Y-%m-%dT%H:%M:%SZ")  
                                if item_date > parsed_to_date:  
                                    should_include = False  
                      
                            if should_include:  
                                filtered_list.append(item)  
                        except (ValueError, TypeError):  
                            filtered_item = find_and_filter_dates(item, field_path, from_date, to_date)  
                            if filtered_item:  
                                filtered_list.append(filtered_item)  
                    else:  
                        filtered_item = find_and_filter_dates(item, field_path, from_date, to_date)  
                        if filtered_item:  
                            filtered_list.append(filtered_item)  
                return filtered_list  
            return data  


        for post_filter in post_filters:  
            filter_type = post_filter.get("type")  
            field_path = post_filter.get("field")  
  
            if filter_type == "value_match":  
                expected_value = params.get(post_filter.get("param_name"))  
                match_mode = params.get("match_mode", True)  
  
                if expected_value is not None:  
                    if not isinstance(expected_value, list):  
                        expected_value = [expected_value]  
  
                    filtered_response = find_and_filter_ranges(  
                        filtered_response,   
                        field_path,   
                        expected_value,   
                        match_mode  
                    )  
  
            elif filter_type == "date_range":  
                from_date = params.get("from_date")  
                to_date = params.get("to_date")  
                if not to_date:  
                    to_date = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")  
  
                if field_path and (from_date or to_date):  
                    filtered_response = find_and_filter_dates(  
                        filtered_response,  
                        field_path,  
                        from_date,  
                        to_date  
                    )  
  
        return filtered_response  


    def make_request(self, request_name, **params):  
        """Uses predefined request templates to execute API calls"""  
      
        template = ConfigLoader.load_request_template(self.api_name, request_name)  
        method = template.get("method", "GET").upper()  # Defaults to GET if method not defined
        header_type = template.get("header_type", None)  
  
        # Extract variable types from template (if defined)  
        variable_types = template.get("variable_types", {})  
  
        # Format variables based on template, making sure lists are handled correctly  
        formatted_variables = {}  
        for key, value in template.get("variables", {}).items():  
            if isinstance(params.get(key), list):  
                formatted_variables[key] = ",".join(map(str, params[key]))  # Convert list to comma-separated string  
            else:  
                formatted_variables[key] = str(value).format(**params)  
      
        # Cast variables to specified types  
        final_variables = {  
            key: int(value) if variable_types.get(key) == "int"  
            else bool(value) if variable_types.get(key) == "bool"  
            else value  
            for key, value in formatted_variables.items()  
        }  
      
        # Process endpoint, separating query parameters if necessary  
        raw_endpoint = template.get("endpoint", "")  
        if "?" in raw_endpoint:  
            endpoint, query_string = raw_endpoint.split("?", 1)  
            endpoint = endpoint.format(**final_variables)  # Fill path variables  
            query_params = dict(param.split("=") for param in query_string.split("&"))  
            formatted_query_params = {key: final_variables.get(value.strip("{}"), value) for key, value in query_params.items()}  
            formatted_endpoint = f"{endpoint}?{urlencode(formatted_query_params)}"  
        else:  
            formatted_endpoint = raw_endpoint.format(**final_variables)  
  
        json_data = None  
  
        # Determine if the request is a GraphQL or REST API call  
        if "query" in template or "query_file" in template:  
            # Handling GraphQL requests  
            data = {}  
            if "query" in template:  
                data["query"] = template["query"]  
            elif "query_file" in template:  
                data["query"] = ConfigLoader.load_query(template["query_file"])  
            data["variables"] = final_variables  
            json_data = data  
        else:  
            # Handling REST requests, json_data only if method is not GET and body_params are set  
            if method != "GET":  
                json_data = {  
                    key: params[key] if key in params and isinstance(params[key], list) else params.get(key, None)  
                    for key in template.get("body_params", [])  
                }  

        response = self.request(method, endpoint=formatted_endpoint, json=json_data, header_type=header_type)
  
        # Apply response filter if defined  
        response_filter = template.get("response_filter")  
        if response_filter:  
            response = self._filter_response(response, response_filter)  
  
        # Apply post filter if defined  
        post_filters = template.get("post_filter")  
        if post_filters:  
            response = self._apply_post_filters(response, post_filters, params)  
  
        return response
