import requests
import json
import time
from abc import ABC, abstractmethod

class ConfigLoader:
    """Loads API configuration and request templates"""

    @staticmethod
    def load_config(file_path):
        with open(file_path, "r") as f:
            return json.load(f)
        
    @staticmethod
    def load_graphql_query(file_path):
        with open(file_path, "r") as f:
            return f.read()
        
class BaseAPI(ABC):
    """Abstract base class for handling API authentication and universal requests"""

    def __init__(self, config_path, api_name, timeout=10, max_retries=3, backoff_factor=2):
        self.full_config = ConfigLoader.load_config(config_path)

        if api_name not in self.full_config:
            raise ValueError(f"API '{api_name}' not found in config.")
        
        self.config = self.full_config[api_name]
        self.base_url = self.config.get("base_url")
        self.headers = self._set_headers()
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    @abstractmethod
    def _set_headers(self):
        """Set authentication headers."""
        pass

    def request(self, method, endpoint="", **kwargs):
        """Handles generic API requests"""
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(self.max_retries):
            try:

                response = requests.request(method, url, headers=self.headers, timeout=self.timeout, **kwargs)

                if response.status_code < 400:
                    return response.json()
                print(f"Attempt {attempt+1}: API error: {response.status_code} - {response.text}")
            except requests.exceptions.RequestException as e:
                print(f"Attempt {attempt+1}: Request failed - {e}")
            
            sleep_time = self.backoff_factor ** attempt
            print(f"Retrying in {sleep_time} seconds...")
            time.sleep(sleep_time)
            
        raise Exception(f"API request failed after {self.max_retries} attempts.")
    
    
class SpecificAPI(BaseAPI):
    """Handles API specific logic using request templates"""
    def __init__(self, config_path, template_path, api_name, timeout=10, max_retries=3, backoff_factor=2):
        super().__init__(config_path, api_name, timeout, max_retries, backoff_factor)
        self.templates = ConfigLoader.load_config(template_path)

        if api_name not in self.templates:
            raise ValueError(f"API '{api_name}' not found in templates.")
        
        self.api_templates = self.templates[api_name]

    def _set_headers(self):
        """Set authentication headers based on API type"""
        return {
            "Authorization": f"Bearer {self.config.get('api_token')}",
            "Content-Type": "application/json"
        }
       
    def _filter_response(self, response, filter_path):
        """Extracts only the needed part of the response on the filter path"""
        keys = filter_path.split(".")
        for key in keys:
            response = response.get(key, {})
        return response
    
    def make_request(self, request_name, **params):
        """Uses predefined request templates to execute API calls"""
        if request_name not in self.api_templates:
            raise ValueError(f"Request template '{request_name}' not found for API.")
        
        template = self.api_templates[request_name]
        method = template.get("method")
        variable_types = template.get("types", {})
        formatted_variables = {
            key: value.format(**params) for key, value in template.get("variables", {}).items()
        }
        final_variables = {
            key: int(value) if variable_types.get(key) == "int" else value
            for key, value in formatted_variables.items()
        }
        if "query" in template:
            data = {
                "query": template["query"],
                "variables": final_variables
            }
        elif "query_file" in template:
            query = ConfigLoader.load_graphql_query(template["query_file"])
            data = {
                "query": query,
                "variables": final_variables
            }
        else:
            data = None
 
        response = self.request(method, json=data)
        response_filter = template.get("response_filter")
        if response_filter:
            response = self._filter_response(response, response_filter)

        return response
    

# test
    
api = SpecificAPI("config.json", "templates.json", "graphql")
#response = api.make_request("check_pr_status", repo_owner="AMD-Radeon-Driver", repo_name="drivers", pr_number=93877)
response = api.make_request("pr_merge_status", repo_owner="AMD-SW-Infra", repo_name="AICodeReview", pr_number=160)
#response = api.make_request("check_pr_status_fix", repo_owner="AMD-SW-Infra", repo_name="AICodeReview", pr_number=160)
print(response)