import logging
import requests

class APIErrorHandler:
    """Handles API errors, logging and structured exception management"""

    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)

    def handle_response(self, response):
        """Process API responses and raises appropriate exceptions if needed"""
        try:
            response.raise_for_status() # Raise error for HTTP errors (4xx/5xx)
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            self.log_error(f"HTTP error: {response.status_code} - {response.text}")
            raise RuntimeError(f"API request failed with status {response.status_code}: {response.text}") from http_err
        except requests.exception.RequestException as req_err:
            self.log_error(f"Request error: {req_err}")
            raise RuntimeError(f"API request error: {req_err}") from req_err
        except ValueError:
            self.log_error("Failed to decode JSON response")
            raise RuntimeError("API returned invalid JSON response")
        
    def log_error(self, message):
        """Logs error message in a standardized format"""
        self.logger.error(message)

    def retry_request(self, request_func, retries=3, *args, **kwargs):
        """Retries an API request in case of failures"""
        for attempt in range(retries):
            try:
                response = request_func(*args, **kwargs)
                return self.handle_response(response)
            except RuntimeError as e:
                if attempt == retries - 1:
                    self.log_error(f"Final attempt failed: {e}")
                    raise
                self.log_error(f"Retry {attempt + 1}/{retries} after error: {e}")