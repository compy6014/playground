import json

class ErrorHandler:
    """Handles API errors"""

    def __init__(self, config_loader):
        """Initialize ErrorHandler with a reference to ConfigLoader"""
        self.config_loader = config_loader

    def get_error_message(self, api_name, request_name, status_code, **error_details):
        """Retrieves a predefined error message for a specific request_name and status_code"""
        template =  self.config_loader.load_request_template(api_name, request_name)
        error_templates = template.get("errors", {})

        # Get error message based on status code or use default if not defined
        error_message = error_templates.get(str(status_code), error_templates.get("default", "An unexpected error occured"))

        return error_message.format(**error_details)