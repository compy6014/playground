from workflow_executor import WorkflowExecutor


context = {
    #"alert_numbers": [1443, 1437, 1441],
    "from_date": "2025-03-15T00:00:00Z",
    "owner": "AMD-Radeon-Driver",
    "repo": "dal",
    "git_environment": "enterprise",
    "state": "open",
    "codeql_environment": "dev",
    "include_explanation": True,
    "pr_platform": True,
    "branch_delete": True,
    "draft_pr": True,
    "team_name": "demo"
}
executor = WorkflowExecutor(workflow_name="demo_codeql", team_name="demo")
executor.execute(context)

