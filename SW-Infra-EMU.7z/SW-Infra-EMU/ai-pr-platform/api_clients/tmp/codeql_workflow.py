# Move imports to template
import os, re
from datetime import datetime, timezone
from specific_api import SpecificAPI
from template_formatter import Formatter
from utility_functions import FunctionLibrary

# Vars from input context
# alert_numbers = []
# alert_numbers = [1435]
# owner = "AMD-Radeon-Driver"
# repo = "dal"
# git_environment = "enterprise"
# branch = "amd-dal"
# state = "open"
# from_date = "2025-03-18T00:00:00Z"
# to_date = "2025-03-18T23:59:59Z"
# include_explanation = True
# detect_fp = True
# pr_platform = True
# codeql_environment = "dev"
# team_name = "demo"
# #ticket_id = "ID_001_test"
# branch_delete = False
# draft_pr = True




# Actual workflow
if git_environment == "enterprise":
    github_instance = "on-prem"
else:
    github_instance = "EMU"

formatter_context = {
    "owner": owner,
        "repo": repo
}
github_api = SpecificAPI("github", environment=git_environment)
codeql_api = SpecificAPI("codeql_new", environment=codeql_environment)
graphql_api = SpecificAPI("graphql", environment=git_environment)
formatter = Formatter("codeql_templates", team_name, formatter_context)

rules = formatter.format("rules")
branch = formatter.format("base_branch")
detect_fp = formatter.format("detect_fp")
ticket_id = formatter.format("ticket_id")
git_blame = formatter.format("git_blame")
service_accounts = formatter.format("service_accounts")
send_no_alert_email = formatter.format("send_no_alert_email")
email_server = formatter.format("email_server")
email_port = formatter.format("email_port")
email_sender = formatter.format("email_sender")

# print("===RULES") #DEBUG
# print(rules) #DEBUG
# print("===BASE BRANCH") #DEBUG
# print(branch) #DEBUG
# print("===DETECT FP") #DEBUG
# print(detect_fp) #DEBUG
# print(git_blame) #DEBUG
# print(service_accounts) #DEBUG
# print(send_no_alert_email) #DEBUG
# print(email_server, email_port, email_sender) #DEBUG


rules = [rule.strip() for rule in rules.split(',')]
results = []
filtered_alerts = []
alert_numbers = globals().get('alert_numbers', None)
if alert_numbers:
    for alert_number in alert_numbers:
        print(f"Fetching alert {alert_number} from {owner}/{repo}")
        alert_json = github_api.make_request("get_code_scanning_alert", repo_name=repo, repo_owner=owner, alert_number=alert_number)
        filtered_alerts.append(alert_json)
        date_sentence = "<p></p>"
else:
    from_date = globals().get('from_date', None)
    to_date = globals().get('to_date', None)
    if from_date and to_date:
        print(f"Fetching alerts from {owner}/{repo}, from {from_date} to {to_date}")
        from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
        readable_from_date = from_date_dt.strftime("%B %d, %Y")
        to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
        readable_to_date = to_date_dt.strftime("%B %d, %Y")
        date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created from {readable_from_date} to {readable_to_date}:</p>"
    elif from_date:
        print(f"Fetching alerts from {from_date} to now {datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}")
        from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
        readable_from_date = from_date_dt.strftime("%B %d, %Y")
        readable_to_date = datetime.now(timezone.utc).strftime("%B %d, %Y")
        date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created from {readable_from_date} to {readable_to_date}:</p>"
    elif to_date:
        print(f"Fetching alerts up to {to_date}")
        to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
        readable_to_date = to_date_dt.strftime("%B %d, %Y")
        date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created up to {readable_to_date}:</p>"
    else:
        print("No date range specified, filtering not applied")
        date_sentence = "<p></p>"
    all_alerts_json = github_api.make_request("get_code_scanning_results", repo_name=repo, repo_owner=owner, branch=branch, state=state, rules=rules, from_date=from_date, to_date=to_date)
    print(f"Found {len(all_alerts_json)} alerts")
    filtered_alerts.append(all_alerts_json)


if len(filtered_alerts) == 1 and isinstance(filtered_alerts[0], list):  
    flat_data = filtered_alerts[0]  
else:  
    flat_data = filtered_alerts 

for alert in flat_data:
    result = {
        'alert_number': alert['number'],
        'url': alert['html_url'],
        'predicted_as_fp': False,
        'pr_url': None,
        'branch_name': None,
        'explanation': None
    }

    # print("===ALERT NUMBER") #DEBUG
    # print(result['alert_number']) #DEBUG

    print(f"Caling CodeQL Fix API for alert {result['alert_number']}")
    fix = codeql_api.make_request("codeql_fix", alert_num=result['alert_number'], include_explanation=include_explanation, github_instance=github_instance, owner=owner, repo_name=repo, detect_fp=detect_fp, pr_platform=pr_platform)
    print(f"Fix: {fix}")
    result['predicted_as_fp'] = fix['predicted_as_fp']

    if result['predicted_as_fp'] and detect_fp:
        print(f"Predicted as FP; \n{fix['explanation']}")
        result['explanation'] = fix['explanation']
        results.append(result)
        continue

    base_sha = alert['most_recent_instance']['commit_sha']
    file_path = alert['most_recent_instance']['location']['path']
    start_line = alert['most_recent_instance']['location']['start_line']
    end_line = alert['most_recent_instance']['location']['end_line']


    print("===FILE PATH") #DEBUG
    print(file_path) #DEBUG

    #BLAME ASSIGN TO REVIEWERS - NEW PR/BRANCH/MODIFIED_FILE
    #service_accounts = {s.strip() for s in service_accounts.split(", ") if s.strip()}
    #fallback_list = "someone"
    #fallback_list = {s.strip() for s in fallback_list.split(", ") if s.strip()}

    if git_blame is True:
        fallback_list = formatter.format("fallback_team_slug")
        response = graphql_api.make_request("blame", repo_name=repo, repo_owner=owner, branch_name=branch, file_path=file_path)
        blame_data = response['data']['repository']['ref']['target']['blame']['ranges']
        blame_list = FunctionLibrary.blame_for_lines(blame_data, start_line, end_line)
        blame_list = [r.strip() for r in blame_list.split(", ") if r.strip()]
        filtered_list = [r for r in blame_list if r not in service_accounts]
        if filtered_list:
            final_list = filtered_list
        else:
            last_file_mod = github_api.make_request("get_last_committer", repo_name=repo, repo_owner=owner, branch=branch, file_path=file_path)[0]
            if last_file_mod and last_file_mod not in service_accounts:
                final_list = last_file_mod
            else:
                final_list = fallback_list
                team_reviewers = True

    
    original_file = FunctionLibrary.base64_decode(github_api.make_request("get_file_content", repo_name=repo, repo_owner=owner, branch_sha=base_sha, file_path=file_path))
    # print("===DIFF") #DEBUG
    # print(fix['diff']) #DEBUG
    
    corrected_file = FunctionLibrary.apply_diff_to_file(original_file=original_file, file_name=file_path, code_diff=fix['diff'])

    #Encode updated file
    encoded_content = FunctionLibrary.base64_encode(corrected_file)

    # formatter_context = {
    #     "owner": owner,
    #     "repo": repo,
    #     "branch": branch,
    #     "alert_number": result['alert_number'],
    #     "rule_header": FunctionLibrary.get_rule_based_commit_text(alert['rule']['id'], alert['rule']['description'], alert['rule']['description'])[0],
    #     "root_folder": (os.path.normpath(file_path)).split(os.path.sep)[0],
    #     "rule_description": FunctionLibrary.get_rule_based_commit_text(alert['rule']['id'], alert['rule']['description'], alert['rule']['description'])[1],
    #     "alert_severity": alert['rule'].get('security_severity_level', "N/A"), 
    #     "alert_description": alert['rule']['description'], 
    #     "alert_url": alert['html_url'],
    #     "fix_explanation": fix['explanation'],
    #     "signoff_user": github_api.make_request("get_user_details")[0],
    #     "signoff_email": github_api.make_request("get_user_details")[1]
    # }

    #formatter = Formatter("codeql_templates", team_name, formatter_context)
    
    #formatter.update_context({"ticket_id": ticket_id, "date_sentence": date_sentence})

    formatter.update_context({
        "owner": owner,
        "repo": repo,
        "branch": branch,
        "alert_number": result['alert_number'],
        "rule_header": FunctionLibrary.get_rule_based_commit_text(alert['rule']['id'], alert['rule']['description'], alert['rule']['description'])[0],
        "root_folder": (os.path.normpath(file_path)).split(os.path.sep)[0],
        "rule_description": FunctionLibrary.get_rule_based_commit_text(alert['rule']['id'], alert['rule']['description'], alert['rule']['description'])[1],
        "alert_severity": alert['rule'].get('security_severity_level', "N/A"), 
        "alert_description": alert['rule']['description'], 
        "alert_url": alert['html_url'],
        "fix_explanation": fix['explanation'],
        "signoff_user": github_api.make_request("get_user_details")[0],
        "signoff_email": github_api.make_request("get_user_details")[1],
        "ticket_id": ticket_id,
        "date_sentence": date_sentence
    })
    
    # print("===TICKET ID") #DEBUG
    # print(ticket_id) #DEBUG

    generated_branch_name = formatter.format("generate_branch_name")

    # print("===GENERATED BRANCH NAME") #DEBUG
    # print(generated_branch_name) #DEBUG
    
    generated_commit_header = formatter.format("generate_commit_header")
    generated_commit_description = formatter.format("generate_commit_description") 
    generated_commit_message = generated_commit_header + "\n\n" + generated_commit_description

    generated_pr_title = formatter.format("generate_pr_title")
    # print("===GENERATED PR TITLE") #DEBUG
    # print(generated_pr_title) #DEBUG

    # formatter.update_context({"new_param": "new_value"})
    # print("UPDATE CONTEXT")
    # print(formatter_context)

    # override_branch_name = formatter.format("generate_branch_name", {"alert_number": "OVERRIDE"})
    # print("OVERRIDE CONTEXT")
    # print(override_branch_name)

    generated_pr_description = formatter.format("generate_pr_description")
    # print("===GENERATED PR DESCRIPTION") #DEBUG
    # print(generated_pr_description) #DEBUG

    sign_off_message = formatter.format("sign_off_message")
    
    if sign_off_message:
        generated_commit_message += f"\n\n{sign_off_message}"
    
    # print("===GENERATED COMMIT MESSAGE + SIGNOFF") #DEBUG
    # print(generated_commit_message) #DEBUG

    result['branch_name'] = generated_branch_name

    ###CREATE_BRANCH_AND_PUSH
    ##CREATE BRANCH
    #check if branch exists
        #if branch exists add prefix/suffix or delete branch

    try:
        branch_exists = github_api.make_request("check_existing_branch", repo_name=repo, repo_owner=owner, branch_name=generated_branch_name)
        print(branch_exists)
        print(f"Branch '{generated_branch_name}' already exists")
        #delete existing branch or create with new name
        #delete and create new
        if branch_delete:
            print(f"Deleting existing branch with name '{generated_branch_name}'")
            try:
                delete_branch = github_api.make_request("delete_existing_branch", repo_name=repo, repo_owner=owner, branch_name=generated_branch_name)
                print("Deleting existing branch")
            except RuntimeError as e:
                if "422" in str(e):
                    print(f"Existing branch '{generated_branch_name}' deleted")
                else:
                    raise
        else:
            generated_branch_name = generated_branch_name + '_2'
            create_branch_response = github_api.make_request("create_branch", repo_name=repo, repo_owner=owner, ref=f"refs/heads/{generated_branch_name}", sha=base_sha)
            print(f"Creating branch with modified name: {generated_branch_name}")
    
    except RuntimeError as e:
        if "404" in str(e):
            print(f"Branch '{generated_branch_name}' does not exist, creating branch")
            #create branch API request
            create_branch_response = github_api.make_request("create_branch", repo_name=repo, repo_owner=owner, ref=f"refs/heads/{generated_branch_name}", sha=base_sha)
            print(create_branch_response)
        else:
            raise
    ##CHECK IF FILE EXISTS
    try:
        file_sha = github_api.make_request("check_file_sha", repo_name=repo, repo_owner=owner, new_branch=generated_branch_name, file_path=file_path)
        print("===FILE_SHA") #DEBUG
        print(file_sha) #DEBUG
    except RuntimeError as e:
        if "404" in str(e):
            print(f"File '{file_path}' does not exist")
            file_sha = None

    if file_sha:
        response = github_api.make_request("update_existing_file", repo_name=repo, repo_owner=owner, file_path=file_path, message=generated_commit_message, content=encoded_content, branch=generated_branch_name, sha=file_sha)
        print(f"Updating existing file '{file_path}'")
    else:
        response = github_api.make_request("create_new_file", repo_name=repo, repo_owner=owner, file_path=file_path, message=generated_commit_message, content=encoded_content, branch=generated_branch_name)
        print(f"Creating file '{file_path}'")
    
    result['branch_name'] = generated_branch_name
    
    ###CREATE_PULL_REQUEST
    #input or baseBranch from config
    pr_url = github_api.make_request("create_pull_request", repo_name=repo, repo_owner=owner, title=generated_pr_title, body=generated_pr_description, head=generated_branch_name, base=branch, draft=draft_pr)
    print(f"PR title: {generated_pr_title}")
    result['pr_url'] = pr_url
    # print("===RESULT PR_URL UPDATE") #DEBUG
    # print(result['pr_url']) #DEBUG
    # if result['pr_url']:
    #     print("PR URL updated")
    # else:
    #     print("PR URL not updated")
    #add labels
        #get pr_number from created pull request
    #pr_url = "https://github.amd.com/AMD-SW-Infra/AICodeReview/pull/238"
    pr_number = re.search(r'/pull/(\d+)', pr_url).group(1)
    #print(f"PR_NUMBER TEST: {pr_number}")
    label_list = formatter.format("label_list")
    reviewer_list = formatter.format("reviewer_list")
    # print("===LABEL_LIST") #DEBUG
    # print(label_list)
    # print("===LABEL_LIST_CONVERSION") #DEBUG
    label_list = [label.strip() for label in label_list.split(',')]
    # print(label_list)
    # print("===REVIEWER_LIST") #DEBUG
    # print(reviewer_list)
    # print("===REVIEWER_LIST_CONVERSION") #DEBUG
    reviewer_list = [reviewer.strip() for reviewer in reviewer_list.split(',')]
    print(reviewer_list)
    if pr_url is not None and label_list:   
        print(f"Adding labels to PR: {pr_url}")
        add_labels = github_api.make_request("add_labels_to_pr", repo_name=repo, repo_owner=owner, pr_number=pr_number, labels=label_list)
        print(f"Labels added")
        
    if pr_url is not None and reviewer_list:
        if '#last_committer' in reviewer_list:
            last_committer = github_api.make_request("get_last_committer", repo_name=repo, repo_owner=owner, branch=generated_branch_name, file_path=file_path)
            if last_committer:
                # Replace the placeholder with the actual committer's username
                reviewer_list = reviewer_list.replace('#last_committer', last_committer)
                print(f"Replaced '#last_committer' in reviewers list with {last_committer}.")
            else:
                # If no committer is found, remove the placeholder
                reviewer_list = reviewer_list.replace('#last_committer', '')
        add_reviewer = github_api.make_request("add_reviewers_to_pr", repo_name=repo, repo_owner=owner, pr_number=pr_number, reviewers=reviewer_list)
        print(f"Adding reviewers {reviewer_list} to PR: {pr_url}")

    
    # OVERRIDE FINAL_LIST FOR DEMO
    final_list = ["imirosav"]
    if git_blame is True:
        if team_reviewers:
            response = github_api.make_request("add_team_reviewers_to_pr", repo_name=repo, repo_owner=owner, pr_number=pr_number, team_reviewers=final_list)
            print(f"Assign team {final_list} to reviewers")
        else:
            response = github_api.make_request("add_reviewers_to_pr", repo_name=repo, repo_owner=owner, pr_number=pr_number, reviewers=final_list)
            print(f"Assign {final_list} to reviewers")
    
    results.append(result)

detected_fp = [result for result in results if result.get('predicted_as_fp') is True]
created_prs = [result for result in results if result['pr_url']]

# print("===DETECTED FPs") #DEBUG
# print(detected_fp) #DEBUG
# print("===CREATED PRs") #DEBUG
# print(created_prs) #DEBUG

# Format detected FP section
if detected_fp:
    detected_fp_section = "<ul>" + "".join([f"<li>For alert <a href='{fp['url']}'>{fp['alert_number']}</a>: {fp['explanation']}</li>" for fp in detected_fp]) + "</ul>"
else:
    detected_fp_section = "<ul><li>None</li></ul>"

# Format created PRs section
if created_prs:
    created_prs_section = "<ul>" + "".join([
        f"<li>For alert <a href='{pr['url']}'>{pr['alert_number']}</a>: <a href='{pr['pr_url']}'>{pr['pr_url']}</a></li>"
        for pr in created_prs
    ]) + "</ul>"
else:
    created_prs_section = "<ul><li>None</li></ul>"

formatter.update_context({"detected_fp_section": detected_fp_section, "created_prs_section": created_prs_section})


if detected_fp_section and created_prs_section == "<ul><li>None</li></ul>":
    if send_no_alert_email is True:
        send_email = True
    else:
        send_email = False
else:
    send_email = True

if send_email is True:
    email_body = formatter.format("email_body")
    email_subject = formatter.format("email_subject")
    email_recipients = formatter.format("email_recipients")    
    email = FunctionLibrary.send_email(email_server, email_port, email_sender, email_subject, email_body, email_recipients)