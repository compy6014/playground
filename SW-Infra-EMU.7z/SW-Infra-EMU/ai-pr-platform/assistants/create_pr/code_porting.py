# assistants/create_pr/code_porting_assistant.py

import os
from typing import Any, Dict, List, Optional

import requests

from assistants.ai_assistant import AIAssistant
from helpers.utils import save_to_file
from helpers.github_helper import GitHubHelper
from helpers.logger import get_module_logger

class CodePortingAssistant(AIAssistant):
    """
    Assistant that automates code porting by creating PRs.
    """

    def assistant_type(self) -> str:
        """Return the assistant type name used in the configuration."""
        return 'CodePorting'

    def required_parameters(self) -> list:
        """Return a list of required parameter names."""
        return ['owner', 'repo', 'target_branch', 'ticket_id']

    def optional_parameters(self) -> list:
        """Return optional parameter groups where at least one must be provided."""
        return [('commit_id', 'from_date'), ('commit_id', 'source_branch')]

    def __init__(self, ghe_token: str, code_porting_token: str, json_in_params: Optional[Dict[str, Any]] = None):
        super().__init__(ghe_token, json_in_params)
        self.code_porting_token = code_porting_token
        #self.logger = get_module_logger('CODE_PORTING')

        # Initialize attributes from json_in_params with defaults
        params = self.json_in_params  # Already initialized in the base class
        self.from_date = params.get('from_date')
        self.commit_id = params.get('commit_id')
        self.draft_pr = params.get('draft_pr', False)
        self.label_list = params.get('label_list', '')
        self.reviewer_list = params.get('reviewer_list', '')
        self.ticket_id = params.get('ticket_id', '')
        self.target_branch = params.get('target_branch')
        self.source_branch = params.get('source_branch')
        self.owner = params.get('owner')
        self.repo = params.get('repo')
        self.output_file = params.get('output_file', 'codeporting_result.html')

        self.commit_list: List[Dict[str, Any]] = []
        self.results: List[Dict[str, Any]] = []

        #TODO Remove
        # Initialize GitHub helper
        #self.gitHubHelper = self._initialize_github_helper()
        # Any other initializations can be added here

    #def api_url(self) -> str:
    #    """Return the API URL to be used for the API call."""
    #    return f"{self.api_url_name}"

    def pre_processing(self):
        """Collect items to process."""
        self.logger.debug("Starting pre-processing.")
        self.collect_items_to_process()
        self.logger.debug(f"Collected {len(self.commit_list)} commits to process.")

    def generate_api_params(self):
        """Generate API parameters for each commit."""
        self.logger.debug("Generating API parameters.")
        # Since parameters may vary per commit, we'll generate them during the API call.

    def api_call(self, params: Dict[str, Any]):
        """Perform the API call and return the result."""
        self.logger.debug(f"Making API call to {self.api_url_name} with params {params}.")
        headers = {"x-api-key": self.code_porting_token}
        try:
            resp = requests.post(self.api_url_name, headers=headers, params=params)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request to Code Porting API failed: {e}")
            raise

    def post_processing(self):
        """Perform any necessary post-processing steps."""
        self.logger.debug("Starting post-processing.")
        if self.results:
            try:
                output_body = self.prepare_output_body(self.results)
                save_to_file(output_body, self.output_file)
                self.logger.info(f"Results saved to {self.output_file}.")
            except Exception as e:
                self.logger.error(f"Error while preparing or saving output body: {e}")
                raise

    def perform_task(self):
        """Override perform_task to process multiple commits."""
        self.pre_processing()
        for item in self.commit_list:
            result = self.initialize_result(item)
            try:
                params = {
                    "commit_id": item['sha'][:7],
                    "repo_name": f"{self.owner}/{self.repo}"
                }
                api_result = self.api_call(params)
                if not self.should_process_item(api_result):
                    self.handle_unprocessable_item(item, api_result, result)
                else:
                    self.process_item(item, api_result, result)
            except Exception as e:
                result['status'] = 'Error'
                result['reason'] = str(e)
                self.logger.error(f"Error processing commit {item['sha'][:7]}: {e}")
            self.results.append(result)
        self.post_processing()
        return self.results

    def collect_items_to_process(self):
        """Collect the list of commits to process."""
        try:
            if self.commit_id:
                self.logger.info(f"Fetching commit by ID: {self.commit_id}")
                commit = self.gitHubHelper.get_commit_by_id(self.owner, self.repo, self.commit_id)
                self.commit_list = [commit] if commit else []
                if not self.commit_list:
                    self.logger.warning(f"No commit found with ID: {self.commit_id}")
            else:
                self.logger.info(
                    f"Fetching commits for owner: {self.owner}, repo: {self.repo}, "
                    f"branch: {self.source_branch}, from date: {self.from_date}"
                )
                self.commit_list = self.gitHubHelper.get_commits_since(
                    self.owner, self.repo, self.source_branch, self.from_date
                )
                if not self.commit_list:
                    self.logger.warning("No new commits found.")
        except Exception as e:
            self.logger.error(f"Error in collect_items_to_process: {e}")
            raise

    def initialize_result(self, item):
        """Initialize the result dictionary for a commit."""
        commit_id = item['sha'][:7]
        result = {
            'commit_id': commit_id,
            'commit_url': item['html_url'],
            'pr_url': None,
            'branch_name': None,
            'status': None,
            'reason': None,
            'files': []
        }
        return result

    def should_process_item(self, api_result) -> bool:
        """Determine whether the commit should be processed further."""
        return api_result.get('commit_processed') != "No"

    def handle_unprocessable_item(self, item, api_result, result):
        """Handle commits that should not be processed further."""
        commit_id = item['sha'][:7]
        reason = api_result.get('processing_reason', 'Unknown reason')
        self.logger.info(f"Code porting fix not applied for commit: {commit_id}, reason: {reason}")
        result['status'] = 'Not Applied'
        result['reason'] = reason

    def process_item(self, item, api_result, result):
        """Process the commit as per the API result, including creating PRs."""
        try:
            commit_id = item['sha'][:7]
            self.logger.debug(f"Processing commit: {commit_id}")

            # Process file changes
            file_changes = api_result.get('file_changes', [])
            if not file_changes:
                self.logger.warning(f"No file changes for commit: {commit_id}")
                result['status'] = 'No Changes'
                return

            # Create a branch and commit changes
            branch_name = f"{self.ticket_id}_{commit_id}"
            self.gitHubHelper.create_branch(self.owner, self.repo, branch_name, self.target_branch)
            self.gitHubHelper.commit_changes(self.owner, self.repo, branch_name, file_changes, commit_message=item['commit']['message'])

            # Create a pull request
            pr = self.gitHubHelper.create_pull_request(
                self.owner,
                self.repo,
                title=f"Code Porting: {item['commit']['message']}",
                head=branch_name,
                base=self.target_branch,
                body=f"Automated code porting for commit {commit_id}",
                draft=self.draft_pr
            )

            # Add labels and reviewers if specified
            if self.label_list:
                labels = [label.strip() for label in self.label_list.split(',')]
                self.gitHubHelper.add_labels_to_pr(self.owner, self.repo, pr.number, labels)
            if self.reviewer_list:
                reviewers = [rev.strip() for rev in self.reviewer_list.split(',')]
                self.gitHubHelper.add_reviewers_to_pr(self.owner, self.repo, pr.number, reviewers)

            result['status'] = 'Success'
            result['pr_url'] = pr.html_url
            result['branch_name'] = branch_name
            result['files'] = file_changes

            self.logger.info(f"PR created: {pr.html_url} for commit: {commit_id}")
        except Exception as e:
            result['status'] = 'Error'
            result['reason'] = str(e)
            self.logger.error(f"Error processing commit {commit_id}: {e}")

    def prepare_output_body(self, results) -> str:
        """Prepare the output body for code porting."""
        self.logger.debug("Preparing output body.")
        output_lines = ["<html><body><h1>Code Porting Results</h1><ul>"]
        for result in results:
            line = f"<li><strong>Commit {result['commit_id']}</strong>: {result['status']}"
            if result['pr_url']:
                line += f" - <a href='{result['pr_url']}'>PR Link</a>"
            if result['reason']:
                line += f" - Reason: {result['reason']}"
            line += "</li>"
            output_lines.append(line)
        output_lines.append("</ul></body></html>")
        return '\n'.join(output_lines)
