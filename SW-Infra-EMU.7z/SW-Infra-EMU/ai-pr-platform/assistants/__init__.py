# assistants/__init__.py  
  
from .ai_assistant import AIAssistant  
  
__all__ = ['AIAssistant']  
