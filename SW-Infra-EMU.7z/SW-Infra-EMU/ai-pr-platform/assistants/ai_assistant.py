# assistants/ai_assistant.py

import os
import sys
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import logging
import yaml

from helpers.github_helper import GitHubHelper
from helpers.ai_db_proxy import AIDBProxy
from helpers.ai_comment_manager import AICommentManager

class AIAssistant(ABC):
    """
    Abstract base class for AI Assistants.
    """

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        if not ghe_token:
            raise ValueError("GitHub Enterprise token (ghe_token) must be provided.")
        self.ghe_token = ghe_token
        self.json_in_params = json_in_params or {}
        self.json_api_params = None
        self.api_url_name = None
        self.use_dev_api = use_dev

        # Initialize logger first
        self.logger = self._initialize_logger()
        self.logger.debug("Initializing AIAssistant.")

        # Load configurations
        self.config = self._load_config()
        self.logger.debug(f"Configuration loaded: {self.config}")

        # Initialize helpers
        self.github_helper = self._initialize_github_helper()
        self.ai_db_proxy = self._initialize_ai_db_proxy()
        self.comment_manager = self._initialize_comment_manager()

        # Perform input parameter validation
        self.check_required_parameters()

        # Retrieve additional tokens
        self.api_token = self._get_api_token()

        # Set the API URL from the configuration
        self.api_url_name = self.get_api_url()

    @abstractmethod
    def assistant_type(self) -> str:
        """Return the assistant type name used for configuration lookup."""
        pass

    def _load_config(self) -> Dict[str, Any]:
        """Load configurations from the config.yaml file."""
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'config.yaml')

        # Resolve the absolute path
        config_path = os.path.abspath(config_path)

        if not os.path.exists(config_path):
            self.logger.error(f"Configuration file not found: {config_path}")
            raise FileNotFoundError(f"Configuration file not found: {config_path}")

        with open(config_path, 'r') as config_file:
            config = yaml.safe_load(config_file)
        return config

    def _get_api_token(self) -> str:
        """
        Retrieve the API token required by the assistant.

        First, check if it's provided in json_in_params.
        If not, retrieve it from environment variables.
        """
        assistant_type = self.assistant_type().upper()
        token_param_name = 'api_token'
        token = self.json_in_params.get(token_param_name)
        if token:
            self.logger.debug(f"Using API token from json_in_params for assistant {assistant_type}.")
            return token

        token_env_var = f"API_TOKEN"
        token = os.getenv(token_env_var)
        if token:
            self.logger.debug(f"Using API token from environment variable '{token_env_var}' for assistant {assistant_type}.")
            return token

        raise ValueError(
            f"API token for {assistant_type} is required. Please provide it in '{token_param_name}' parameter "
            f"or set the environment variable '{token_env_var}'."
        )

    def get_api_url(self) -> str:
        """Return the appropriate API URL based on the use_dev_api flag."""
        assistant_type = self.assistant_type()
        api_urls = self.config.get('api_urls', {})
        assistant_api_urls = api_urls.get(assistant_type, {})
        if not assistant_api_urls:
            raise ValueError(f"API URLs not defined for assistant type '{assistant_type}'")

        if self.use_dev_api:
            api_url = assistant_api_urls.get('dev')
            if not api_url:
                raise ValueError(f"Development API URL not defined for assistant type '{assistant_type}'")
        else:
            api_url = assistant_api_urls.get('prod')
            if not api_url:
                raise ValueError(f"Production API URL not defined for assistant type '{assistant_type}'")
        return api_url

    def _check_author_exclusion(self, author: str, additional_authors: Optional[list[str]] = None):
        """
        Check if the given author is in the exclude list or in the additional authors list.
        If the author is in either list, raise an exception.

        Args:
            author (str): The username of the author to check.
            additional_authors (Optional[List[str]]): Additional authors to exclude.

        Raises:
            ValueError: If the author is excluded from processing.
        """
        # Get the exclude list from the configuration
        exclude_list = self.config.get('api_urls', {}).get(self.assistant_type(), {}).get('exclude_authors', [])
        if not isinstance(exclude_list, list):
            self.logger.warning("Exclude authors list is not a list. Defaulting to an empty list.")
            exclude_list = []

        # Combine the exclude_list with additional_authors if provided
        if additional_authors:
            exclude_list.extend(additional_authors)

        if author in exclude_list:
            self.logger.info(f"Author '{author}' is excluded from processing.")
            raise ValueError(f"Author '{author}' is excluded from processing.")
        else:
            self.logger.debug(f"Author '{author}' is not in the exclude list.")

    @abstractmethod
    def required_parameters(self) -> list:
        """Return a list of required parameter names."""
        pass

    def optional_parameters(self) -> list:
        """
        Return a list of optional parameter groups where at least one must be provided.

        Each group is a tuple of parameter names where at least one must be provided.
        """
        return []

    def check_required_parameters(self):
        """Check that all required parameters are present in json_in_params."""
        # Check required parameters
        required_params = self.required_parameters()
        missing_params = [
            param for param in required_params
            if param not in self.json_in_params or self.json_in_params[param] is None
        ]

        # Check optional parameter groups
        for group in self.optional_parameters():
            if not any(self.json_in_params.get(param) is not None for param in group):
                group_str = ' or '.join(group)
                missing_params.append(f"At least one of: {group_str}")

        if missing_params:
            raise ValueError(f"Missing required parameters: {', '.join(missing_params)}")

        # Assign parameters to instance variables
        for param in required_params:
            setattr(self, param, self.json_in_params.get(param))
        for group in self.optional_parameters():
            for param in group:
                if param in self.json_in_params and self.json_in_params[param] is not None:
                    setattr(self, param, self.json_in_params.get(param))

    @abstractmethod
    def pre_processing(self):
        """Perform any necessary pre-processing steps."""
        pass

    @abstractmethod
    def generate_api_params(self):
        """Generate parameters for the API call based on input parameters."""
        pass

    @abstractmethod
    def api_call(self, api_url_name: str, params: Dict[str, Any]):
        """Perform the API call and return the result."""
        pass

    @abstractmethod
    def post_processing(self):
        """Perform any necessary post-processing steps."""
        pass

    def perform_task(self):
        """Perform the main task by orchestrating the steps."""
        self.pre_processing()
        self.generate_api_params()
        result = self.api_call(self.api_url_name, self.api_token, self.json_api_params)
        self.logger.debug(f"API call result: {result}")

        self.post_processing(result)
        return result

    def _initialize_github_helper(self):
        """Initialize the GitHub helper."""
        self.logger.debug("Initializing GitHubHelper with ghe_token.")
        return GitHubHelper(self.ghe_token)

    def _initialize_ai_db_proxy(self):
        """Initialize the AI DB Proxy."""
        self.logger.debug("Initializing AIDBProxy.")
        # Assuming AIDBProxy is a defined helper
        return AIDBProxy()

    def _initialize_logger(self):
        """Initialize the Logger."""
        logger = logging.getLogger(self.__class__.__name__)
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
        handler.setFormatter(formatter)
        if not logger.handlers:
            logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
        return logger

    def _initialize_comment_manager(self):
        """Initialize the Comment Manager."""
        self.logger.debug("Initializing CommentManager.")
        # Assuming CommentManager is a defined helper
        return AICommentManager()
