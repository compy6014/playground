class CoverityAssistant():
    '''Coverity Assistant class'''