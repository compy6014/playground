import json
import base64
import re
import logging
import os
import subprocess
import smtplib
import fnmatch
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication 
from utils.config_loader import ConfigLoader

class FunctionLibrary:
    LOG_LEVEL = logging.DEBUG
    @staticmethod
    def base64_encode(data):
        if not isinstance(data, str):
            raise ValueError("Data must be a string")
        return base64.b64encode(data.encode()).decode()
    
    @staticmethod
    def base64_decode(data):
        if not isinstance(data, str):
            raise ValueError("Data must be string")
        return base64.b64decode(data).decode()
    
    @classmethod
    def _apply_diff(self, original_lines: list[str], diff_lines: list[str]) -> tuple[list[str], int, list[int], list[tuple[int, str]]]:
        """Helper method to apply a diff to lines."""
        diff_pattern = re.compile(r'@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@')
        new_lines = []
        old_line_idx = 0  # Index in original_lines
        diff_line_idx = 0  # Index in diff_lines

        added_lines = []
        removed_lines = []
        start_line = 0

        while diff_line_idx < len(diff_lines):
            line = diff_lines[diff_line_idx]
            diff_line_idx += 1

            match = diff_pattern.match(line)
            if match:
                # Parse hunk header
                old_line_no = int(match.group(1)) - 1  # zero-based index
                new_line_no = int(match.group(2)) - 1
                start_line = new_line_no
                hunk_added_lines = []
                hunk_removed_lines = []

                # Add unchanged lines before the hunk
                while old_line_idx < old_line_no:
                    new_lines.append(original_lines[old_line_idx])
                    old_line_idx += 1

                # Process hunk lines
                while diff_line_idx < len(diff_lines):
                    diff_line = diff_lines[diff_line_idx]
                    if diff_line.startswith('@@'):
                        # Next hunk header, break to outer loop
                        break
                    diff_line_idx += 1

                    if diff_line.startswith(' '):
                        # Context line, copy from original
                        if old_line_idx < len(original_lines):
                            new_lines.append(original_lines[old_line_idx])
                            old_line_idx += 1
                        else:
                            # Original file ended unexpectedly
                            pass
                    elif diff_line.startswith('-') and not diff_line.startswith('---'):
                        # Line removed from original
                        if old_line_idx < len(original_lines):
                            # Record removed line number (1-based)
                            hunk_removed_lines.append(old_line_idx + 1)
                            old_line_idx += 1
                        else:
                            # Original file ended unexpectedly
                            pass
                    elif diff_line.startswith('+') and not diff_line.startswith('+++'):
                        # Line added to new file
                        new_lines.append(diff_line[1:] + '\n')
                        # Record added line position (1-based)
                        hunk_added_lines.append((len(new_lines), diff_line[1:] + '\n'))
                    else:
                        # Should not happen
                        pass

                # Extend overall added and removed lines
                added_lines.extend(hunk_added_lines)
                removed_lines.extend(hunk_removed_lines)
            else:
                # Non-hunk line (should be headers), skip
                pass

        # Append any remaining lines from the original file
        while old_line_idx < len(original_lines):
            new_lines.append(original_lines[old_line_idx])
            old_line_idx += 1

        return new_lines, start_line, removed_lines, added_lines

    @classmethod
    def apply_diff_to_file(self, original_file: str, file_name: str, code_diff: str) -> str:
        """Apply a diff to a specific file."""
        lines = original_file.splitlines(keepends=True)
        file_pattern = re.compile(r'^--- a/(\S+)')
        code_diff = code_diff.replace('\n\n', '\n \n') # Fix for empty lines in diff
        diff_lines = code_diff.split('\n')

        apply_changes = False

        for i, line in enumerate(diff_lines):
            file_match = file_pattern.match(line)
            if file_match:
                current_file = file_match.group(1)
                apply_changes = (current_file == file_name)
                continue

            if apply_changes:
                updated_lines, start_line, removed_lines, added_lines = self._apply_diff(lines, diff_lines[i:])
                print(f"Applied diff to file: {file_name}, start_line: {start_line}, removed_lines: {removed_lines}, added_lines: {added_lines}")
                return ''.join(updated_lines)

        return original_file
    
    
    @classmethod
    def get_rule_based_commit_text(self, rule_id: str, default_commit_header: str, default_commit_description: str) -> tuple[str, str]:
        """
        Returns a commit header and description based on a given rule_id.
        """
        # Map specific rule IDs or groups of IDs to a header and description
        rule_map = {
            ("cpp/comparison-with-wider-type",): (
                "Do not compare integers with different widths",
                "Avoid comparing integers with different widths"
            ),
            ("cpp/missing-null-test", "cpp/inconsistent-null-check", "cpp/inconsistent-nullness-testing"): (
                "Handle potential null pointer",
                "Make sure to check for null"
            ),
            ("cpp/memory-never-freed", "cpp/memory-may-not-be-freed"): (
                "Free memory allocation",
                "Free memory to avoid memory leak"
            )
        }

        for group, (header_text, description_text) in rule_map.items():
            if rule_id in group:
                return header_text, description_text

        # Fallback if no match
        return default_commit_header, f"Fix for: {default_commit_description}"
    
    @staticmethod
    def get_module_logger(module_name:str) -> logging.Logger:
        """Configures and returns a logger for the specified module.
        This function creates a logger with a specified name (typically the module name)
        and sets up both console and file logging. The log messages include log level,
        module name, timestamp, and the message.
        Args:
            module_name (str): The name of the logger, usually the module name.
        Returns:
            logging.Logger: A configured logger instance with both console and file handlers.
        """
        output_location = 'debug/global.log'

        logger = logging.getLogger(module_name)
        logger.propagate = False

        handler_stream = logging.StreamHandler()
        os.makedirs(os.path.dirname(output_location), exist_ok=True)
        handler_file = logging.FileHandler(output_location, mode='a')

        formatter = logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        handler_stream.setFormatter(formatter)
        handler_file.setFormatter(formatter)

        logger.addHandler(handler_stream)
        logger.addHandler(handler_file)
        logger.setLevel(FunctionLibrary.LOG_LEVEL)
        
        return logger
    
    @staticmethod
    def send_email(smtp_server, smtp_port, from_email, subject, body, to_email, attachments=None):
        # Create MIMEText object to represent email
        msg = MIMEMultipart()
        msg['From'] = from_email
        msg['To'] = to_email
        msg['Subject'] = subject

        # Attach email body
        msg.attach(MIMEText(body, 'html'))

        #Attach files if provided
        if attachments:
            for filepath in attachments:
                if not os.path.isfile(filepath):
                    print(f"Attachment {filepath} does not exist, skipping.")
                    continue
                with open (filepath, 'rb') as f:
                    part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'  
                msg.attach(part)

        try:
            # Create SMTP session and send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.send_message(msg)
            server.quit()
            print("Email sent successfully")
        except Exception as e:
            print(f"Failed to send email: {e}")
        

    def get_last_modifier(file_path: str, line_number: int, repo_path: str = ".") -> str:
        """Returns user who last modified the given line in file"""
        try:
            result = subprocess.run(
                ["git", "-C", repo_path, "blame", "-L", f"{line_number},{line_number}", "--line-porcelain", file_path],
                capture_output=True,
                text=True,
                check=True
            )
            output = result.stdout.splitlines()
            for line in output:
                if line.startswith("author "):
                    return line[len("author "):]
            raise ValueError("Author not found in blame output")
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Git blame failed: {e.stderr}")
        except Exception as e:
            raise RuntimeError(f"Failed to get last modifier: {e}")

    
    def blame_for_lines(blame_ranges, start_line, end_line):
        reviewers = set()
        for r in blame_ranges:
            if r["endingLine"] >= start_line and r["startingLine"] <= end_line:
                user = r["commit"]["author"].get("user")
                if user and user.get("login"):
                    reviewers.add(user["login"])
        return ", ".join(sorted(reviewers))


    def mask_fields(self, data, fields_to_mask, mask_value="<base64encoded>"):  
        if isinstance(data, dict):  
            return {  
                k: (mask_value if k in fields_to_mask else self.mask_fields(v, fields_to_mask, mask_value))  
                for k, v in data.items()  
            }  
        elif isinstance(data, list):  
            return [self.mask_fields(item, fields_to_mask, mask_value) for item in data]  
        else:  
            return data 

    @staticmethod  
    def expand_alert_numbers(alert_numbers_str):  
        """  
        Expands a string like "1123, 1130-1135, 1140-1150, 1172"  
        into a list of integers: [1123, 1130, 1131, ..., 1135, 1140, ..., 1150, 1172]  
        """  
        import re  
        alert_numbers = []  
        for part in alert_numbers_str.split(','):  
            part = part.strip()  
            if not part:  
                continue  
            m = re.match(r'^(\d+)\s*-\s*(\d+)$', part)  
            if m:  
                start = int(m.group(1))  
                end = int(m.group(2))  
                if start > end:  
                    raise ValueError(f"Invalid alert range: {part}")  
                alert_numbers.extend(range(start, end + 1))  
            else:  
                try:  
                    alert_numbers.append(int(part))  
                except ValueError:  
                    raise ValueError(f"Invalid alert number: {part}")  
        return alert_numbers

    @staticmethod
    def write_skipped_alerts_to_file(skipped_alert_numbers=None, alert_limit=None):  
        with open('skipped_alerts.txt', 'w') as f:  
            if skipped_alert_numbers:  
                f.write(f"CodeQL Fix Generation processes up to {alert_limit} alerts per run, hence the alerts below were skipped. Please feel free to paste them into the Historical Issue Pipeline to run the tool on those.\n")
                f.write(f"Skipped alerts: {skipped_alert_numbers}")

    @classmethod
    def apply_unified_diff_to_content(self, original_content: str, code_diff: str) -> tuple[bool, str]:
        """Apply a unified diff to the original content.

        Returns:
            Tuple[bool, str]: A tuple containing a boolean indicating if changes were applied,
                              and the updated content or a reason message.
        """
        lines = original_content.splitlines(keepends=True)
        diff_pattern = re.compile(r'@@ -(\d+),\d+ \+(\d+),\d+ @@')
        diff_lines = code_diff.split('\n')

        if not code_diff.strip():
            reason = 'Empty diff.'
            return False, reason

        changes_applied = False

        for i, line in enumerate(diff_lines):
            match = diff_pattern.match(line)
            if match:
                start_line = int(match.group(2)) - 1

                added_lines = []
                removed_lines = []
                rem_count = 0
                for j, diff_line in enumerate(diff_lines[i+1:], start=1):
                    if diff_line.startswith('+') and not diff_line.startswith('+++'):
                        add_pos = start_line + j - 1 - rem_count
                        added_lines.append((add_pos, diff_line[1:] + '\n'))
                    elif diff_line.startswith('-') and not diff_line.startswith('---'):
                        rem_count += 1
                        removed_lines.append(start_line + j - 1)
                    elif diff_line.startswith('@@'):
                        break

                # Remove lines in reverse order to avoid index shifting
                for pos in sorted(removed_lines, reverse=True):
                    if 0 <= pos < len(lines):
                        del lines[pos]
                    else:
                        reason = f"Invalid line number {pos} for removal."
                        return False, reason

                # Adjust positions for added lines after removals
                offset = 0
                for pos, added_line in added_lines:
                    if 0 <= pos + offset <= len(lines):
                        lines.insert(pos + offset, added_line)
                        #offset += 1
                    else:
                        reason = f"Invalid line number {pos + offset} for insertion."
                        return False, reason

                changes_applied = True
                print(f"Applied diff to file at start_line: {start_line}, removed_lines: {removed_lines}, added_lines: {added_lines}")

        updated_content = ''.join(lines)

        if not changes_applied:
            reason = 'No lines were added or removed.'
            return False, reason

        return True, updated_content
    
    # @classmethod
    # def get_team_name(cls, owner, repo, branch=None, config_path=None):
    #     """
    #     Get the team name based on the owner, repo, and optionally branch.
    #     Reads configuration from a JSON file (config/teams_mapping.json).

    #     Args:
    #         owner (str): The repository owner.
    #         repo (str): The repository name.
    #         branch (str, optional): The branch name. Defaults to None.
    #         config_path (str, optional): Path to the JSON configuration file. Defaults to 'config/teams_mapping.json'.

    #     Returns:
    #         str: The team name or a default value if no match is found.
    #     """
    #     # Default path to the JSON configuration file
    #     if not config_path:
    #         # Use a relative path based on the location of this script
    #         base_dir = os.path.dirname(os.path.abspath(__file__))  # Path to helpers directory
    #         config_path = os.path.join(base_dir, '..', 'config', 'teams_mapping.json')  # Navigate to config/teams_mapping.json

    #     # Convert inputs to lowercase for case-insensitive matching
    #     owner_lower = owner.lower() if owner else ""
    #     repo_lower = repo.lower() if repo else ""
    #     branch_lower = branch.lower() if branch else None

    #     # Read and parse the JSON configuration file
    #     try:
    #         with open(config_path, 'r', encoding='utf-8') as f:
    #             config = json.load(f)
    #     except FileNotFoundError:
    #         raise FileNotFoundError(f"The configuration file {config_path} does not exist.")
    #     except json.JSONDecodeError as e:
    #         raise ValueError(f"Error decoding JSON configuration file {config_path}: {e}")

    #     # Use case-insensitive lookup
    #     for config_owner, owner_repos in config.items():
    #         if config_owner.lower() == owner_lower:
    #             for config_repo, repo_rules in owner_repos.items():
    #                 if config_repo.lower() == repo_lower:
    #                     # If a branch is provided, check for a branch-specific team name
    #                     if branch_lower:
    #                         for pattern, rule in repo_rules.items():
    #                             if fnmatch.fnmatch(branch_lower, pattern.lower()):
    #                                 team_name = rule.get('team_name') if isinstance(rule, dict) else rule
    #                                 if team_name:
    #                                     return cls.get_last_team_name(team_name)
    #                     # If branch not specified or no match found, use the default rule
    #                     rule = repo_rules.get("default")
    #                     if rule:
    #                         team_name = rule.get('team_name') if isinstance(rule, dict) else rule
    #                         return cls.get_last_team_name(team_name)
    #                     return f"{owner}/{repo}"
    #     # Return owner/repo as the team name if no match found
    #     return f"{owner.lower()}/{repo.lower()}"

    # @staticmethod
    # def get_last_team_name(team_name):
    #     """
    #     If team_name is a comma-separated string, return the last value (stripped).
    #     """
    #     if isinstance(team_name, str) and ',' in team_name:
    #         return team_name.split(',')[-1].strip()
    #     return team_name

    # @classmethod
    # def get_team_name(cls, owner, repo, branch=None, config_path=None):
    #     """
    #     Get the team name based on the owner, repo, and optionally branch.
    #     Works with the new teams_mapping.json structure where team names are top-level keys.

    #     Args:
    #         owner (str): The repository owner.
    #         repo (str): The repository name.
    #         branch (str, optional): The branch name. Defaults to None.
    #         config_path (str, optional): Path to the JSON configuration file. Defaults to 'config/teams_mapping.json'.

    #     Returns:
    #         str: The team name or a default value if no match is found.
    #     """
    #     # Default path to the JSON configuration file
    #     if not config_path:
    #         # Use a relative path based on the location of this script
    #         base_dir = os.path.dirname(os.path.abspath(__file__))  # Path to helpers directory
    #         config_path = os.path.join(base_dir, '..', 'config', 'teams_mapping.json')  # Navigate to config/teams_mapping.json

    #     # Convert inputs to lowercase for case-insensitive matching
    #     owner_lower = owner.lower() if owner else ""
    #     repo_lower = repo.lower() if repo else ""
    #     branch_lower = branch.lower() if branch else None
    #     repo_path = f"{owner_lower}/{repo_lower}"

    #     # Read and parse the JSON configuration file
    #     try:
    #         with open(config_path, 'r', encoding='utf-8') as f:
    #             config = json.load(f)
    #     except FileNotFoundError:
    #         raise FileNotFoundError(f"The configuration file {config_path} does not exist.")
    #     except json.JSONDecodeError as e:
    #         raise ValueError(f"Error decoding JSON configuration file {config_path}: {e}")

    #     # Track teams that match the repo path for possible branch matching later
    #     matching_teams = {}
        
    #     # First pass: find all teams containing the repo path
    #     for team_name, team_repos in config.items():
    #         if repo_path in [repo_key.lower() for repo_key in team_repos.keys()]:
    #             # Store branch rules for this team's repo
    #             matching_teams[team_name] = team_repos.get(
    #                 repo_path, 
    #                 next((v for k, v in team_repos.items() if k.lower() == repo_path), {})
    #             )
        
    #     # If branch is provided, look for a specific branch match
    #     if branch_lower and matching_teams:
    #         for team_name, branch_rules in matching_teams.items():
    #             for pattern in branch_rules:
    #                 if fnmatch.fnmatch(branch_lower, pattern.lower()):
    #                     return cls.get_last_team_name(team_name)
        
    #     # If branch is not provided or no branch match found, check for "default" rule
    #     for team_name, branch_rules in matching_teams.items():
    #         if "default" in branch_rules:
    #             return cls.get_last_team_name(team_name)
        
    #     # If we have any matching teams but no specific branch match, use the first team
    #     if matching_teams:
    #         return cls.get_last_team_name(next(iter(matching_teams)))
        
    #     # Return owner/repo as the team name if no match found
    #     return f"{owner_lower}/{repo_lower}"

    # @staticmethod
    # def get_last_team_name(team_name):
    #     """
    #     If team_name is a comma-separated string, return the last value (stripped).
    #     """
    #     if isinstance(team_name, str) and ',' in team_name:
    #         return team_name.split(',')[-1].strip()
    #     return team_name



    # @classmethod
    # def get_team_names_from_github_paths(cls, github_paths_str):
    #     """
    #     Extract team names from a comma-separated string of GitHub paths.
    #     Each path should be in the format organization/repository/branch.
    #     Branch names can contain slashes.
        
    #     Args:
    #         github_paths_str (str): Comma-separated string of GitHub paths
    #                             e.g. "org1/repo1/branch1, org2/repo2/feature/branch2"
        
    #     Returns:
    #         list: List of team names corresponding to each GitHub path
    #     """
    #     team_names = []
        
    #     # Split the input string by commas and clean up whitespace
    #     paths = [path.strip() for path in github_paths_str.split(',')]
        
    #     for path in paths:
    #         # Skip empty paths
    #         if not path:
    #             continue
                
    #         # Split the path into components
    #         components = path.split('/')
            
    #         # Ensure the path has at least 3 components
    #         if len(components) < 3:
    #             raise ValueError(f"Invalid GitHub path format: {path}. Expected format: organization/repository/branch")
            
    #         # Extract organization and repository
    #         organization = components[0]
    #         repository = components[1]
            
    #         # Extract the branch (everything after organization/repository/)
    #         # This properly handles branch names with slashes
    #         branch = '/'.join(components[2:])
            
    #         # Get the team name using the existing method
    #         team_name = cls.get_team_name(organization, repository, branch)
    #         team_names.append(team_name)
        
    #     return team_names

    @classmethod
    def extract_components(cls, path):
        """
        Extract owner, repo, and branch from a full path string.
        
        Args:
            path (str): Full path string in format "owner/repo/branch"
            
        Returns:
            tuple: (owner, repo, branch) where branch may contain multiple '/'
        """
        components = path.split('/', 2)
        
        if len(components) < 2:
            return None, None, None
        
        owner = components[0]
        repo = components[1]
        
        # If there's a branch component (anything after repo)
        branch = components[2] if len(components) > 2 else None
        
        return owner, repo, branch
    
    @staticmethod
    def get_team_name(full_path, config_path=None):
        """
        Get the team name based on the full repo path.
        Reads configuration from a JSON file (config/teams_mapping_by_team.json).

        Args:
            full_path (str): Full repo path (owner/repo/branch)
            config_path (str, optional): Path to the JSON configuration file. Defaults to 'config/teams_mapping.json'.

        Returns:
            str: The team name or None if no match is found.
        """
        full_path = full_path.lower()
        # Split the path to get owner/repo and branch
        parts = full_path.split('/', 2)
        if len(parts) < 3:
            return None
        
        owner_repo = f"{parts[0]}/{parts[1]}"
        branch = parts[2]
        if not config_path:
            # Use a relative path based on the location of this script
            base_dir = os.path.dirname(os.path.abspath(__file__))  # Path to helpers directory
            config_path = os.path.join(base_dir, '..', 'config', 'teams_mapping_by_team.json')  # Navigate to config/teams_mapping.json
        with open(config_path, 'r') as f:
            teams_mapping = json.load(f)
        
        # Iterate through teams to find a match
        for team_name, repos in teams_mapping.items():
            if owner_repo in repos:
                # Check if the branch matches any of the branches for this repo
                for mapped_branch in repos[owner_repo]:
                    # The branch in the path starts with the mapped branch
                    if branch == mapped_branch or branch.startswith(mapped_branch + '/'):
                        return team_name
        
        return None
    
    @classmethod
    def get_team_names_from_github_paths(cls, github_paths_str):
        """
        Extract team names from a comma-separated string of GitHub paths.
        Each path should be in the format organization/repository/branch.
        Branch names can contain slashes.
        
        Args:
            github_paths_str (str): Comma-separated string of GitHub paths
                                e.g. "org1/repo1/branch1, org2/repo2/feature/branch2"
        
        Returns:
            list: List of team names corresponding to each GitHub path
        """
        team_names = []
        
        # Split the input string by commas and clean up whitespace
        paths = [path.strip() for path in github_paths_str.split(',')]
        
        for path in paths:
            # Skip empty paths
            if not path:
                continue
            
            # Get the team name using the existing method
            team_name = cls.get_team_name(path)
            team_names.append(team_name)
        
        return team_names