import json
import os

class ConfigLoader:
    API_CONFIG_PATH = "config/api_config.json"
    REQUEST_TEMPLATES_PATH = "templates/request_templates.json"
    FORMATTER_TEMPLATES_PATH = "templates/formatting_templates.json"
    WORKFLOW_TEMPLATES_PATH = "templates/workflow_templates.json"


    @staticmethod
    def load_api_config(api_name):
        """Load specific API configuration from api_config.json"""
        with open(ConfigLoader.API_CONFIG_PATH, "r") as f:
            config = json.load(f)

        if api_name not in config:
            raise ValueError(f"API '{api_name}' not found in api_config.json")
        
        return config[api_name]


    @staticmethod
    def load_request_template(api_name, request_name):
        """Load request template from request_templates.json"""
        with open(ConfigLoader.REQUEST_TEMPLATES_PATH, "r") as f:
            templates = json.load(f)

        if api_name not in templates or request_name not in templates[api_name]:
            raise ValueError(f"Request '{request_name}' not found in API '{api_name}' in request_templates.json")
        
        return templates[api_name][request_name]
    

    @staticmethod
    def load_formatter_template(template_category):
        """Load formatter template from formatter_templates.json"""
        with open(ConfigLoader.FORMATTER_TEMPLATES_PATH, "r") as f:
            templates = json.load(f)
        
        if template_category not in templates:
            raise ValueError(f"Template category '{template_category}' not found")
        
        return templates[template_category]


    @staticmethod
    def load_query(file_path):
        """Load query from a file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Query file '{file_path}' not found")
        
        with open(file_path, "r") as f:
            return f.read()
    

    @staticmethod
    def load_external_template(template_ref, as_json=False):
        """Loads template content from external file if 'external:' prefix is used.
        If as_json=True, parses file as JSON and returns dict, returns raw string by default"""
        if isinstance(template_ref, str) and template_ref.startswith("external:"):
        #if template_ref.startswith("external:"):
            file_path = template_ref.replace("external:", "").strip()

            if not os.path.exists(file_path):
                raise FileNotFoundError(f"External template file '{file_path}' not found")
            
            with open(file_path, "r") as f:
                return json.load(f) if as_json else f.read()
        # Return inline template if not a file reference
        return template_ref
    

    @staticmethod
    def load_workflow_template(workflow_name, team_name):
        """Uses general workflow and merge with team specific overrides"""
        with open(ConfigLoader.WORKFLOW_TEMPLATES_PATH, "r") as f:
            templates = json.load(f)
        
        if workflow_name not in templates:
            raise ValueError(f"Workflow '{workflow_name}' not found")

        return templates[workflow_name]
