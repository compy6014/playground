from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from exceptions import LLMException, LLMExceptionWithRetry
from logger import get_module_logger
import time
import requests
from requests.exceptions import Timeout


class QueryEngine(ABC):
    """Class that manages interaction with LLM Gateway.
    """

    def __init__(self, llm_manager_settings: dict, llm_token:str) -> None:
        self.logger                      = get_module_logger(llm_manager_settings["logger_name"])
        self.retry_wait_time_sec         = llm_manager_settings["retry_wait_time_sec"] # wait time for retrying API
        self.retry_response_codes        = llm_manager_settings["retry_response_codes"] # response codes to retry on
        self.global_retry_max_attempts   = llm_manager_settings["global_retry_max_attempts"] # max number of retries
        self.timeout_retry_attempts      = llm_manager_settings["timeout_retry_attempts"]
        self.invalid_text_retry_attempts = llm_manager_settings["invalid_text_retry_attempts"]
        self.llm_api_timeout             = llm_manager_settings["llm_api_timeout"]  # timeout in 30 second
        self.max_prompt_length           = llm_manager_settings["max_prompt_length"] # max number of characters to send to LLM
        # Setup LLM API related attributes
        self.llm_server                  = llm_manager_settings["llm_server"]
        self.llm_header                  = {llm_manager_settings["llm_header"]: llm_token}
        self.deployment_id               = llm_manager_settings["deployment_id"]
        self.endpoint_name               = llm_manager_settings["endpoint_name"]
        self.llm_parameters              = llm_manager_settings["llm_parameters"]
        self.reset_usage_counters()
        self.reset_debug()


    def get_debug_info(self) -> dict[str, str]:
        """Provides a dicitonary with debug information about the API parameters and response.

        Returns:
            dict[str, str]: debug info
        """
        debug = {
        "Model ID": getattr(self, 'deployment_id', ''),
        "API Parameters": getattr(self, 'llm_parameters', ''),
        "Responses": self.debug['Responses']
        }
        return debug


    def reset_debug(self) -> None:
        self.debug = {"Responses": []}


    def reset_usage_counters(self) -> None:
        self.num_llm_api_calls = 0
        self.num_llm_api_calls_success = 0
        self.total_llm_time_in_ms = 0
        self.num_prompt_tokens = 0  # not logged
        self.num_total_tokens = 0


    def get_num_llm_api_calls(self) -> int:
        return getattr(self, 'num_llm_api_calls', 0)


    def get_num_llm_api_calls_success(self) -> int:
        return getattr(self, 'num_llm_api_calls_success', 0)


    def get_num_prompt_tokens(self) -> int:
        return getattr(self, 'num_prompt_tokens', 0)


    def get_num_total_tokens(self) -> int:
        return getattr(self, 'num_total_tokens', 0)


    def get_total_llm_time_in_ms(self) -> int:
        return getattr(self, 'total_llm_time_in_ms', 0)


    def get_num_llm_total_tokens(self) -> int:
        return getattr(self, 'num_total_tokens', 0)

    def get_max_prompt_length(self) -> int:
        return self.max_prompt_length


    def get_avg_llm_time_in_ms(self) -> int:
        if hasattr(self, 'total_llm_time_in_ms') and hasattr(self,'num_llm_api_calls_success') and self.num_llm_api_calls_success > 0:
            return int(self.total_llm_time_in_ms / self.num_llm_api_calls_success)


    def is_text_valid(self, text: str, source='') -> bool:
        """Return whether the input text is valid or not.

        Args:
            text (str): text to evaluate
            source (str): the text type being evaluated (e.g. prompt, response)

        Returns:
            bool: True if valid, False otherwise.
        """
         # Check if the prompt is empty or contains only whitespace
        if not text or text.isspace():
            self.logger.warning(f'{source} text invalid! Text is empty or contains only whitespace.')
            return False

        # Check if the text length exceeds the maximum allowed length
        if len(text) > self.max_prompt_length:
            self.logger.warning(f'{source} text invalid! Text too large: {len(text)} characters. Should be < {self.max_prompt_length}.')
            return False

        # Check if the text contains non-ascii characters
        if not text.isascii():
            self.logger.warning(f'{source} text invalid! Contains non-ascii characters')
            return False

        return True


    def is_prompt_valid(self, prompt: str) -> bool:
        """Return whether the input prompt is valid or not.

        Args:
            prompt (str): prompt to evaluate

        Returns:
            bool: True if valid, False otherwise.
        """
        return self.is_text_valid(prompt, 'Prompt')


    def call_llm_api(self, body: dict[str, str]) -> dict[str, str]:
        """Calls the LLM API. Throws LLM exception if status is not successful
        Args:
            body (dict[str, str]): body containing parameters for the API
        Returns:
            dict[str, str]: response dict
        """
        self.logger.debug('Send Request to LLM')
        try:
            self.num_llm_api_calls += 1
            response = requests.post(url=f"{self.llm_server}/{self.deployment_id}/{self.endpoint_name}",
                                    json=body,
                                    headers=self.llm_header,
                                    timeout=self.llm_api_timeout)
            status = response.status_code
            reason = response.reason
            if status == 200:
                elapsed_in_ms = int(response.elapsed.seconds * 1000 + response.elapsed.microseconds / 1000)
                self.logger.debug(f'Successful LLM Response in {elapsed_in_ms/1000:.2f}s!')
                response = response.json()
                self.update_usage_counters(response, elapsed_in_ms)
                return response
            if status in self.retry_response_codes:
                self.logger.warning(f'{status} Error occured!')
                raise LLMExceptionWithRetry(max_retry_attempts=self.global_retry_max_attempts, outcome=reason, error_number=status)
            else:
                raise LLMException(outcome=reason, error_number=status)
        except Timeout:
            self.logger.warning('Timeout Error occured!')
            raise LLMExceptionWithRetry(max_retry_attempts=self.timeout_retry_attempts,
                                        outcome=f'Reached Timeout of {self.llm_api_timeout}s',
                                        error_number=-1)


    def handle_retry(self, error_outcome: str, attempt: int, max_attempts: int, wait_time: int):
        """Handles response errors by logging the error, waiting, and raising an exception if the maximum number of attempts is reached.

        Args:
            error_outcome (str): The error number of the response error.
            attempt (int): The current attempt number.
            max_attempts (int): The maximum number of attempts allowed.
            wait_time (int): The waiting time in seconds between attempts.

        Raises:
            LLMException: If the maximum number of attempts is reached.
        """
        if attempt < max_attempts:
            self.logger.info(f"Error Received: {error_outcome}. Waiting {wait_time} sec (attempt {attempt}/{max_attempts})")
            time.sleep(wait_time)
        else:
            raise LLMException(outcome=f"Exceeded max retry attempts: {max_attempts}. {error_outcome}")


    def get_responses(self, prompts: dict[str, List[str]], model: str) -> dict[str, str]:
        """Posts a request to the LLM API for each prompt in prompts. Returns the response as a dictionary

        Args:
            prompts (list[str]): keys are identifiers (e.g. filename), values are prompts

        Returns:
            dict[str, str]: keys are identifiers from prompts, values are dict responses from LLM
        """
        old_model = self.deployment_id
        if model: # Set model ID if specified for this prompt
            self.logger.info(f"Setting model to {model}")
            self.deployment_id = model

        responses = {}
        for key, prompt_thread in prompts.items():
            response = self.process_prompt_thread(key, prompt_thread)
            if response:
                responses[key] = response
            self.debug['Responses'].append({key: response})

        self.deployment_id = old_model # Reset model to default
        return responses

    def get_response(self, filename:str, prompt: str, messages: Optional[List[Dict[str, str]]] = None) -> str:
        if not self.is_prompt_valid(prompt):
            return ""
        response = self.get_llm_response(prompt, messages)
        return response


    def get_llm_response(self, prompt: str, messages: Optional[List[Dict[str, str]]] = None) -> str:
        """Returns a response for a prompt, as provided by the LLM.
        Executes retry logic if rate limit is reached.

        Args:
            prompt (str): prompt for LLM to generate answer
            messages (Optional[List[Dict[str, str]]]): optional parameter for additional messages

        Returns:
            str: response str from LLM with relevant info
        """
        body = self.llm_parameters
        if messages is not None:
            body["messages"] = messages
        else:
            body["messages"] = [self.add_single_prompt(prompt)]
        global_max_attempts = self.global_retry_max_attempts # never exceed this number of attempts
        wait_time = self.retry_wait_time_sec

        response = ''
        for attempt in range(1, global_max_attempts + 1):
            try:
                response_raw = self.call_llm_api(body=body)
                response = self.get_valid_response(response_raw)
                break
            except LLMExceptionWithRetry as e:
                self.handle_retry(e.outcome, attempt, e.max_attempts, wait_time)
            except Exception as e:
                self.logger.error(f"LLM Error: {e}. Continue to the next prompt... ")
                break
        return response


    @abstractmethod
    def add_single_prompt(self, prompt: str) -> Dict[str, str]:
        """Returns the dictionary object to be used when messages is not provided for get_llm_response. required due to different
        role names between models

        Args:
            prompt (str): prompt for LLM to generate answer

        Returns:
            Dict[str, str]: dictionary object to be used when messages is not provided
        """
        pass


    @abstractmethod
    def process_prompt_thread(self, key: str, prompt_thread: List[str]) -> str:
        pass


    @abstractmethod
    def update_usage_counters(self, response : dict, elapsed_in_ms:int) -> None:
        ...


    @abstractmethod
    def get_valid_response(self, response: dict) -> str:
        pass

