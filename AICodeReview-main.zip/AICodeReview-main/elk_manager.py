from datetime import datetime
from elk import elastic_bulk_index
from elk import query_elk
from pr_info import PrInfo
from elasticsearch_dsl import Q
import json

class ElkManager:
    """
    ElkManager is a class for logging API usage information to Elasticsearch.

    Usage:
        elk_manager = ElkManager()
        elk_manager.log_api_usage(repo, pr_url, num_github_api_calls, num_llm_api_calls, num_total_llm_tokens, avg_llm_time_in_ms)
    """
    def __init__(self):
        """
        Initialize ElkManager with the current timestamp as the program start time.
        """
        self.program_start_time = datetime.utcnow()


    def write_comment_data(self, data: list[str]) -> None:
        """Writes comment data to Elasticsearch.

        Args:
            data (list[str]): data to write
        """
        if len(data) < 12:
            self.logger.debug('Write comment data to ELK called with wrong arguments')
            return

        COMMENT_ID, OWNER, REPOSITORY, PR_NUMBER, AUTHOR_ID, COMMIT_ID, ISSUE_TYPE, COMMENT_URL, SIGNIFICANCE, CONFIDENCE, CATEGORY, COMMENT_BODY, BASE_BRANCH = range(13)

        json_message = {
            "comment_id": data[COMMENT_ID],
            "program_start_timestamp": self.program_start_time.isoformat(),
            "owner": data[OWNER],
            "repository": data[REPOSITORY],
            "pr_number": int(data[PR_NUMBER]),
            "author_id": data[AUTHOR_ID],
            "commit_id": data[COMMIT_ID],
            "issue_type": data[ISSUE_TYPE],
            "comment_url": data[COMMENT_URL],
            "significance": float(data[SIGNIFICANCE]),
            "confidence": float(data[CONFIDENCE]),
            "category": data[CATEGORY],
            "comment_body": data[COMMENT_BODY] if len(data) > COMMENT_BODY else None,
            "base_branch": data[BASE_BRANCH],
            "is_merged": 'false'
        }
        index_name = "ai_comment_data"
        elastic_bulk_index(index_name, [json_message])

    def log_api_usage(self, repo: str, pr_url:str, num_github_api_calls:int, num_llm_api_calls:int, num_total_llm_tokens:int, avg_llm_time_in_ms:int,  num_files:int) -> None:
        """
        Log API usage information to Elasticsearch.
        :param repo: Repository name
        :param pr_url: Pull request URL
        :param num_github_api_calls: Number of GitHub API calls
        :param num_llm_api_calls: Number of LLM API calls
        :param num_total_llm_tokens: Total number of LLM tokens
        :param avg_llm_time_in_ms: Average LLM time in milliseconds
        :param num_files: Number of files in the PR
        """
        json_message = {
            "repository": repo,
            "pr_url": pr_url,
            "num_github_api_calls": num_github_api_calls,
            "num_files": num_files,
            "num_llm_api_calls": num_llm_api_calls,
            "num_llm_total_tokens": num_total_llm_tokens,
            "avg_llm_call_in_s": float(avg_llm_time_in_ms),  # Store the value as a float
            "program_start_timestamp": self.program_start_time.isoformat()  # Convert datetime to string
        }
        json_message_list = [json_message]
        index_name = "ai_api_usage"
        elastic_bulk_index(index_name, json_message_list)

    def read_latest_comment_data_by_pr(self, owner: str, repository: str, pr_number: int, single_comment=True) -> list[dict[str,str]]:
        """Return data from the latest comment posted on a PR defined by owner, repository and pr_number

        Args:
            owner (str): owner of the PR
            repository (str): repository of the PR
            pr_number (str): number of the PR
            single_comment (bool, True): if True, returns the single latest comment. Otherwise, returns all posted comments

        Returns:
            dict[str,str]: the data of the latest comment
        """
        # Create a query to match the owner, repository, and pr_number
        query = Q("bool",
                  must=[Q("match", msg__owner=owner),
                        Q("match", msg__repository=repository),
                        Q("match", msg__pr_number=pr_number)])

        # Convert the Q object to a dictionary
        query_dict = query.to_dict()

        # Query Elasticsearch
        response = query_elk("ai_comment_data", query_dict, sort={"@timestamp": {"order": "desc"}}, size=1)

        # Parse the response to a list of dictionaries
        result = [{'_id': hit.meta.id, **hit.to_dict()} for hit in response]

        # Define the mapping of old names to new names
        rename_dict = {
            'msg.issue_type': 'issue_type',
            'msg.owner': 'owner',
            'msg.repository': 'repository',
            'msg.comment_id': 'comment_id',
            'msg.pr_number': 'pr_number',
            'msg.commit_id': 'commit_id',
            'msg.author_id': 'author_id',
            'msg.comment_url': 'comment_url',
            'msg.significance': 'significance',
            'msg.confidence': 'confidence',
            'msg.category': 'category',
            'msg.comment_body': 'comment_body'
        }

        # Create a new list to store the renamed dictionaries
        renamed_result = []

        # Loop over each dictionary in the result list
        for item in result:
            renamed_dict = {new_key: item.get(old_key) for old_key, new_key in rename_dict.items()}
            renamed_dict.update({key: value for key, value in item.items() if key not in rename_dict})
            renamed_result.append(renamed_dict)

        return renamed_result

    def log_exception(self, e: Exception, pr_info: PrInfo, pr_url: str) -> None:
        """
        Log exception information to Elasticsearch.
        :param e: The exception that was raised
        :param pr_info: Pull request information
        :param pr_url: Pull request URL
        """
        owner = None
        repo = None
        pr_num = 0
        exc_type = None
        exc_err_num = -1
        exc_desc = None

        if pr_info is not None and pr_info.is_initialized():
            owner = pr_info.get_owner()
            repo = pr_info.get_repository()
            pr_num = pr_info.get_pr_number()

        if hasattr(e, 'exception_type'):
            exc_type = e.exception_type
        if hasattr(e, 'error_number') and e.error_number is not None:
            exc_err_num = e.error_number
        if hasattr(e, 'outcome'):
            exc_desc = e.outcome

        json_message = {
            "owner": owner,
            "repository": repo,
            "pr_number": pr_num,
            "pr_url": pr_url,
            "exception_type": exc_type,
            "error_number": exc_err_num,
            "exception_description": exc_desc,
            "log_timestamp": self.program_start_time.isoformat()  # Assuming program_start_time is available
        }
        json_message_list = [json_message]
        index_name = "ai_exception_logging"
        elastic_bulk_index(index_name, json_message_list)