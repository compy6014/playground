from typing import Dict, List, Optional
from query_engine import QueryEngine
from exceptions import LLMExceptionWithRetry
from logger import get_module_logger

class GeminiManager(QueryEngine):
    """Class that manages interaction with OpenAI.
    """

    def __init__(self, llm_manager_settings: dict, llm_token:str) -> None:
        super().__init__(llm_manager_settings, llm_token)


    def process_prompt_thread(self, key: str, prompt_thread: List[str]) -> str:
        messages = [
            {"author": "system", "content": "You are a helpful assistant that provides actionable code reviews."}
        ]
        response = ''
        for prompt in prompt_thread:
            messages += [{"author": "user", "content": prompt}]
            response = self.get_response(key, prompt, messages)

            if not response:
                break
            messages += [{"author": "assistant", "content": response}]
        return response


    def get_valid_response(self, response: dict) -> str:
        """Return whether the input prompt is valid or not.
        Args:
            response (dict): an llm response dict
        Returns:
            str: Response text from LLM. Empty string if not valid
        """
        if not self.is_response_structure_valid(response):
            return ''

        candidate = response['candidates'][0]
        text = candidate['content']['parts'][0]['text']
        if not self.is_text_valid(text, 'LLM Response'):
            raise LLMExceptionWithRetry(max_retry_attempts=self.invalid_text_retry_attempts,
                                        outcome=f'Invalid Text. Retrying {self.invalid_text_retry_attempts} times',
                                        error_number=-1)

        # add check for finish reason
        if candidate['finishReason'] != 'STOP':
            self.logger.warning('LLM stopped processing due to: {}'.format(candidate['finishReason']))
            return ''

        return text


    def update_usage_counters(self, response: Dict, elapsed_in_ms: int) -> None:
        """Update usage counters with the response metadata."""
        usage = response["usageMetadata"]
        self.num_prompt_tokens += usage["promptTokenCount"]
        self.num_total_tokens += usage["totalTokenCount"]
        self.num_llm_api_calls_success += 1
        self.total_llm_time_in_ms += elapsed_in_ms
        self.logger.info(f"Usage: {usage}")


    def is_response_structure_valid(self, response: dict) -> bool:
        """Return whether the response dict structure is valid or not.

        Args:
            response (dict): response from LLM

        Returns:
            bool: True if valid, False otherwise.
        """
        if not response:
            self.logger.warning("LLM response is empty.")
            return False

        candidates = response.get("candidates")
        if not candidates:
            self.logger.warning("LLM response does not contain expected keys")
            return False

        candidate = candidates[0]
        message_content = candidate.get("content", {}).get("parts")[0].get("text")
        finish_reason = candidate.get("finishReason")

        if not (message_content and finish_reason):
            self.logger.warning("LLM response does not contain expected keys")
            return False
        return True


    def add_single_prompt(self, prompt: str) -> Dict[str, str]:
        """Returns the dictionary object to be used when messages is not provided for get_llm_response. required due to different
        role names between models

        Args:
            prompt (str): prompt for LLM to generate answer

        Returns:
            Dict[str, str]: dictionary object to be used when messages is not provided
        """
        return {"author": "user", "content": prompt}
