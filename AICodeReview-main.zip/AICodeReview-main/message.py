from exceptions import CommonException

class Message():
    """Class that stores message-like data as an object
    """

    def __init__(self, **kwargs) -> None:
        if len(kwargs) < 1:
            raise CommonException(f'No message data to load!')

        for key, value in kwargs.items():
            setattr(self, key, value)

    def get_text(self) -> str:
        """Return the text contained within this instance

        Returns:
            str: text for this instance
        """
        return getattr(self, 'text', '')


    def set_text(self, updated_text):
        setattr(self, 'text', updated_text)


    def get_comment_type(self) -> str:
        """Return the type of comment contained within this instance

        Returns:
            str: type of this instance
        """
        return getattr(self, 'comment_type', '')


    def get_short_name(self) -> str:
        """Returns the short name associated with this message

        Returns:
            str: short name
        """
        return getattr(self, 'short_name', 'unknown_name')


    def get_exit_issue_level(self) -> int:
        """Returns the exit level associated with this message

        Returns:
            int: exit issue
        """
        return int(getattr(self, 'exit_issue_level', -1))
