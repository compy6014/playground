
class PRReviewerBaseException(Exception):
    def __init__(self, exception_type, error_number=None, outcome=None, url=None):
        self.error_number = error_number
        self.outcome = outcome
        self.url = url
        self.exception_type = exception_type

    def __str__(self):
        result = f"{self.exception_type} Exception"
        if self.error_number is not None:
            result += f" Code: {self.error_number}"
        if self.url is not None:
            result += f", URL: {self.url}"
        if self.outcome is not None:
            result += f". {self.outcome}"
        return result

class LLMException(PRReviewerBaseException):
    def __init__(self, outcome, error_number=None):
        super().__init__(exception_type="LLM", error_number=error_number, outcome=outcome)

class LLMExceptionWithRetry(LLMException):
    def __init__(self, max_retry_attempts, outcome, error_number=None):
        self.max_attempts = max_retry_attempts
        super().__init__(outcome=outcome, error_number=error_number)

class GitHubException(PRReviewerBaseException):
    def __init__(self, error_number, outcome):
        super().__init__(exception_type="GitHub", error_number=error_number, outcome=outcome)

class URLException(PRReviewerBaseException):
    def __init__(self, url, error_number, outcome=''):
        super().__init__(exception_type="URL", error_number=error_number, outcome=outcome, url=url)

class CommonException(PRReviewerBaseException):
    def __init__(self, outcome):
        super().__init__(exception_type="Common", outcome=outcome)

class IOException(PRReviewerBaseException):
    def __init__(self, outcome):
        super().__init__(exception_type="IO", outcome=outcome)

class DBException(PRReviewerBaseException):
    def __init__(self, error_code, outcome):
        super().__init__(exception_type="DB", error_number=error_code, outcome=outcome)
