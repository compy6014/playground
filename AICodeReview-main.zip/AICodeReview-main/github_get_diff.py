import json
import os, subprocess
import re
import base64
from datetime import datetime
from exceptions import CommonException
from logger import get_module_logger
from database import DatabaseManager
from elk_manager import ElkManager
from github_api import GithubAPI
from pr_info import PrInfo


class GithubGetDiff():
    """Class that retrieves and prepares diffs from GitHub.
    """

    def __init__(self,
                 get_diff_settings: dict,
                 github_api: GithubAPI,
                 pr_info: PrInfo,
                 whitelist_file: str,
                 force_full_diff: bool,
                 db: ElkManager) -> None:

        self.logger              = get_module_logger(get_diff_settings["logger_name"])
        self.max_diff_characters = get_diff_settings["max_diff_characters"]
        self.github_username     = get_diff_settings["github_username"]
        self.db                  = db

        if pr_info is None or not isinstance(pr_info, PrInfo) or not pr_info.is_initialized():
            raise CommonException("pr_info must be non-None and an instance of PrInfo")
        self.pr_info             = pr_info

        if github_api is None or not isinstance(github_api, GithubAPI):
            raise CommonException("github_api must be non-None and an instance of GithubAPI")
        self.github_api = github_api

        self.read_whitelist_file(whitelist_file)
        self.force_full_diff = force_full_diff


# Diff Retrieval Code:

    def read_whitelist_file(self, whitelist_file: str) -> None:
        """Reads and stores whitelist file from a JSON fil as a dictionary containing the whitelist information.

        Args:
            whitelist_file (str): The path to the JSON file containing the whitelist file.
        """
        self.logger.info(f'Reading whitelist data from {whitelist_file}...')
        with open(whitelist_file, 'r') as f:
            whitelist_file = json.load(f)
        self.whitelist = whitelist_file


    def is_whitelisted(self, diff_file_path: str) -> bool:
        """Checks if the file extension of the given filename is in the whitelist.

        Args:
            diff_file_path (str): The name of the file to check.

        Returns:
            bool: True if the file extension is in the whitelist, otherwise False.
        """
        # Get the file extension
        _, extension = os.path.splitext(diff_file_path)
        extension = extension.lower()
        filename = os.path.basename(diff_file_path).lower()

        # Check if the extension or diff_file_path is in the whitelist
        for item in self.whitelist:
            extension_match = item['type'] == 'extension' and item['value'] == extension
            name_match = item['type'] == 'filename' and item['value'] == filename
            if extension_match or name_match:
                return True
        return False


    def git_notation_intersection(self, hunk_notation_1:str, hunk_notation_2:str) -> bool:
        """
        This method checks if there is an intersection between two hunk notations.
        It first extracts the start and range values from the hunk notations.
        Then it calculates the end lines for each hunk notation.

        :param hunk_notation_1: str, A string representing the first hunk notation (e.g. "@@ -121,10 +121,7 @@")
        :param hunk_notation_2: str, A string representing the second hunk notation (e.g. "@@ -67,40 +66,82 @@")

        :return: bool, True if there is an intersection between the two hunk notations; False otherwise.
        """

        # Extract start and range values from the strings
        start1, range1 = [int(x) for x in hunk_notation_1.split(' ')[2].split('+')[1].split(',')]
        start2, range2 = [int(x) for x in hunk_notation_2.split(' ')[2].split('+')[1].split(',')]

        # Calculate end lines
        end1 = start1 + range1
        end2 = start2 + range2

        # Check if there is an intersection between the two ranges
        is_intersection = max(start1, start2) <= min(end1, end2)
        return is_intersection


    def intersect_diffs(self, diff1: str, diff2: str) -> str:
        """Finds the intersection of two diffs.
        Args:
            diff1 (str): The first diff to compare.
            diff2 (str): The second diff to compare.

        Returns:
            str: The intersected diff.
        """
        hunks1 = re.findall(r'@@ -\d+,\d+ \+\d+,\d+ @@', diff1)
        hunks2 = re.findall(r'@@ -\d+,\d+ \+\d+,\d+ @@', diff2)

        hunk_dict1 = {hunk: diff1.split(hunk, 1)[1].split('@@', 1)[0] for hunk in hunks1}
        hunk_dict2 = {hunk: diff2.split(hunk, 1)[1].split('@@', 1)[0] for hunk in hunks2}

        common_start = diff1[:diff1.find('@@')]

        result = common_start
        for hunk1 in hunk_dict1:
            for hunk2 in hunk_dict2:
                if self.git_notation_intersection(hunk1, hunk2):
                    result += '\n' + hunk1 + hunk_dict1[hunk1]

        if result == common_start:      # no shared code
            return ''
        else:
            return result.strip()


    def combine_diffs_by_intersection(self, full_diff: dict[str, str], compare_diff: dict[str, str]) -> dict[str, str]:
        """Combines two diffs by intersection.
        Args:
            full_diff (dict[str, str]): The full diff to compare.
            compare_diff (dict[str, str]): The diff to compare against.

        Returns:
            dict[str, str]: The combined intersected diff.
        """
        intersection_diff = {}
        for key in compare_diff.keys():
            if key in full_diff:                                    # same file
                if full_diff[key] == compare_diff[key]:             # same diff means a full file was changed by the current user
                    intersection_diff[key] = compare_diff[key]
                else:                                               # same file but atg-dev and the current PR changed it
                    intersection_diff_str = self.intersect_diffs(compare_diff[key], full_diff[key])
                    if intersection_diff_str:
                        intersection_diff[key] = intersection_diff_str
        self.logger.info(f'Diff intersects in: {len(intersection_diff.keys())} files')
        return intersection_diff


    def get_diffs(self, diff_type: str) -> dict[str, str]:
        """Returns a dict of diffs based on the diff_type.
        If use_only_added_code is True, then only provide added code (lines with '+' signs) from the diff.
        Otherwise, return the full diff.

        Args:
            diff_type (str): can be file, hunk or entire_pr

        Returns:
            dict[str, str]: keys are identifiers (e.g. filename), values are the code diffs
        """
        diff_url = self.get_diff_url()
        if not diff_url:
            return {}
        self.diff_url = diff_url
        pr_diff = self.github_api.get_diffs(diff_url)
        if pr_diff is None or not isinstance(pr_diff, str):
            raise CommonException("get_diffs did not receive data from github call")
        diffs = self.prepare_diffs(diff_type, pr_diff)

        pr_was_updated  = self.pr_info.get_pr_url_diff() != diff_url   # Check if the PR was updated by comparing the full diff URL with the diff URL
        if pr_was_updated:
            pr_full_diff = self.github_api.get_diffs(self.pr_info.get_pr_url_diff())
            prepared_diff = self.prepare_diffs(diff_type, pr_full_diff)
            intersection_diffs = self.combine_diffs_by_intersection(prepared_diff, diffs)
            return intersection_diffs
        return diffs

    def get_full_files(self) -> dict[str, str]:
        """Returns a dict of file contents for each file in the PR.

        Returns:
            dict[str, str]: keys are identifiers (e.g. filename), values are the code diffs
        """
        response_text = self.github_api.get_url(self.pr_info.get_pr_url_files())
        files = json.loads(response_text)

        file_contents = {}
        for file in files:
            file_url = file['contents_url']
            file_response = self.github_api.get_url(file_url)
            file_content = base64.b64decode(json.loads(file_response)['content']).decode('utf-8')
            file_contents[file['filename']] = file_content

        return file_contents


    def get_full_base_files(self) -> dict[str, str]:
        """Returns a dict of file contents for each file in the PR from the *base* commit, i.e prior to changes.

        Returns:
            dict[str, str]: keys are identifiers (e.g. filename), values are the code diffs
        """
        base_commit_sha = self.pr_info.get_pr_base_commit_id()
        response_text = self.github_api.get_url(self.pr_info.get_pr_url_files())
        files = json.loads(response_text)

        file_contents = {}
        for file in files:
            # Find the start of 'ref='
            start = file['contents_url'].find('ref=') + 4

            # Find the end of the ref value (which is the start of the next parameter or the end of the string)
            end = file['contents_url'].find('&', start)
            if end == -1:
                end = len(file['contents_url'])

            # Replace the old ref value with the new one
            file_url = file['contents_url'][:start] + base_commit_sha + file['contents_url'][end:]
            try: # try/catch, as for example new files will not exist in base commit. For these cases, we cannot provide file context.
                file_response = self.github_api.get_url(file_url)
                file_content = base64.b64decode(json.loads(file_response)['content']).decode('utf-8')
                file_contents[file['filename']] = file_content
            except Exception as e:
                self.logger.warning(f"Error getting file content for {file['filename']}: {e}")
                file_contents[file['filename']] = ''

        return file_contents


    def get_function_contexts(self, full_files, full_base_files) -> dict[str, str]:
        """Returns a dict of function contexts using the -W flag of git diff between
        the current commit and base commit of a file.
        """
        result = {}
        for filename in full_files:
            if full_base_files[filename] == '':
                result[filename] = full_files[filename]
            else:
                base_file_path = f'{os.path.basename(filename)}_base'
                full_file_path = f'{os.path.basename(filename)}_full'
    
                # Specify UTF-8 encoding to avoid Unicode errors
                with open(base_file_path, 'w', encoding='utf-8') as base_file:
                    base_file.write(full_base_files[filename])
                with open(full_file_path, 'w', encoding='utf-8') as full_file:
                    full_file.write(full_files[filename])
    
                git_diff_command = ['git', 'diff', '-W', '--no-index', base_file_path, full_file_path]
                git_diff_output = subprocess.run(git_diff_command, capture_output=True, text=True).stdout
                result[filename] = self.clean_single_diff(git_diff_output)
    
                os.remove(base_file_path)
                os.remove(full_file_path)
    
        return result


    def get_diff_url(self) -> str:
        """Returns a URL that contains a diff.
        This can be the default PR diff or it can be based on the last comment made by the AI Reviewer

        Returns:
            str: URL to a diff
        """
        diff_file_url = self.pr_info.get_pr_url_diff()
        if self.force_full_diff:
            return diff_file_url
        try:
            last_ai_comment_commit_id = self.find_last_ai_comment_commit_id()

            if last_ai_comment_commit_id is None:   # No previous AI comments found, Using a default diff
                self.logger.info(f"No previous AI comments found, using default diff URL: {diff_file_url}")
                return diff_file_url

            if last_ai_comment_commit_id == self.pr_info.get_pr_commit_id():   # No diff since he last AI comment
                self.logger.info("No diff since the last AI comment")
                return None
            else:
                diff_file_url = re.sub(r'pulls/\d+', 'compare', self.pr_info.get_pr_url_api())
                diff_file_url = diff_file_url + '/' + last_ai_comment_commit_id + "..." + self.pr_info.get_pr_commit_id()
                self.logger.info(f"Created Diff URL: {diff_file_url}")
        except Exception as e:
            self.logger.warning(f"Error in finding the closest commit. Working on full diff. Error: {e}")
        return diff_file_url


    def get_commits(self):
        """Retrieves the commits from the PR."""
        commits_url = f"{self.pr_info.get_pr_url_api()}/commits"
        response_text = self.github_api.get_url(commits_url)
        if response_text is None or not isinstance(response_text, str):
            raise CommonException("Error retrieving commits from github")
        return json.loads(response_text)


    def get_closest_commit(self, commits: list[dict], last_comment_time: str):
        """Finds the commit that is closest to the last comment time."""
        the_closest_to_ai_comment_commit = None
        closest_commit_timestamp = None
        for commit in commits:
            commit_timestamp = commit['commit']['committer']['date']
            commit_timestamp = datetime.strptime(commit_timestamp, '%Y-%m-%dT%H:%M:%SZ')
            last_comment_time = datetime.strptime(last_comment_time, '%Y-%m-%dT%H:%M:%SZ')
            if commit_timestamp <= last_comment_time:
                if closest_commit_timestamp is None or commit_timestamp > closest_commit_timestamp:
                    the_closest_to_ai_comment_commit = commit
                    closest_commit_timestamp = commit_timestamp
        return the_closest_to_ai_comment_commit


    def get_last_comment_commit_id_from_github(self) -> str:
        """Computes the commit id based on the last time the AI Reviewer commented."""
        last_comment_time = self.find_last_ai_comment_time_()
        commits = self.get_commits()
        closest_commit = self.get_closest_commit(commits, last_comment_time)
        if closest_commit is None:
            return None
        return closest_commit['sha']


    def get_last_comment_commit_id_from_database(self) -> str:
        """Retrieves the commit id from the latest comment made on the current PR

        Returns:
            str: commit id of the latest comment
        """
        latest_comment = self.db.read_latest_comment_data_by_pr(self.pr_info.get_owner(),
                                                                self.pr_info.get_repository(),
                                                                self.pr_info.get_pr_number())
        if latest_comment and latest_comment[0]:
            commit_id = latest_comment[0]['commit_id']
            return commit_id
        return None


    def find_last_ai_comment_commit_id(self) -> str:
        """Returns the commit id of the last time the AI Reviewer commented

        Raises:
            GitHubException: Raised when failing to get commits

        Returns:
            str: commit id
        """
        try:
            self.logger.info('Retrieving latest comment data from database...')
            return self.get_last_comment_commit_id_from_database()
        except Exception as e:
            self.logger.warning(f'Failed to retrieve data from database: {e}. Attempting to get commits from Github.')
            return self.get_last_comment_commit_id_from_github()


    def find_last_ai_comment_time_(self) -> str:
        """Returns the time when the AI Reviewer commented last

        Raises:
            GitHubException: Raised when failing to get comments

        Returns:
            str: timestamp
        """
        comment_url = self.pr_info.get_pr_url_api().replace('pulls', 'issues') + '/comments'
        comments = self.github_api.get_comments(comment_url)
        if comments is None:
            raise CommonException("Error getting previous comments")
        ai_comments = []
        for comment in comments:
            if "AI Bot Analysis" in comment["body"] and comment['user']['login'] == self.github_username:
                ai_comments.append(comment)

        if ai_comments:
            # Find the comment with the latest update time
            most_updated_comment = None
            for comment in ai_comments:
                if most_updated_comment is None or comment["created_at"] > most_updated_comment["created_at"]:
                    most_updated_comment = comment

            # Return the commit ID of the most updated comment
            return most_updated_comment["created_at"]
        else:
            return None

    def clean_single_diff(self, diff: str) -> str:
        """Cleans up a single diff by removing hunk info and removed lines.

        Args:
            diff (str): The diff to clean.

        Returns:
            str: The cleaned diff.
        """
        code_start_index = diff.find('@@', diff.find('@@') + 1) + 2 #remove git diff header
        code_string = diff[code_start_index:]
        lines = code_string.split('\n')
        cleaned_lines = [line[1:] if line.startswith('+') else line for line in lines if not line.startswith('-')]
        return '\n'.join(cleaned_lines)

    def prepare_diffs(self, diff_type: str, pr_diff: str) -> dict[str, str]:
        """Prepares a dictionary of diffs

        Args:
            diff_type (str): one of 'entire_pr', 'hunk' or 'file' (most used)
            pr_diff (str): the diff of the given pr

        Returns:
            dict[str, str]: keys are identifiers (e.g. filename), values are diff
        """
        diffs = {}
        if diff_type == 'entire_pr':
            return {f'{self.pr_info.repository}/{self.pr_info.pr_number}': pr_diff}
        for diff in pr_diff.split('diff --git ')[1:]: # always ignore first element since its empty
            filename = self.is_diff_valid(diff)
            if not filename:
                continue
            if diff_type == 'file':  # split up the diffs in the PR by file
                diffs[filename] = diff
        return diffs


    def is_diff_valid(self, diff: str) -> str:
        """Return whether the input diff is valid or not.

        Args:
            diff (str): diff to evaluate

        Returns:
            str: Return filename if the diff is valid, False otherwise
        """
        if len(diff) == 0:
            self.logger.info(f"Diff is empty!")
            return False
        filename = self.extract_name_from_diff(diff)
        if not self.is_whitelisted(filename):
            self.logger.info(f"File {filename} is not in the whitelist.")
            return False
        if len(diff) >= self.max_diff_characters:
            self.logger.warning(f"File {filename} is too large: {len(diff)}. Max size: {self.max_diff_characters}.")
            return False
        if 'deleted file mode' in diff:
            self.logger.info(f"Deleted file in diff.")
            return False
        return filename


    def extract_name_from_diff(self, diff: str) -> str:
        """Returns the filename corresponding to the input diff
        Args:
            diff (str): raw unified diff

        Returns:
            str: filename
        """
        filename_pattern = re.compile(r'a/(.+?) b/')
        match = filename_pattern.search(diff)
        if match:
            return match.group(1)
        else:
            self.logger.warning('Can not extract name from diff')
            return "UnknownFile"

