import re
from logger import get_module_logger
from exceptions import GitHubException
from comment import Comment
from query import Query
import json

class CommentManager():
    """Class that prepares comments from responses sent by an LLM
    """


    def __init__(self, comment_mngr_settings: dict) -> None:
        self.logger = get_module_logger(comment_mngr_settings["logger_name"])
        self.lines_threshold_for_review_comment = comment_mngr_settings["lines_threshold_for_review_comment"]
        self.category_ignore_list               = self.get_comment_ignore_list_from_config('category_ignore_list.json')


    def create_comments(self, query: Query, llm_responses: dict[str, str]) -> list[Comment]:
        """Prepares a list of comments based on the llm_response and the given query

        Args:
            query (Query): the query which contains expected flags
            llm_responses (dict[str, str]): the response dict from an llm

        Returns:
            list[Comment]: a list of comment objects to be posted on Github
        """
        comment_list = []
        if len(llm_responses) == 0:
            return comment_list
        if query.get_comment_type() == 'conversation': # expect single description comment
            comment = self.create_conversation_comment(query, llm_responses)
            comment_list.append(comment)
        if query.get_comment_type() == 'review': # expect multiple review comments (for each file)
            comments = self.create_review_comment(query, llm_responses, self.category_ignore_list)
            comment_list.extend(comments)
        return comment_list


    def update_comment_text(self, query: Query, comments: list[Comment]) -> None:
        """
        Updates the text of each comment based on the comment type specified in the query.
        If the comment type is 'review', the significance and confidence scores are added to the comment text.
        The updated comment text includes the query's response header, original or modified comment text,
        and the query's response footer.

        Args:
            query (Query): An instance of the Query class containing comment type,
                        response header, and response footer.
            comments (list[Comment]): A list of .
        Returns:
            None. The function modifies the list of 'comments' instances in-place.
        """
        if query.get_comment_type() == 'conversation':
            comment = comments[0]
            txt = comment.get_text()
            txt = f"{query.get_response_header()}\n\n{txt}"
            comment.set_text(txt)

        elif query.get_comment_type() == 'review':
            for comment in comments:
                self.update_review_comment_text(query, comment)


    def update_review_comment_text(self, query: Query, comment: Comment) -> None:
        """Updates the text of a given comment using the corresponding query.

        Args:
            query (Query): An instance of the Query class containing comment type,
                        response header, and response footer.
            comment (Comment): Comment instance to be updated
        """
        txt = comment.get_text()
        txt += '\n'
        significance = int(comment.get_significance_score())
        if significance != 0:
            txt += f'Significance: {significance}/10\n'
        txt += f'Confidence: {int(comment.get_confidence_score())}/10\n'
        txt = f"{query.get_response_header()}\n\n{txt}\n\n{query.get_response_footer()}"
        txt = f'### {comment.get_category()}\n<details><summary>Click for details</summary>\n\n{txt}</details>'
        comment.set_text(txt)


    def create_conversation_comment(self, query: Query, llm_responses: dict[str, str]) -> Comment:
        """Prepares a single comment to be posted as a conversation, by concatenating the text over each llm response.

        Args:
            query (Query): the Query for which the comment is constructe
            llm_responses (dict[str, str]): the response dict from an llm

        Returns:
            Comment: a Comment object to be posted on GitHub
        """
        comment_text = ''
        for key, text in llm_responses.items():
            if key == 'post_process_description':
                comment_text = text + '\n'
            else:
                comment_text += f'{key}:\n{text}\n\n'

        comment_dict = {'text': comment_text,
                        'comment_type': query.get_comment_type(),
                        'short_name': query.get_short_name()
                        }
        return Comment(**comment_dict)


    def create_comment_dict(self, issue_hunk: str, issue_text: str, position: int, filename: str, confidence_score: float, category: str, query: Query):
        """
        Create a comment dictionary based on the given parameters.
        Args:
            issue_hunk (str): The hunk associated with the issue.
            issue_text (str): The text describing the issue.
            position (int): Position in the diff where the issue is found.
            filename (str): The filename where the issue is found.
            category (str): A short category for this issue.
            query: An object containing methods to get comment type and short name.
        Returns:
            dict: A comment dictionary containing the inputs
        """
        start_line, num_lines = self.extract_line_numbers(issue_hunk, position)
        comment_dict = {
                        'text': issue_text,
                        'comment_type': query.get_comment_type(),
                        'start_line': start_line,
                        'num_lines': num_lines,
                        'position': position,
                        'filename': filename,
                        'category': category,
                        'confidence_score': confidence_score,
                        'short_name': query.get_short_name()
                        }
        return comment_dict

    def parse_keyword(self, comment_text: str, keyword: str):
        pattern = rf"\n{keyword}:\s([^\n]+)"
        match = re.search(pattern, comment_text)

        if match:
            data = match.group(1)
            updated_text = re.sub(pattern, " ", comment_text)
        else:
            # Default value as an empty string
            data = ""
            updated_text = comment_text

        return data, updated_text


    def create_review_comment(self, query: Query, llm_responses: dict[str, str], filter_categories: list[str] = None) -> list[Comment]:
        """Prepares a list of comments to be posted as individual review comments.

        Args:
            query (Query): the Query for which the comment is constructe
            llm_responses (dict[str, str]): the response dict from an llm
            filter_categories (list[str]): list of categories to filter comments by. If None, no filtering is done.

        Returns:
            list[Comment]: a list of Comment objects to be posted on GitHub
        """
        comments = []
        for filename, text in llm_responses.items():
            if query.get_expected_negative_flag() in text:
                continue
            confidence_score, text = self.parse_keyword(text, keyword='Confidence')
            issue_category, text = self.parse_keyword(text, 'Category')

            # Skip this comment if its category is in the filter list
            if filter_categories is not None and issue_category in filter_categories:
                continue

            start_sentence, hunk_dict = self.split_into_hunks(text)
            if start_sentence.startswith(query.get_positive_start()):   # Cut the positive start: "Yes there are issues"
                start_sentence = start_sentence[len(query.get_positive_start()):]
            position = 'RIGHT' #self.extract_change_side(text) - this is deprecated for now
            if hunk_dict:
                for issue_hunk, issue_text in hunk_dict.items():
                    if start_sentence and start_sentence != '\n':
                        issue_text = start_sentence + issue_text
                    comment_dict = self.create_comment_dict(issue_hunk, issue_text, position, filename, confidence_score, issue_category, query)
                    comments.append(Comment(**comment_dict))
            else:       #no notations found
                comment_dict = self.create_comment_dict('', start_sentence, position, filename, confidence_score, issue_category, query)
                comments.append(Comment(**comment_dict))
        return comments

    def extract_change_side(self, hunk: str) -> str:
        """ Determines the change side (LEFT or RIGHT) based on the hunk content.

        Args:
            hunk (str): A string containing either 'Addition' or 'Removal'.

        Returns:
            str: 'LEFT' if the change is 'Removal', 'RIGHT' if the change is 'Addition', or an empty string if no match is found.
        """
        match = re.search(r"(Addition|Removal)", hunk)
        if not match:
            raise GitHubException('', f'No position match found in hunk {hunk}')
        change = match.group()
        return 'LEFT' if change == 'Removal' else 'RIGHT'


    def split_into_hunks(self, text: str) -> tuple[str, dict[str, str]]:
        """
        Split the given text into hunks and create a dictionary mapping
        hunks to their cleaned comments.
        Args:
            text (str): The text to be split and processed.
        Returns:
                - The starting sentence before the first hunk.
                - A dictionary mapping hunk labels to their corresponding cleaned comments.
                Hunk labels follow the format '@@ -start1,len1 +start2,len2 @@'.
        """
        hunks = re.findall(r'Hunk @@ -\d+,\d+ \+\d+,\d+ @@', text)
        parts = re.split(r'(Hunk @@ -\d+,\d+ \+\d+,\d+ @@)', text)
        hunk_dict = {}
        current_hunk = None
        start_sentence = parts[0]
        for part in parts:
            if part in hunks:
                current_hunk = part.replace("Hunk ", "")
                if current_hunk not in hunk_dict:   # new hunk notation
                    hunk_dict[current_hunk] = ""
            elif current_hunk is not None:
                hunk_text = self.clean_comment(part)
                if hunk_dict[current_hunk]:   # already has a comment
                    hunk_dict[current_hunk] += '\n\n'
                hunk_dict[current_hunk] += hunk_text
        return start_sentence, hunk_dict

    def split_at_last_instance(self, text, split_text, len_threshold = 5):
        """
        Split the input text at the last occurrence of split_text and return both parts.
        If either of the split parts is shorter than the length threshold, it will be replaced with an empty string.

        Args:
            text (str): The text to be split.
            split_text (str): The substring at which the text will be split.
            len_threshold (int, optional): The minimum length required for both split parts. Defaults to 5.

        Returns:
            tuple[str, str]: The two parts of the text after splitting at the last occurrence of split_text.
        """
        last_index = text.rfind(split_text)
        if last_index == -1:
            return text, ""
        else:
            str1 = text[:last_index + len(split_text)]
            str2 = text[last_index + len(split_text):].lstrip(' \n\t')
            if len(str1) < len_threshold:
                str1 = ""
            if len(str2) < len_threshold:
                str2 = ""
            return str1, str2


    def extract_line_numbers(self, hunk_key: str, side: str) -> tuple[int]:
        """Returns the starting line of the hunk and the number of lines it contains,
        depending on the relevant side of the diff (left=old file, right=new file)

        Args:
            hunk_key (str): string containing hunk notation

        Returns:
            tuple(int, int): the starting line and number of lines
        """
        # Validate side input
        if side not in ['LEFT', 'RIGHT']:
            self.logger.warning(f'Side not valid: {side}. Expected either "RIGHT" or "LEFT".')
            return -1, -1

        # Check if the hunk_key format is valid
        hunk_numbers = re.findall(r'-?\d+', hunk_key)
        if len(hunk_numbers) != 4:
            self.logger.warning(f'Invalid hunk format: {hunk_key}. Extracted: {hunk_numbers}. Expected 4 numbers.')
            return -1, -1
        old_start, old_lines, new_start, new_lines = (int(num) for num in hunk_numbers)

        # Early return if hunk is too large
        if old_lines + new_lines > self.lines_threshold_for_review_comment:
            return -1, -1

        # Return the relevant side data
        if side == 'RIGHT':
            return new_start, new_lines

        return old_start, old_lines


    def clean_comment(self, text: str) -> str:
        """Removes specific hunk-related strings from the given text.

        Args:
            text (str): The input text containing hunk-related strings.
            example_output (str): The substring to remove from the text

        Returns:
            str: The cleaned text with hunk-related strings removed.
        """
        # Remove "bad" symbols at the beginning
        substrings = ["\n", ".", " ", ":"]
        while any(text.startswith(substring) for substring in substrings):
            for substring in substrings:
                if text.startswith(substring):
                    text = text[len(substring):]
        return text

    def get_comment_ignore_list_from_config(self, config_file: str) -> list[str]:
        """Reads the ignore list from a JSON configuration file.

        Args:
            config_file (str): The path to the configuration file.

        Returns:
            list[str]: The ignore list.
        """
        with open(config_file, 'r') as f:
            config = json.load(f)
        return config.get('ignore_list', [])
