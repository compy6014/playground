import json
import os
import requests
import pandas as pd
from exceptions import CommonException, GitHubException
from logger import get_module_logger
from comment import Comment
from database import DatabaseManager
from elk_manager import ElkManager
from github_api import GithubAPI
from pr_info import PrInfo


class GithubPostComment():
    """Class that manages interaction with GitHub.
    """

    def __init__(self,
                 post_comment_settings: dict,
                 github_api: GithubAPI,
                 pr_info: PrInfo,
                 db: ElkManager) -> None:

        self.logger          = get_module_logger(post_comment_settings["logger_name"])
        self.db              = db

        if pr_info is None or not isinstance(pr_info, PrInfo) or not pr_info.is_initialized():
            raise CommonException("pr_info must be non-None and an instance of PrInfo")
        self.pr_info = pr_info

        if github_api is None or not isinstance(github_api, GithubAPI):
            raise CommonException("github_api must be non-None and an instance of GithubAPI")
        self.github_api = github_api

        self.reset_debug()


    def post_comments(self, comments: list[Comment]) -> None:
        """Posts a comment to Github and if successful, logs the posted comment details to a csv

        Args:
            comment (Comment): comment to post
        """
        for comment in comments:
            comment_type = comment.get_comment_type()
            if comment_type == 'conversation':
                response = self.post_conversation_comment(comment)
            elif comment_type == 'review':
                response = self.post_review_comment_with_fallback(comment)
            else:
                raise CommonException(f'Unsupported comment_type: {comment_type}')
            if response.status_code == 201:
                self.handle_successful_comment_post(response, comment)
            else:
                self.handle_failed_comment_post(response)



    def post_review_comment_with_fallback(self, comment: Comment) -> requests.Response:
        """Attempts to post a review comment and falls back to posting a conversation comment.

        Args:
            comment (Comment): comment to post
        """
        try:
            return self.post_review_comment(comment)
        except GitHubException as e:
            self.logger.warning(f'Failed to post review comment on the hunk. Attempting to post review comment on the file. Exception caught: {e}')
            return self.post_review_comment(comment, post_on_file=True)


    def post_conversation_comment(self, comment: Comment) -> requests.Response:
        """Posts a comment to GitHub based on `url`.
        Args:
            comment (Comment): comment object
        """
        comment_body = {
            "body": self.replace_author_string(comment.get_text()),
        }
        extra_data = {'short_name': comment.get_short_name()}
        comment_url = self.pr_info.get_pr_url_api().replace('pulls', 'issues') + '/comments'
        return self.call_github_comment_api(comment_body, comment_url, extra_data)


    def create_comment_body_for_file_only(self, comment: Comment) -> dict:
        """Creates a comment body for file level comments.

        Args:
            comment (Comment): Comment object containing the comment content, file name, and commit_id.

        Returns:
            dict: A dictionary containing the necessary information for post_review_comment.
        """
        comment_body = {
            "body": self.replace_author_string(comment.get_text()),
            'commit_id': self.pr_info.get_pr_commit_id(),
            'path': comment.get_filename(),
            'subject_type': 'file'
        }
        return comment_body


    def create_comment_body_for_position(self, comment: Comment) -> dict:
        """Creates a comment body for position based comments.

        Args:
            comment (Comment): Comment object containing the comment content, file name, commit_id, and line positions.

        Returns:
            dict: A dictionary containing the necessary information for post_review_comment.
        """
        start_line, end_line = comment.get_lines()
        position = comment.get_position()
        comment_body = {
            "body": self.replace_author_string(comment.get_text()),
            'commit_id': self.pr_info.get_pr_commit_id(),
            'path': comment.get_filename(),
            'start_line': start_line,
            'line': end_line,
            'start_side': position,
            'side': position
        }
        return comment_body


    def is_valid_position(self, start_line:int, end_line:int) -> bool:
        return start_line > 0 and end_line >= 0


    def post_review_comment(self, comment: Comment, post_on_file = False) -> requests.Response:
        """Posts review comments on GitHub for each response containing detected issues.

        Args:
            comment (Comment): comment object
            post_on_file (bool, False): If True, posts review for whole file. Otherwise, posts on code
        """
        start_line, end_line = comment.get_lines()
        if self.is_valid_position(start_line, end_line) and not post_on_file:
            # we have a valid start_line and end_line:
            comment_body = self.create_comment_body_for_position(comment)
        else:
            # we don't have a start_line and end_line:
            comment_body = self.create_comment_body_for_file_only(comment)
        extra_data = {'short_name': comment.get_short_name()}
        comment_url = self.pr_info.get_pr_url_api() + '/comments'
        return self.call_github_comment_api(comment_body, comment_url, extra_data)


    def replace_author_string(self, comment: str) -> str:
        """Returns the comment string where the @author template replaced with the actual PR author

        Args:
            comment (str): comment string

        Returns:
            str: comment string with actual author
        """
        return comment.replace('@author', f'@{self.pr_info.get_pr_author_id()}')


    def call_github_comment_api(self, comment_body: dict[str, str], comment_url: str, extra_comment_data=None) -> requests.Response:
        """Posts a comment on GitHub using the provided comment_body and comment_url.

        Args:
            comment_body (dict[str, str]): A dictionary containing the comment details.
            comment_url (str): The URL where the comment should be posted.
            extra_comment_data (dict[str, str]): Optional dictionary with extra data for logging
        """
        self.logger.info(f'Trying to post comment to {comment_url} ...')
        response = self.github_api.call_github_comment(comment_url, comment_body)
        return response


    def handle_successful_comment_post(self, response: dict[str, str], comment: Comment) -> None:
        """Handles a successful comment post, extracts relevant information, logs the comment, and updates the comments file content.

        Args:
            response (dict[str, str]): A successful response object from the POST call
            comment_body (dict[str, str]): The original comment body data used for the POST call
            extra_comment_data (dict[str, str]): Optional dictionary with extra data for logging
        """
        self.logger.info('Successfully posted comment!')
        comment_data = response.json()
        comment_id = comment_data['id']
        comment_url = comment_data['html_url']
        comment_issue_type = comment.get_short_name()

        # save to debug log
        comment_details = {'Comment URL': comment_url, 'Comment ID': comment_id}
        self.debug['Comments'].append(comment_details)
        self.debug['Comments URL'] += comment_url + '\n'
        self.log_comment_to_csv(comment_issue_type, comment_id)

        # TODO category for AI Code Review - hardcoded
        category = 'AI Code Review'
        # save to ELK
        data = [
            comment_id,
            self.pr_info.get_owner(),
            self.pr_info.get_repository(),
            self.pr_info.get_pr_number(),
            self.pr_info.get_pr_author_id(),
            self.pr_info.get_pr_commit_id(),
            comment_issue_type,
            comment_url,
            comment.get_significance_score(),
            comment.get_confidence_score(),
            #comment.get_category(),
            category,
            comment.get_text(),
            self.pr_info.get_base_branch()
        ]
        self.db.write_comment_data(data)

    def reset_debug(self) -> None:
        self.debug = {"Comments": [],
                      "Comments URL": ""}

    def get_debug_info(self) -> dict[str, str]:
        """Provides a dicitonary with debug information about the PR and comment, if posted.
        Also logs any comment data to the artifactory file
        Returns:
            dict[str, str]: debug info
        """
        debug = {
                "PR URL": self.pr_info.get_pr_url_api(),
                "PR Author": self.pr_info.get_pr_author_id(),
                "PR Commit ID": self.pr_info.get_pr_commit_id(),
                "Comments": self.debug['Comments'],
                "Comments URL": self.debug['Comments URL'],
            }
        return debug


    def handle_failed_comment_post(self, response) -> None:
        raise GitHubException(response.status_code, f'{response.reason}')


    def log_comment_to_csv(self, comment_type: str, comment_id: str) -> None:
        """Save the repository name, PR number, comment ID, and comment type in a CSV file using Pandas
        Args:
            comment_type (str): either 'review' or 'issue'
            comment_id (str): comment_id generated when posting
        """
        csv_file = 'comments.csv'
        data = {
            'repository': [self.pr_info.get_repository()],
            'pull_number': [self.pr_info.get_pr_number()],
            'comment_id': [comment_id],
            'comment_type': [comment_type],
        }
        new_df = pd.DataFrame(data)
        # If the file exists, read it and append the new data, otherwise create a new file
        if os.path.exists(csv_file):
            existing_df = pd.read_csv(csv_file)
            df = pd.concat([existing_df, new_df], ignore_index=True)
        else:
            df = new_df
        df.to_csv(csv_file, index=False)
        self.logger.info(f'Logged comment data to {csv_file}')