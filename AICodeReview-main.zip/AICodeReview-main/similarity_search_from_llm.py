from openai_manager import OpenAIManager
import json
from logger import get_module_logger
import argparse

class SimilaritySearchManager():
    """ This class is responsible for managing similarity search requests to LLM.
    """

    similarity_search_prompt_text = """### CONTEXT
A test code snippet and a test code patch are provided below. It's possible that the code snippet has been altered and incorporated into the code patch.

### OBJECTIVE
Perform a fuzzy string comparison between the code snippet and the code patch, disregarding differences in leading and trailing whitespaces. If there is a substring in the code patch that shows significant similarity to the code snippet, perform the following calculations on the identified pair of similar code patch substring and code snippet:
- Compute the Levenshtein distance for the pair of strings;
- Determine the similarity percentage for the pair using the formula (1 - (Levenshtein distance / max(len(patch), len(snippet)))) * 100;
- Count the lines of code in the matched patch substring, excluding empty lines.

### OUTPUT FORMAT
For any identified matches, output the result in the following JSON format:
    {
        "snippet": <code snippet>,
        "id": id for the above snippet,
        "substring": <matched patch substring>,
        "levenshteinDist": <Levenshtein distance>,
        "percentSimilarity": <percentage similarity calculated>,
        "aiLines": <count of lines in the matched patch substring>
    }

If no significant similarity is found between the code snippet and the code patch, return an empty json object ({}). Do not provide any code or steps to achieve this goal, you must perform the calculations and return the output as described above.
"""

    def __init__(self):
        self.logger = get_module_logger('SIMILARITY_SEARCH_MGR')
        self.llm_token = "924eba03776f40b6b93dfa02b1077098"
        self.initialize_components()

    def initialize_components(self) -> None:
        """This function initializes a set of managers needed
        """
        with open('project_settings.json') as parameters:
            project_settings     = json.load(parameters)
        project_settings["LLMManager"]["openai"]['deployment_id'] = 'swe-gpt4o-exp1'
        self.llm_manager         = OpenAIManager(project_settings["LLMManager"]["openai"], self.llm_token)

    def check_patch_for_similarity(self, patch: str, code_snippet: str) -> dict:
        """This function checks the similarity between a code patch and a list of code snippets.
        """
        prompt = f"""{self.similarity_search_prompt_text}\n\n
            ### CODE PATCH:\n {patch}\n-----\n
            ### CODE SNIPPET:\n {code_snippet}\n
            """
        try:
            response = self.llm_manager.get_llm_response(prompt)
            response = response[response.find('{') : response.rfind('}') + 1] # Trim extra GPT 4o Response text
            response = json.loads(response)
        except Exception as e:
            self.logger.error(f'Failed to parse llm_response due to {e}. llm_response: {response}')
            return {}
            # Silent failure here - we want to log the error but continue trying with other patches if there are others
        return response

    def process_patches_for_similarity(self, pr_patches: str) -> dict:
        """This function processes a list of patches and corresponding code snippets for similarity.
        """
        with open(pr_patches, 'r') as f:
            patches = json.load(f)

        files = []

        for patch in patches['files']:
            patch_code = patch['patch']
            code_snippets = patch['code_snippets']
            similarity_matches = []
            for snippet in code_snippets:
                response = self.check_patch_for_similarity(patch_code, str(snippet))
                if response != {}:
                    similarity_matches.append(response)
            files.append({
                "patch": patch_code,
                "filename": patch['filename'],
                "similarity_matches": similarity_matches
            })
        return {
            "files": files
        }

    def main(self, pr_patches: str):
        return self.process_patches_for_similarity(pr_patches)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--pr_patches', type=str, default='', required=True, help='JSON string in the format: {{pull_number: <pull request number>, files: [{{filename: <file name>, patch: <file patch>, code_snippets: <a list of code suggestions for this patch from Copilot/AI Review bot>}}]}}')
    args = parser.parse_args()

    similarity_search_manager = SimilaritySearchManager()
    result = similarity_search_manager.main(args.pr_patches)

    # write the result to output.json
    with open('output.json', 'w') as f:
        json.dump(result, f)

