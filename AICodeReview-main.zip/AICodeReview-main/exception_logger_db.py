from database import DatabaseManager
from pr_info import PrInfo

class ExceptionLoggerDB():
    """Class that handles logging exceptions to DB
    """
    def __init__(self, db: DatabaseManager) -> None:

        self.db = db


    def log_to_db(self, e : Exception, pr_info: PrInfo, pr_url: str) -> None:
        """Log exception to exception table in the database for debug purposes
        Logging to database can itself raise an exception, that one obviously won't be logged in DB.

        Args:
           e: raised Exception
        """
        owner = None
        repo = None
        pr_num = 0
        pr_url = pr_url
        exc_type = None
        exc_err_num = -1
        exc_desc = None

        if pr_info is not None and pr_info.is_initialized():
            owner = pr_info.get_owner()
            repo = pr_info.get_repository()
            pr_num = pr_info.get_pr_number()

        if hasattr(e, 'exception_type'):
            exc_type = e.exception_type
        if hasattr(e, 'error_number') and e.error_number is not None:
            exc_err_num = e.error_number
        if hasattr(e, 'outcome'):
            exc_desc = e.outcome

        exception_data = [owner, repo, pr_num, pr_url, exc_type, exc_err_num, exc_desc]
        self.db.write_exception_data(exception_data)
