import psycopg2
from psycopg2 import extras
from datetime import datetime
from logger import get_module_logger
from exceptions import DBException
from pr_info import PrInfo

class DatabaseManager:
    class CommentsData:
        COMMENT_ID_INDEX = 0
        OWNER_INDEX = 1
        REPOSITORY_INDEX = 2
        PR_NUMBER_INDEX = 3
        AUTHOR_ID_INDEX = 4
        COMMIT_ID_INDEX = 5
        ISSUE_TYPE_INDEX = 6
        COMMENT_URL = 7
        SIGNIFICANCE_INDEX = 8
        CONFIDENCE_INDEX = 9
        CATEGORY_INDEX = 10
        PERCENT_MATCH_INDEX = 11

    class ExceptionData:
        OWNER = 0
        REPOSITORY = 1
        PR_NUMBER = 2
        PR_URL = 3
        EXCEPTION_TYPE = 4
        ERROR_CODE = 5
        EXCEPTION_DESCRIPTION = 6
        PROGRAM_START_TIMESTAMP = 7

    def __init__(self, db_settings: dict, log_to_db: bool, program_start_time: datetime):
        self.logger     = get_module_logger(db_settings["logger_name"])
        self.db_config  = db_settings["db_config"]

        self.program_start_time = program_start_time
        self.connection = psycopg2.connect(**self.db_config)
        self.logger.debug('Database connected')

        self.columns = self.get_column_names()
        self.log_to_db = log_to_db


    def get_column_names(self) -> list[str]:
        """Retrieve columns of the database

        Returns:
            list[str]: list of column names
        """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM comments_data LIMIT 1")
                data = [col[0] for col in cursor.description]
                self.logger.debug(f'Database columns: {data}')
            return data
        except psycopg2.Error as e:
            self.logger.error("Error while getting database column names")
            # Useful while debugging, but this is not logged in exception DB
            # as it's called in DatabaseManager constructor and therefore before exception logger is created
            raise DBException(e.pgcode, e.pgerror.splitlines()[0])
        except:
            # probably psycopg2.Warning
            self.logger.error("Error while getting database column names")
            return []


    def write_data(self, query: str, data: list[str]):
        """Write data to the database

        Args:
            query (str): query used to write data
            data (list[str]): data to write
        """
        if not self.log_to_db:
            return
        try:
            with self.connection.cursor() as cur:
                cur.execute(query, data)
                self.connection.commit()
                self.logger.debug('Succesfully wrote data to database')
        except psycopg2.Error as e:
            self.logger.error(f"Error while storing data: {e}")
            self.connection.rollback()
            raise DBException(e.pgcode, e.pgerror.splitlines()[0])
        except Exception as e:
            self.logger.error(f"Error while storing data: {e}")
            self.connection.rollback()


    def update_data(self, query: str, data: list[str]):
        """Updates data in the database

        Args:
            query (str): query
            data (list[str]): data to update
        """
        try:
            with self.connection.cursor() as cur:
                extras.execute_values(cur, query, data)
                self.connection.commit()
                self.logger.debug('Succesfully executed query')
        except psycopg2.Error as e:
            self.logger.error(f"Error while executing query: {e}")
            self.connection.rollback()
            raise DBException(e.pgcode, e.pgerror.splitlines()[0])
        except Exception as e:
            self.logger.error(f"Error while executing query: {e}")
            self.connection.rollback()


    def read_data(self, query_info: tuple) -> list[str]:
        """Returns data from the database based on the input query

        Args:
            query_info (tuple): A tuple containing the query string and its parameters

        Returns:
            list[str]: data
        """
        query, params = query_info
        try:
            with self.connection.cursor() as cur:
                cur.execute(query, params)
                data = cur.fetchall()
                self.logger.debug('Succesfully retrieved data from database')
                return data
        except psycopg2.Error as e:
            self.logger.error(f"Error while retrieving data: {e.pgcode}: {e.pgerror.splitlines()[0]}")
        except Exception as e:
            self.logger.error(f"Error while retrieving data: {e}")

    def delete_comment_data(self, data: list[str]) -> None:
        """Deletes comment data from the database.

        Args:
            data (list[str]): data to delete
        """
        query = """
            DELETE FROM comments_data (
                comment_id, program_start_timestamp, owner, repository, pr_number, author_id, commit_id, issue_type, comment_url, significance, confidence, category, percent_match
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        formatted_data = (
            data[self.CommentsData.COMMENT_ID_INDEX],
            self.program_start_time,
            data[self.CommentsData.OWNER_INDEX],
            data[self.CommentsData.REPOSITORY_INDEX],
            int(data[self.CommentsData.PR_NUMBER_INDEX]),
            data[self.CommentsData.AUTHOR_ID_INDEX],
            data[self.CommentsData.COMMIT_ID_INDEX],
            data[self.CommentsData.ISSUE_TYPE_INDEX],
            data[self.CommentsData.COMMENT_URL],
            float(data[self.CommentsData.SIGNIFICANCE_INDEX]),
            float(data[self.CommentsData.CONFIDENCE_INDEX]),
            data[self.CommentsData.CATEGORY_INDEX   ],
            data[self.CommentsData.PERCENT_MATCH_INDEX]
            )

        self.write_data(query, formatted_data)

    def write_comment_data(self, data: list[str]) -> None:
        """Writes comment data to the database.

        Args:
            data (list[str]): data to write
        """
        if len(data) < 10:
            self.logger.debug('Write comment data to DB called with wrong arguments')
            return

        query = """
            INSERT INTO comments_data (
                comment_id, program_start_timestamp, owner, repository, pr_number, author_id, commit_id, issue_type, comment_url, significance, confidence, category, percent_match
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        formatted_data = (
            data[self.CommentsData.COMMENT_ID_INDEX],
            self.program_start_time,
            data[self.CommentsData.OWNER_INDEX],
            data[self.CommentsData.REPOSITORY_INDEX],
            int(data[self.CommentsData.PR_NUMBER_INDEX]),
            data[self.CommentsData.AUTHOR_ID_INDEX],
            data[self.CommentsData.COMMIT_ID_INDEX],
            data[self.CommentsData.ISSUE_TYPE_INDEX],
            data[self.CommentsData.COMMENT_URL],
            float(data[self.CommentsData.SIGNIFICANCE_INDEX]),
            float(data[self.CommentsData.CONFIDENCE_INDEX]),
            data[self.CommentsData.CATEGORY_INDEX]
            )

        self.write_data(query, formatted_data)

    def get_all_comments_by_pr(self, pr_info: PrInfo) -> list[dict[str,str]]:
        return self.read_latest_comment_data_by_pr(pr_info.get_owner(), pr_info.get_repository(), int(pr_info.get_pr_number()), False)


    def read_latest_comment_data_by_pr(self, owner: str, repository: str, pr_number: int, single_comment=True) -> list[dict[str,str]]:
        """Return data from the latest comment posted on a PR defined by owner, repository and pr_number

        Args:
            owner (str): owner of the PR
            repository (str): repository of the PR
            pr_number (str): number of the PR
            single_comment (bool, True): if True, returns the single latest comment. Otherwise, returns all posted comments

        Returns:
            dict[str,str]: the data of the latest comment
        """
        query = """
        SELECT * FROM comments_data
        WHERE repository = %s AND
            owner = %s AND
            pr_number = %s
        ORDER BY program_start_timestamp DESC
        """
        if single_comment:
            query += "LIMIT 1;"
        result = self.read_data((query, (repository, owner, pr_number)))
        if result:
            data = []
            for row in result:
                data.append({self.columns[i]: row[i] for i in range(len(self.columns))})
            return data
        return []


    def write_exception_data(self, data: list[str]) -> None:
        """Writes exception data to the database.

        Args:
            data (list[str]): data to write
        """
        if len(data) < 7:
            self.logger.debug('Write exceptions data to DB called with wrong arguments')
            return

        query = """
            INSERT INTO exceptions_data (
                owner, repository, pr_number, pr_url, exception_type, error_code, exception_description, program_start_timestamp
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        formatted_data = (
            data[self.ExceptionData.OWNER],
            data[self.ExceptionData.REPOSITORY],
            int(data[self.ExceptionData.PR_NUMBER]),
            data[self.ExceptionData.PR_URL],
            data[self.ExceptionData.EXCEPTION_TYPE],
            data[self.ExceptionData.ERROR_CODE],
            data[self.ExceptionData.EXCEPTION_DESCRIPTION],
            self.program_start_time
        )
        self.write_data(query, formatted_data)


    def log_api_usage(self, repo: str, pr_url:str, num_github_api_calls:int, num_llm_api_calls:int, num_total_llm_tokens:int, avg_llm_time_in_ms:int) -> None:
        """Writes API usage stats to the database.

        Args:
            repo: repository
            pr_url: and PR URL
            num_github_api_calls: number of calls to Github for this PR URL
            num_llm_api_calls: number of calls to LLM for this PR URL
            num_total_llm_tokens: number of total tokens used when interacting with LLM for this PR URL
            avg_llm_time_in_ms: average duration before LLM returns a (succesful) response
        """

        query = """
            INSERT INTO API_usage_data (
                repository, pr_url, num_github_api_calls, num_llm_api_calls, num_llm_total_tokens, avg_llm_call_in_s, program_start_timestamp
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        formatted_data = (
            repo,
            pr_url,
            num_github_api_calls,
            num_llm_api_calls,
            num_total_llm_tokens,
            f"{avg_llm_time_in_ms/1000:.2f}",
            self.program_start_time
        )
        self.write_data(query, formatted_data)


    def close(self) -> None:
        """Closes the database connection
        """
        self.logger.debug('Database connection closed')
        self.connection.close()


# Example usage
if __name__ == "__main__":
    # Create a DatabaseManager instance with your PostgreSQL configuration
    db = DatabaseManager("AI_CodeReview", "postgres", "Admin@123", "srdcvadmcapd01", "5432")

    print(db.read_latest_comment_data_by_pr('ATG', 'SysArch-AICodeReview', 71))
    db.close()