import pandas as pd
from datetime import datetime
import os
import argparse
import psycopg2


class Database:
    def __init__(self):
        db_config = {
                "dbname": 'AI_CodeReview',
                "user": 'postgres',
                "password": 'Admin@123',
                "host": 'srdcvadmcapd01',
                "port": '5432'
                }
        self.connection = psycopg2.connect(**db_config)
        print('Connected to database')
        self.columns = self.get_column_names()

    def get_column_names(self) -> list[str]:
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM comments_data LIMIT 1")
                data = [col[0] for col in cursor.description]
            return data
        except:
            print("Error while getting database column names")
            return []
    
    def read_data(self, query_info: tuple) -> list[str]:
        query, params = query_info
        try:
            with self.connection.cursor() as cur:
                cur.execute(query, params)
                data = cur.fetchall()
                print('Succesfully retrieved data from database')
                return data
        except Exception as e:
            print(f"Error while retrieving data: {e}")
    
    def get_comments_since_date(self, date: str, repos: list = []):
        query = """
        SELECT *
        FROM "comments_data"
        WHERE program_start_timestamp >= %s
        """
        if repos: # Add the additional filter if repos list is not empty
            query += 'AND repository = ANY(%s)'
        query += ';'

        query_params = (date, repos) if repos else (date,)
        result = self.read_data((query, query_params))
        result = pd.DataFrame(result, columns=self.columns)
        print(f'Retrieved {result.shape[0]} entries!')
        return result


def prepare_comments_csv(date, only_dal):
    db = Database()
    repos = []
    if only_dal: 
        repos = ['dal', 'VPE']
        print(f'Retrieving data from: {repos}')
    print(f'Getting data from date: {date}')
    comments = db.get_comments_since_date(date, repos)
    filename = f'comment_data_since_{date}.csv'
    print(f'Saving data to: {filename}')
    comments.to_csv(filename, index=False)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-date',  type=str, help='earliest date to get data for, in yyyy-mm-dd format')
    parser.add_argument('--only_dal', '--dal', action="store_true", default=False, help='only look at DAL repo data')
    args = parser.parse_args()
    prepare_comments_csv(date=args.date, only_dal=args.only_dal)