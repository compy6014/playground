# Analysis Scripts for AI Code Reviewer

The scripts in this directory are used to analyze data about the Code Reviewer comments.

## Setup
These scripts require additional dependencies outlined in `requirements.txt`. 
These can be installed to the `aicodereview` conda environment created before.

## Script Details
Since each script performs a subtask, the following is an overview and **recommended order** in which to run the scripts:
1. `create_comments_csv_from_db.py`. This script pulls comment data from the DB and compiles them into a csv which will be used for subsequent analysis. It takes two arguments: 
    - `-date`: the date from which to get data in YYYY-MM-DD (e.g. setting it to `2024-01-01` will retrieve comments from Jan 1st 2024)
    - `--only_dal`: optional, whether to retrieve data only pertaining to DAL repos
    - **Example**: `py create_comments_csv_from_db.py -date 2024-01-01 --only_dal`
2. `get_reaction_data.py`. This script gets the Reaction Data from the Github APU for a given comments_csv file: 
    - `-comment_csv`: the path to a `comment_csv` created by Step 1. 
    - **Example**: `py get_reaction_data.py -comment_csv dal_comments_data_09-11-23.csv`
3. `visualize_reaction_data.py`. This script plots various graphs about reaction and comment data given comments_csv and reaction_csv file. Plots will be placed in a `visualizations` directory: 
    - `-comment_csv`: the path to a `comment_csv` created by Step 1.
    - `-reaction_csv`: the path to a `reaction_csv` created by Step 2. 
    - **Example**: `py visualize_reaction_data.py -comment_csv dal_comments_data_09-11-23.csv -reaction_csv reaction_data_09-11-23.csv`
