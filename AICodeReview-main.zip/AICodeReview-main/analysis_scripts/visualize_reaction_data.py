import pandas as pd
import argparse
import matplotlib.pyplot as plt
import os


def plot_reactions_over_time(df, dir=''):
    df['reaction_time'] = pd.to_datetime(df['reaction_time'])
    df['date'] = df['reaction_time'].dt.date
    daily_reactions = df.groupby('date').agg({'like': 'sum', 'dislike': 'sum'}).reset_index()
    daily_reactions['date_str'] = daily_reactions['date'].apply(lambda x: x.strftime('%d-%m'))

    plt.plot(daily_reactions['date_str'], daily_reactions['like'], label='Likes', color='green', marker='o')
    plt.plot(daily_reactions['date_str'], daily_reactions['dislike'], label='Dislikes', color='orange', marker='o')
    plt.xticks(rotation=45)
    plt.xlabel('Date')
    plt.ylabel('Number of Reactions')
    plt.title(f'{df.shape[0]} Reactions Over Time')
    plt.legend()
    plt.savefig(f'{dir}reactions_over_time.png', bbox_inches='tight')
    plt.show()


def plot_reactions_by_user(df, dir=''):
    sorted_df = df.groupby('user_id').agg({'like': 'sum', 'dislike': 'sum'}).reset_index()
    sorted_df['total'] = sorted_df['like'] + sorted_df['dislike']
    sorted_df = sorted_df.sort_values('total', ascending=False)
    sorted_df[['user_id', 'like', 'dislike']].plot(kind='bar', x='user_id', stacked=False, figsize=(10,6), color=['green', 'orange'])
    plt.title(f'{sorted_df["total"].sum()} Reaction Counts by {len(sorted_df)} Users, Sorted by Total Reactions')
    plt.savefig(f'{dir}reactions_by_user.png', bbox_inches='tight')
    plt.show()


def plot_reactions_by_pr(df, dir=''):
    df['PR'] = df['repository'] + '/' + df['pr_number'].astype(str)
    reaction_by_pr = df.groupby('PR').agg({'like': 'sum', 'dislike': 'sum'})

    top_likes = reaction_by_pr.sort_values('like', ascending=False).head(10)
    top_dislikes = reaction_by_pr.sort_values('dislike', ascending=False).head(10)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.bar(top_likes.index, top_likes['like'], color='green')
    ax1.set_title('Top 10 PRs with Most Likes')
    ax1.set_ylabel('Number of Likes')
    ax1.set_xticks(range(len(top_likes.index)))
    ax1.set_xticklabels(top_likes.index, rotation=45, ha='right')

    ax2.bar(top_dislikes.index, top_dislikes['dislike'], color='orange')
    ax2.set_title('Top 10 PRs with Most Dislikes')
    ax2.set_ylabel('Number of Dislikes')
    ax2.set_xticks(range(len(top_dislikes.index)))
    ax2.set_xticklabels(top_dislikes.index, rotation=45, ha='right')
    
    plt.tight_layout()
    plt.savefig(f'{dir}reactions_by_pr.png', bbox_inches='tight')
    plt.show()


def plot_reaction_rate(df, dir=''):
    likes = df.like.sum()
    dislikes = df.dislike.sum()
    zeros = ((df.like.isna() | (df.like == 0)) & (df.dislike.isna() | (df.dislike == 0))).sum()
    print(f"Likes: {likes}, Dislikes: {dislikes}")
    
    labels = ['Likes', 'Dislikes', 'Not Reacted']
    sizes = [likes, dislikes, zeros]
    colors = ['green','orange','#4472C4']
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', colors=colors)
    plt.title(f'Like and Dislike Percentages from {df.shape[0]} Posted Comments')
    plt.savefig(f'{dir}reaction_rate.png', bbox_inches='tight')
    plt.show()


def plot_reactions_by_repository(df, dir=''):
    reaction_rates = df[(df.like > 0) | (df.dislike > 0)]
    reaction_rates_repo = reaction_rates.groupby('repository').agg({'like': 'sum', 'dislike': 'sum'})
    reaction_counts = reaction_rates_repo[['like', 'dislike']]
    
    ax = reaction_counts.plot(kind='bar', stacked=False, color=['green', 'orange'], title=f'{reaction_counts.sum().sum()} Reactions by Repository')
    ax.set_ylabel("Count")
    plt.savefig(f'{dir}reaction_by_repository.png', bbox_inches='tight')
    plt.show()


def plot_reactions_by_comment_type(df, dir=''):
    positive_reactions = df[df.like > 0]
    negative_reactions = df[df.dislike > 0]
    
    positive_comment_type = positive_reactions.groupby('comment_type')['like'].sum()
    negative_comment_type = negative_reactions.groupby('comment_type')['dislike'].sum()

    reaction_counts = positive_comment_type.to_frame().join(negative_comment_type.to_frame())
    reaction_counts.columns = ['like', 'dislike']
    
    ax = reaction_counts.plot(kind='bar', stacked=False, color=['green', 'orange'], title=f'{reaction_counts.sum().sum()} Reactions by Comment Type')
    ax.set_ylabel("Count")
    ax.set_xlabel('Comment Type')
    ax.set_xticklabels(['Description', 'Review'], rotation=0)
    plt.savefig(f'{dir}reaction_by_comment_type.png', bbox_inches='tight')
    plt.show()

def plot_reactions_by_issue_type(df, dir=''):
    positive_reactions = df[df.like > 0]
    negative_reactions = df[df.dislike > 0]
    
    positive_issue_type = positive_reactions.groupby('issue_type')['like'].sum()
    negative_issue_type = negative_reactions.groupby('issue_type')['dislike'].sum()

    reaction_counts = positive_issue_type.to_frame().join(negative_issue_type.to_frame())
    reaction_counts.columns = ['like', 'dislike']
    
    ax = reaction_counts.plot(kind='bar', stacked=False, color=['green', 'orange'], title=f'{reaction_counts.sum().sum()} Reactions by Issue Type')
    ax.set_ylabel("Count")
    ax.set_xlabel('Issue Type')
    ax.set_xticklabels(reaction_counts.index, rotation=0)
    plt.savefig(f'{dir}reactions_by_issue_type.png', bbox_inches='tight')
    plt.show()


def preprocess_comments(df):
    df = df.groupby(['repository', 'pr_number']).size().reset_index(name='num_comments')
    df['pull'] = df['repository'] + '/' + df['pr_number'].astype(str)
    print(f'Posted {df.shape[0]} Comments to {df.shape[0]} PRs in Production Repositories')
    print(f'Number of PRs Posted to: {df.shape[0]}')
    print(f'Average Number of Comments Posted per PR: {df["num_comments"].mean():.1f}')
    print(f'Top 5 PRs with Most Comments Posted:\n{df.sort_values(["num_comments"], ascending=False)[:5]}')
    return df


def plot_comments_by_pr(df, dir=''):
    df = preprocess_comments(df)
    repos_group = df.groupby('repository').size().sort_values(ascending=False)
    for repo, num_prs in repos_group.items():
        group = df[df['repository'] == repo]
        num_prs = len(group['pr_number'])
        figsize = (10,5)
        if num_prs > 30:
            figsize = (13, 5)
        group.plot(x='pr_number', y='num_comments', kind='bar', title=f'Comments Posted to {repo.upper()}', legend=False, figsize=figsize)
        plt.xlabel('Pull Number', fontsize=8)
        plt.ylabel('Number of Posted Comments', fontsize=8)
        plt.xticks(range(num_prs), group['pr_number'], rotation=90)

        avg_comments = group['num_comments'].mean() # Add a line for the average num_comments
        plt.axhline(y=avg_comments, color='r', linestyle='--', label='Average')
        plt.legend([f'Average ({avg_comments:.1f})', 'Number of Comments'])
        plt.tight_layout()
        plt.savefig(f'{dir}comments_on_prs_{repo}.png', bbox_inches='tight')
        plt.show()

def plot_comments_by_repo(df, dir=''):
    df = preprocess_comments(df)
    repos_group = df.groupby('repository')['num_comments'].agg('sum').sort_values(ascending=False)

    figsize = (10, 5)
    repos_group.plot(kind='bar', title='Number of Comments Posted in Repositories', legend=False, figsize=figsize)
    plt.xlabel('Repository', fontsize=8)
    plt.ylabel('Number of Posted Comments', fontsize=8)
    plt.xticks(rotation=45)

    plt.tight_layout()
    plt.savefig(f'{dir}comments_by_repository.png', bbox_inches='tight')
    plt.show()


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-comment_csv',  type=str, help='path to comment data csv')
    parser.add_argument('-reaction_csv',  type=str, help='path to reaction data csv')
    args = parser.parse_args()
    
    dir = 'visualizations/'
    os.makedirs(dir, exist_ok=True)

    print(f'Reading data from: {args.comment_csv} and {args.reaction_csv}')
    # Plot Comment Data
    comments_df = pd.read_csv(args.comment_csv)
    comments_df = comments_df[comments_df['repository'] != 'SysArch-AICodeReview']
    # plot_comments_by_repo(comments_df, dir)
    plot_comments_by_pr(comments_df, dir)

    # # Plot Reaction Data
    reactions_df = pd.read_csv(args.reaction_csv)
    plot_reactions_over_time(reactions_df, dir)
    plot_reactions_by_user(reactions_df, dir)

    # # Plot Reaction Data and Comment Data
    merged_df = comments_df.merge(reactions_df, how='left')
    plot_reactions_by_pr(merged_df, dir)
    plot_reaction_rate(merged_df, dir)
    plot_reactions_by_repository(merged_df, dir)
    plot_reactions_by_comment_type(merged_df, dir)
    plot_reactions_by_issue_type(merged_df, dir)
    
    