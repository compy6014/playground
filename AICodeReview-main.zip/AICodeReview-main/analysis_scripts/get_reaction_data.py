import requests
import pandas as pd
from datetime import datetime
import argparse
from tqdm import tqdm
import re


def get_comment_data(owner, repo, comment_id, comment_type):
    # Update the comment_type parameter for the GitHub API

    print(f'Running Rest API call: https://github.amd.com/api/v3/repos/{owner}/{repo}/{comment_type}/comments/{comment_id}/reactions')
    url = f'https://github.amd.com/api/v3/repos/{owner}/{repo}/{comment_type}/comments/{comment_id}/reactions'
    headers = {"Authorization": f"Bearer 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", 'Accept': 'application/vnd.github+json'}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    elif response.status_code == 404:
        return False
    else:
        raise RuntimeError(f'Comment Fetching Failed: Status Code: {response.status_code}. {response.reason}')


def parse_reactions(comment):
    reactions = []
    for reaction in comment:
        user_id = reaction["user"]["login"]
        user_reaction = reaction["content"]
        time_stamp = reaction['created_at']
        reactions.append({"user_id": user_id, "reaction": user_reaction, "reaction_time": time_stamp})
    return reactions

def process_comments_data(comments_df):
    print(f'Getting reaction data for {comments_df.shape[0]} comments...')
    comment_reactions = []
    for i in tqdm(range(len(comments_df))):
        row = comments_df.iloc[i, :]
        comment_id = row['comment_id']
        # Extract issue type from the comment_url
        comment_url = row['comment_url']
        issue_type = 'issues' if re.search(r'issuecomment', comment_url) else 'pulls'

        comment_data = get_comment_data(row['owner'], row['repository'], comment_id, issue_type)
        if not comment_data:
            continue
        comment_reactions.append({str(comment_id): parse_reactions(comment_data)})
    return comment_reactions

def list_of_dicts_to_dataframe(data, comments_df):
    processed_data = []

    for item in data:
        comment_id = list(item.keys())[0]
        reactions = item[comment_id]

        # Get comment_url and repository from comments_df
        comment_url = comments_df.loc[comments_df['comment_id'] == int(comment_id), 'comment_url'].values[0]
        repository = comments_df.loc[comments_df['comment_id'] == int(comment_id), 'repository'].values[0]

        for reaction in reactions:
            new_reaction = {'comment_id': comment_id,
                            'user_id': reaction['user_id'],
                            'comment_url': comment_url,
                            'repository': repository,
                            'like': 0,
                            'dislike': 0}

            # Add 'reaction_time' only if it exists in the data
            if 'reaction_time' in reaction:
                new_reaction['reaction_time'] = reaction['reaction_time']

            if reaction['reaction'] == '+1':
                new_reaction['like'] = 1
            elif reaction['reaction'] == '-1':
                new_reaction['dislike'] = 1
            processed_data.append(new_reaction)

    df = pd.DataFrame(processed_data)

    # Convert 'reaction_time' to datetime format if the column exists
    if 'reaction_time' in df.columns:
        df['reaction_time'] = pd.to_datetime(df['reaction_time'])

    return df

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-comment_csv',  type=str, help='path to comments_data csv')
    args = parser.parse_args()

    print(f'Processing comments data from: {args.comment_csv}')
    comments_df = pd.read_csv(args.comment_csv)
    comment_reactions = process_comments_data(comments_df)
    df = list_of_dicts_to_dataframe(comment_reactions, comments_df)
    csv_name = f'reactions_data_{datetime.now().strftime("%d-%m-%y")}.csv'
    print(f'Saving reaction data to: {csv_name}')
    df.to_csv(csv_name, index=False)