import requests
import pandas as pd
from datetime import datetime
import os
import shutil
from bs4 import BeautifulSoup
import tarfile
import argparse

# Get all logged csvs
url = "http://mkmartifactory.amd.com/artifactory/atg-cvml-generic-local/ai-codereview/logs/"
credentials = {'userid': 'a1atgmerosa', 'password': 'AKCp5dLMrQgdtL2qDYPeucfse5tRUM9aRJqZA3jtgBgzdHgrXnYuPWtUexmgXigd5n9jb6Wew'}
    

def download_file(url, local_filename, credentials):
    with requests.get(url, stream=True, auth=(credentials['userid'], credentials['password'])) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
    return local_filename

def extract_tar(file, path):
    with tarfile.open(file) as tar:
        tar.extractall(path=path)

def parse_html(url, credentials):
    response = requests.get(url, auth=(credentials['userid'], credentials['password']))
    soup = BeautifulSoup(response.text, 'html.parser')
    return soup

def get_tar_files(soup, flag=['']):
    tar_files = []
    for link in soup.find_all('a'):
        href = link.get('href', '')
        if href.endswith('.tar.gz') and any([f in href for f in flag]):
            tar_files.append(href)
    return tar_files

def create_directory(dir_name):
    if not os.path.exists(dir_name):
        os.mkdir(dir_name)

def concatenate_csvs(directory, combined_csv):
    for csv_file in os.listdir(directory):
        if csv_file.endswith('.csv'):
            df = pd.read_csv(os.path.join(directory, csv_file))
            df['owner'] = df['repository'].apply(lambda repo: 'AMD-Radeon-Driver' if 'dal' in repo or 'VPE' in repo else 'ATG')
            combined_csv = pd.concat([combined_csv, df])
    return combined_csv

# Main function
def prepare_comments_csv(root, only_dal):
    tar_files_dir = f'{root}/tar_files'
    csv_files_dir = f'{root}/csv_files'
    filename = f'{root}/comment_data_{datetime.now().strftime("%d-%m-%y")}.csv'
    
    print(f'Collecting data from URL: {url}')
    soup = parse_html(url, credentials)
    flag = ['']
    if only_dal: 
        print('Collecting only DAL files')
        flag = ['dal', 'vpe'] # search for dal repos
        filename = f'{root}/dal_comment_data_{datetime.now().strftime("%d-%m-%y")}.csv'
    tar_files = get_tar_files(soup, flag)

    create_directory(tar_files_dir)
    create_directory(csv_files_dir)

    combined_csv = pd.DataFrame()
    for file in tar_files:
        file_url = url + file
        print(f"Downloading {file}")
        local_file = download_file(file_url, f"{tar_files_dir}/{file}", credentials)
        extract_tar(local_file, csv_files_dir)
        combined_csv = concatenate_csvs(csv_files_dir, combined_csv)
    
    combined_csv = combined_csv.drop_duplicates()
    combined_csv.to_csv(filename, index=False)
    print(f"Combined all CSV files into {filename}")
    print('Removing tarballs and intermediate csv files')
    shutil.rmtree(tar_files_dir)
    shutil.rmtree(csv_files_dir)

if __name__ == "__main__":
   
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-download_path', '-dw',  type=str, default=os.getcwd(), help='path to store downloaded data')
    parser.add_argument('--only_dal', '--dal', action="store_true", default=False, help='only look at DAL repo data')
    args = parser.parse_args()
    prepare_comments_csv(root=args.download_path, only_dal=args.only_dal)