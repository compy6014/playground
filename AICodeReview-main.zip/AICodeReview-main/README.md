# SysArch - AI for Code Review 


## Introduction

This repository contains a prototype **AI Code Review** pipeline that reviews PRs by:
1. Describing changes from the diff
2. Identifying issues from the change
3. Suggesting solutions to address the issues.

This pipeline relies on the LLM access provided by AMD, and as such requires an [LLM Gateway API Key](https://llm.amd.com/). The code is based on the sample scripts by the [SW Infra Team](https://github.amd.com/AMD-SW-Infra/LLM-API-Samples/tree/main/azure_openai/api). It has the ability to post comments on GitHub Pull Requests, if desired by the user.

Furthermore, it contains scripts to download, parse and visualize comment posting and reaction data. These are located in the folder `analysis_scripts`. 

There is also a script to predict the Influence of posted AI comments and update the database accordingly.

## Pipeline Overview:
![alt text](ai_code_review_pipeline.png)
**Technical details [here](https://amdcloud.sharepoint.com/:p:/s/ATGArchTeam/EU64jtiKlL5NqJm_3osqiK8BRcoP-ZpUkJdC7ZS4ZakDkQ?e=wwN16O)**


## Setup

The code is tested on **Python 3.10**.

We currently support the above pipeline. Here is how you can experiment with it:
1. Clone the repo: `git clone https://github.amd.com/ATG/SysArch-AICodeReview.git` and `cd` into it
2. Create env: `conda create -n aicodereview python=3.10`. Activate it: `conda activate aicodereview`.
3. Install dependencies: `pip install -r requirements.txt`
4. After running the script, comment data will be stored to a Database. Also, Logs will be saved under a `debug/` folder by default and also printed to the terminal. Logs include multiple `.json` files corresponding to each query. Finally a `global.log` file will be created containing the same output as printed to the terminal.


## Command-line Arguments

For the main AI Code Reviewer script:
- `-pr_url`, `-u`: The URL to the pull request (PR) that you want to process(such as https://github.amd.com/ATG/SysArch-AICodeReview/pull/1)
- `-llm_token`, `-llm`: The API token for the LLM Gateway
- `-ghe_token`, `-ghe`: The API token for GitHub Enterprise
- `-post_comments`: When set to 1, enables comment posting to the PR. When set to 0, turns off this behaviour. 1 by default.
- `-post_test_comments`: When set to 1, posts comments to the PR with a disclaimer indicating it is a **test comment**. When set to 0, turns off this behaviour. 1 by default.
- `-force_full_diff`: When set to 1, uses the whole diff. When set to 0, gets diff from last comment. 0 by default.
- `-debug`: When set to 1, enables debug logging. When set to 0, turns off this behaviour. 1 by default.
- `-log_to_db`: When set to 1, logs the comment data to the DB. When set to 0, turns off this behaviour. 1 by default.
- `-json_queries`, `-q`: The path to the JSON file containing queries. `queries.json` by default
- `-json_white_list_ext`, `-wl`: A path to a JSON file with white list extensions. `white_list_ext.json` by default

Note: only the `pr_url`, `-llm_token` and `-ghe_token` arguments are necessary. The remaining have default values which, in most cases, do not need to be modified.

## Usage

To run the script, you can use the following command-line syntax:

```bash
python pr_reviewer.py -pr_url <pr_url> -llm_token <llm_token> -ghe_token <ghe_token>
```

**Example:**
```
python pr_reviewer.py -pr_url https://github.amd.com/ATG/Test/pull/1 -llm_token ABCD1234 -ghe_token abcd1234 
```


## Influence Script

### Introduction

This script predicts the influence of AI comments on merged PRs using the LLM. It does this by:
1. Finding PRs updated in a given date range
2. Filtering merged PRs
3. For each comment in a merged PR, predicting its influence on the PR. 
    - i.e. for each AI comment: "does this issue still exist in the merged PR?"
4. Produces a csv containing with the developer reaction to each comment, predicted influence, and a corresponding explanation. 
5. It updates the database (`resolution` and `reaction` fields) only if -update_db is set to 1. Default 0

### Usage

```bash
python influence_rate_over_time.py -start_date <yyy-mm-dd> -end_date <yyy-mm-dd> -update_db 1
```

**Note!** This script must be manually triggered. Ideally, it should be integrated into a weekly/nightly CI workflow so that it regularly checks for merged PRs and updates the DB accordingly.

### Influence Script Pipeline Overview

![alt text](influence_pipeline.png)
**More technical details [here](https://amdcloud.sharepoint.com/:p:/s/ATGArchTeam/EXHtQCrJYaFLsJoEO3qSI0wBTpHLIxFI64e8cWbTXNSAuw?e=v1hI61)**