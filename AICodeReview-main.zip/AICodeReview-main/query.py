from message import Message
from exceptions import CommonException
from typing import List

class Query(Message):
    """Class that stores query-related data as an object
    """
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.update_prompts()


    def update_prompts(self) -> None:
        """Loads the prompt associated with this query

        Returns:
            str: short name
        """
        prompts = self.get_prompts()
        fixed_prompts = []
        for prompt in prompts:
            if not prompt:
                raise CommonException("The prompt value is not initialized!")

            prompt = prompt.replace('{expected_positive}', f'{self.get_expected_positive_flag()}')
            prompt = prompt.replace('{expected_negative}', f'"{self.get_expected_negative_flag()}"') # note double quote symbols
            prompt = prompt.replace('{example_output}', f'"{self.get_example_output()}"') # note double quote symbols
            fixed_prompts.append(prompt)
        self.prompts = fixed_prompts


    def get_post_process_prompt(self) -> str:
        """Returns the post process prompt associated with this query

        Returns:
            str: post process prompt
        """
        return getattr(self, 'post_process_prompt', '')


    def get_prompt(self) -> str:
        """Returns the prepared prompt associated with this query

        Returns:
            str: prompt
        """
        prompt = getattr(self, 'prompt', '')
        return prompt


    def get_prompts(self) -> List[str]:
        """Returns the prepared prompts associated with this query

        Returns:
            str: prompts
        """
        prompts = getattr(self, 'prompts', [])
        return prompts


    def get_expected_positive_flag(self) -> str:
        """Returns the flag indicating an start phrase of this query

        Returns:
            str: flag (e.g. "yes, there are issues")
        """
        return getattr(self, 'expected_positive', '')


    def get_positive_start(self) -> str:
        """Returns the flag indicating an issue, associated with this query

        Returns:
            str: flag (e.g. "yes, there are issues")
        """
        return getattr(self, 'positive_start', '')


    def get_expected_negative_flag(self) -> str:
        """Returns the flag indicating an issue, associated with this query

        Returns:
            str: flag (e.g. "no issues")
        """
        return getattr(self, 'expected_negative', '')


    def get_example_output(self) -> str:
        """Returns the example output for in-context learning for the LLM, associated with this query

        Returns:
            str: example output
        """
        return getattr(self, 'example_output', '')


    def get_response_header(self) -> str:
        """Returns the header associated with this query

        Returns:
            str: header
        """
        return getattr(self, 'response_header', '')


    def get_response_footer(self) -> str:
        """Returns the footer associated with this query

        Returns:
            str: footer
        """
        return getattr(self, 'response_footer', '')


    def use_only_added_code(self) -> bool:
        """Returns the type of code_change associated with this query. E.g. 'added' code only or 'all' code

        Returns:
            bool: True, when only using added code. False, otherwise
        """
        return getattr(self, 'code_change_type', '') == 'added'

    def get_context_level(self) -> str:
        """Returns whether to use 'full' context (entire file), 'function' context (context around changed functions), or 'diff' context

        Returns:
            str: 'full', 'function', or 'diff' depending on the context level
        """
        level = getattr(self, 'context_level', 'diff')
        return level if level in ['full', 'function', 'diff'] else 'diff'

    def get_engine(self) -> str:
        """returns query engine to use.

        Returns:
            str: any of the supported engine types (openai, gemini, etc)
        """
        return getattr(self, 'engine', 'openai')

    def get_model(self) -> str:
        """returns query model to use.

        Returns:
            str: the deployment ID of the model to use (i.e swe-gpt4o-exp1)
        """
        return getattr(self, 'model', '')
