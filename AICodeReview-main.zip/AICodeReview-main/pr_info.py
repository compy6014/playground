import re
import json
from github_api import GithubAPI
from logger import get_module_logger
from exceptions import CommonException, URLException

class PrInfo():
    """Class that stores information about GitHub pull requests.
    """

    def __init__(self,
                 pr_info_settings: dict,
                 github_api: GithubAPI,
                 pr_url: str) -> None:

        self.logger = get_module_logger(pr_info_settings["logger_name"])
        if github_api is None or not isinstance(github_api, GithubAPI):
            raise CommonException("github_api must be non-None and an instance of GithubAPI")
        self.github_api = github_api

        self.pr_url = pr_url
        self.pr_url_api = self.validate_pr_url(pr_url)
        self.load_pr_details(pr_url_api=self.pr_url_api)
        self.pr_url_diff = self.pr_url_api + ".diff"
        self.pr_url_files = self.pr_url_api + "/files"

        self.reset_debug()
        self.initialized = True


    def validate_pr_url(self, pr_url: str) -> str:
        """
        Validates the provided Pull Request (PR) URL and extracts the PR owner, repository,
        and PR number if valid (for both GitHub AMD and GitHub.com EMU). Logs the success
        or failure of the validation and the extracted information if valid.

        Args:
            pr_url (str): The Pull Request URL to validate.

        Returns:
            str: The API URL if the PR URL is valid, otherwise raises an exception.
        """
        self.logger.info(f'Validating PR URL: {pr_url}')

        # Pattern for GitHub AMD: https://github.amd.com/Owner/Repo/pull/123
        pattern_amd = re.compile(r"https://github\.amd\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)")

        # Pattern for standard GitHub (EMU example): https://github.com/Owner/Repo/pull/123
        pattern_emu = re.compile(r"https://github\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)")

        match_amd = re.match(pattern_amd, pr_url)
        match_emu = re.match(pattern_emu, pr_url)

        # Check for GitHub AMD
        if match_amd:
            self.owner, self.repository, self.pr_number = match_amd.groups()
            self.logger.info(
                f'PR URL Valid (GitHub AMD)! Extracted Owner: {self.owner}, '
                f'Repo: {self.repository}, PR Number: {self.pr_number}'
            )
            api_base = "https://github.amd.com/api/v3"
            api_url = f"{api_base}/repos/{self.owner}/{self.repository}/pulls/{self.pr_number}"
            self.logger.info(f'API URL generated: {api_url}')
            return api_url

        # Check for GitHub.com (EMU or any other org)
        if match_emu:
            self.owner, self.repository, self.pr_number = match_emu.groups()
            self.logger.info(
                f'PR URL Valid (GitHub.com)! Extracted Owner: {self.owner}, '
                f'Repo: {self.repository}, PR Number: {self.pr_number}'
            )
            # Set the base API URL for GitHub.com
            api_base = "https://api.github.com"
            graphql_api_base = "https://api.github.com/graphql"
            self.github_api.set_api_base(api_base, graphql_api_base)
            # Generate the API URL
            api_url = f"{api_base}/repos/{self.owner}/{self.repository}/pulls/{self.pr_number}"
            self.logger.info(f'API URL generated: {api_url}')
            return api_url

        # If neither pattern matches, raise an exception
        self.logger.error(f'PR URL Invalid: {pr_url}')
        raise URLException(pr_url, 404, "PR URL Invalid")

    def load_pr_details(self, pr_url_api: str) -> None:
        """Retrieves the commit id of the latest commit, the user id of the author, and the base branch
        """
        git_pr_info_raw = self.github_api.get_url(pr_url_api)
        self.git_pr_info = json.loads(git_pr_info_raw)
        self.commit_id = self.git_pr_info["head"]["sha"]
        self.base_commit_id = self.git_pr_info["base"]["sha"]
        self.author_id = self.git_pr_info["user"]["login"]
        self.base_branch = self.git_pr_info["base"]["ref"]


    def get_pr_commit_id(self) -> str:
        """Returns current commit id for this PR
        """
        commit_id = getattr(self, 'commit_id', '')
        return commit_id

    def get_pr_base_commit_id(self) -> str:
        """Returns base commit id (from base branch) for this PR
        """
        base_commit_id = getattr(self, 'base_commit_id', '')
        return base_commit_id

    def get_owner(self) -> str:
        """Returns owner for this PR
        """
        owner = getattr(self, 'owner', '')
        return owner


    def get_pr_author_id(self) -> str:
        """Returns author id for this PR
        """
        author_id = getattr(self, 'author_id', '')
        return author_id


    def get_pr_url(self) -> str:
        """Returns URL for this PR
        """
        return self.pr_url


    def get_pr_url_api(self) -> str:
        """Returns API URL for this PR
        """
        pr_url_api = getattr(self, 'pr_url_api', '')
        return pr_url_api


    def get_pr_url_diff(self) -> str:
        """Returns DIFF URL for this PR
        """
        pr_url_diff = getattr(self, 'pr_url_diff', '')
        return pr_url_diff


    def get_pr_url_files(self) -> str:
        """Returns FILES URL for this PR
        """
        pr_url_files = getattr(self, 'pr_url_files', '')
        return pr_url_files


    def get_repository(self) -> str:
        """Returns the repo for the PR
        """
        repo = getattr(self, 'repository', 'unknown_repo')
        return repo


    def get_pr_number(self) -> str:
        """Returns the pull number for the PR
        """
        pull_number = getattr(self, 'pr_number', '0')
        return pull_number


    def reset_debug(self) -> None:
        self.debug = {}


    def get_debug_info(self) -> dict[str, str]:
        """Provides a dicitonary with debug information about the PR and comment, if posted.
        Also logs any comment data to the artifactory file
        Returns:
            dict[str, str]: debug info
        """
        debug = {
                "PR URL": self.get_pr_url_api(),
                "PR Commit ID": self.get_pr_commit_id(),
                "Diff URL": self.get_pr_url_diff()
            }
        return debug
    
    def get_base_branch(self) -> str:
        """Returns base branch for this PR
        """
        base_branch = getattr(self, 'base_branch', '')
        return base_branch

    def is_initialized(self) -> bool:
        return self.initialized
