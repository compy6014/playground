from typing import List
from logger import get_module_logger
from exceptions import LLMException

from openai_manager import OpenAIManager
from gemini_manager import GeminiManager
from query_engine import QueryEngine

class LLMManager():
    """Class that manages interaction with LLM Gateway.
    """

    def __init__(self, llm_manager_settings: dict, llm_token:str) -> None:
        self.logger = get_module_logger(llm_manager_settings["logger_name"])
        self.openai_manager = OpenAIManager(llm_manager_settings['openai'], llm_token)
        self.gemini_manager = GeminiManager(llm_manager_settings['gemini'], llm_token)
        self.reset_usage_counters()
        self.reset_debug()

    def detect_engine(self, engine: str) -> QueryEngine:
        match engine:
            case 'openai':
                return self.openai_manager
            case 'gemini':
                return self.gemini_manager
            case _:
                self.logger.error(f"Engine {engine} is not supported.")
                raise LLMException(outcome=f"Unsupported engine specified: {engine}")


    def get_responses(self, prompts: dict[str, List[str]], engine: str, model: str) -> dict[str, str]:
        """Posts a request to the LLM API for each prompt in prompts. Returns the response as a dictionary

        Args:
            prompts (list[str]): keys are identifiers (e.g. filename), values are prompts

        Returns:
            dict[str, str]: keys are identifiers from prompts, values are dict responses from LLM
        """
        query_engine = self.detect_engine(engine)
        if query_engine is None:
            return {}

        responses = query_engine.get_responses(prompts, model)
        self.update_usage_counters(query_engine)
        return responses


    def get_max_prompt_length(self, engine: str) -> int:
        query_engine = self.detect_engine(engine)
        return query_engine.get_max_prompt_length() if query_engine else 0


    ## Below functions need to aggregate the responses from submanagers
    def get_debug_info(self) -> dict[str, str]:
        """Provides a dicitonary with debug information about the API parameters and response.

        Returns:
            dict[str, str]: debug info
        """
        debug = {
            "Gemini_Manager": self.gemini_manager.get_debug_info(),
            "OpenAI_Manager": self.openai_manager.get_debug_info()
        }
        return debug


    def reset_usage_counters(self) -> None:
        """Resets the usage counters for all managers (openAI, gemini, etc)."""
        self.num_llm_api_calls = 0
        self.num_llm_api_calls_success = 0
        self.total_llm_time_in_ms = 0
        self.num_prompt_tokens = 0
        self.num_total_tokens = 0


    def update_usage_counters(self, query_engine: QueryEngine) -> None:
        """Update LLM Usage counters from sub manager (openAI, gemini, etc)."""
        self.num_llm_api_calls += query_engine.get_num_llm_api_calls()
        self.num_llm_api_calls_success += query_engine.get_num_llm_api_calls()
        self.total_llm_time_in_ms += query_engine.get_total_llm_time_in_ms()
        self.num_prompt_tokens += query_engine.get_num_prompt_tokens()
        self.num_total_tokens += query_engine.get_num_total_tokens()


    def reset_debug(self) -> None:
        self.debug = {"Responses": []}


    def get_num_llm_api_calls(self) -> int:
        return getattr(self, 'num_llm_api_calls', 0)


    def get_num_llm_total_tokens(self) -> int:
        return getattr(self, 'num_total_tokens', 0)


    def get_avg_llm_time_in_ms(self) -> int:
        if hasattr(self, 'total_llm_time_in_ms') and hasattr(self,'num_llm_api_calls_success') and self.num_llm_api_calls_success > 0:
            return int(self.total_llm_time_in_ms / self.num_llm_api_calls_success)
