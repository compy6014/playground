import json
import requests
from logger import get_module_logger
from requests.exceptions import Timeout
from exceptions import GitHubException


class GithubAPI():
    """Class that handles API calls to Github.
    """

    def __init__(self,
                 github_api_settings: dict,
                 ghe_token: str) -> None:

        self.logger          = get_module_logger(github_api_settings["logger_name"])
        self.ghe_api_timeout = github_api_settings["ghe_api_timeout"]
        self.comment_header = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {ghe_token}"
        }
        self.diff_header = {
            "Accept": "application/vnd.github.diff",
            "Authorization": f"Bearer {ghe_token}"
        }
        self.graphql_header = {
            "Authorization": f"Bearer {ghe_token}",
            "Content-Type": "application/json",
        }
        self.amd_base_api_url = "https://github.amd.com/api/v3/repos/"
        self.amd_graphql_api_url = "https://github.amd.com/api/graphql"
        self.num_api_calls = 0

    def set_api_base(self, api_base: str, graphql_api_base) -> None:
        """Set the base API URL."""
        self.amd_base_api_url = api_base
        self.amd_graphql_api_url = graphql_api_base
        self.logger.info(f'Set API base to {api_base} and GraphQL API base to {graphql_api_base}.')

    def get_comment_body(self, comment_url:str) -> str:
        body = ''
        response = requests.get(comment_url, headers=self.comment_header)
        if response.status_code == 200:
            comments = response.json()
            body = comments['body']
        return body


    def handle_timeout(self, url: str, action: str) -> None:
        """Handles a timeout error during a GitHub API call.

        Args:
            url (str): The URL of the API call that timed out.
            action (str): The action that was being performed when the timeout occurred.
        """
        self.logger.error(f'Timeout Error occured when {action} {url}!')
        raise GitHubException(error_number=-1, outcome=f'Reached Timeout when {action}!')


    def call_github(self, url: str, headers: dict[str, str], except_404 = False) -> str:
        """Makes a GET request to the GitHub API.

        Args:
            url (str): The URL of the API endpoint.
            headers (dict[str, str]): The headers to include in the request.

        Returns:
            str: The response text from the API call.
        """
        try:
            self.num_api_calls += 1
            response = requests.get(url, headers=headers, timeout=self.ghe_api_timeout)
            if response.status_code == 200:
                return response.text
            elif response.status_code == 404 and except_404: # this means the url doesnt exist (e.g. comment is deleted)
                return ''
            else:
                raise GitHubException(response.status_code, response.reason)
        except Timeout:
            self.handle_timeout(url, 'calling')


    def call_github_comment(self, url: str, comment_body: dict[str, str]) -> requests.Response:
        """Posts a comment on GitHub using the provided comment_body and comment_url.

        Args:
            url (str): The URL where the comment should be posted
            comment_body (dict[str, str]): A dictionary containing the comment details..
        """
        self.logger.info(f'Trying to post comment to {url} ...')
        try:
            self.num_api_calls += 1
            response = requests.post(url, headers=self.comment_header, json=comment_body, timeout=self.ghe_api_timeout)
            return response
        except Timeout:
            self.handle_timeout(url, 'posting comment to')


    def get_url(self, url: str) -> str:
        """Retrieves the content of a PR URL as text.
        """
        response_text = self.call_github(url, self.comment_header)
        return response_text


    def get_diffs(self, url: str) -> str:
        """Retrieves the commit diffs as text.
        """
        response_text = self.call_github(url, self.diff_header)
        return response_text


    def get_comments(self, url:str) -> dict[str, str]:
        """ Retrieves the comments as json response. If the comment is deleted, return and empty dict
        """
        comments = {}
        response_text = self.call_github(url, self.comment_header, except_404=True)
        if response_text:
            comments = json.loads(response_text)
        return comments


    def get_num_api_calls(self) -> int:
        return getattr(self, 'num_api_calls', 0)

    def get_changed_files(self, owner, repository, pr_number):

        # GraphQL query to get list of changed files in a PR
        query_template = """
        query {{
            repository(owner: "{owner}", name: "{repository}") {{
                pullRequest(number: {pr_number}) {{
                    files(first: 100) {{
                        edges {{
                            node {{
                                path
                            }}
                        }}
                    }}
                }}
            }}
        }}
        """
        query = query_template.format(owner=owner, repository=repository, pr_number=pr_number)

        try:
            response = requests.post(self.amd_graphql_api_url, headers=self.graphql_header, data=json.dumps({"query": query}))
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise GitHubException(str(e), response.status_code)

        response_data = response.json()

        if "errors" in response_data:
            print(f"Error in GraphQL response: {response_data['errors']}")
            return []

        pr_data = response_data["data"]["repository"]["pullRequest"]
        changed_files = [edge["node"]["path"] for edge in pr_data["files"]["edges"]]

        return changed_files
