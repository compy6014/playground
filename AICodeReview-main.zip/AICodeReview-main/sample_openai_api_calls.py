import requests


SERVER =  "https://llm-api.amd.com/azure"
HEADERS = {"Ocp-Apim-Subscription-Key": "924eba03776f40b6b93dfa02b1077098"}


def api_call(endpoint_name: str, body: dict, deployment_id: str):
    response = requests.post(url=f"{SERVER}/engines/{deployment_id}/{endpoint_name}", 
                             json=body,
                             headers=HEADERS)
    response.raise_for_status()
    return response.json()


if __name__ == "__main__":
    # Completion ---------------------------------------------------
    # body = {
    #     "prompt": "AMD is",
    #     "max_Tokens": 80,
    #     "temperature": 0,
    #     "top_P": 1,
    #     "logit_Bias": None,
    #     "user": None,
    #     "n": 2,
    #     "stream": False,
    #     "logprobs": None,
    #     "suffix": None,
    #     "echo": False,
    #     "stop": None,
    #     "presence_Penalty": 0,
    #     "frequency_Penalty": 0,
    #     "best_Of": 3
    # }
    # completion_result = api_call(endpoint_name="completions",
    #                              body=body,
    #                              deployment_id="swe-text-davinci-003-exp1")
    # print(f"Completion\n{completion_result}")
    # print("\n--------------\n")


    # Chat Completion ---------------------------------------------------
    body = {
        "messages": [
            # Must provide a conversation in the following format. The first message with "system" role is optional.
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello, can you tell me what is the population of Australia?"},
            {"role": "assistant", "content": "As of August 2021, the estimated population of Australia is around 25.8 million people."},
            {"role": "user", "content": "What is that country's capital?"},
            {"role": "assistant", "content": "The capital city of Australia is Canberra."},
            {"role": "user", "content": "Where is it found?"}
        ],
        "temperature": 0,
        "n": 2,
        "stream": False,
        "stop": None,
        "max_Tokens": 100,
        "presence_Penalty": 0,
        "frequency_Penalty": 0,
        "logit_Bias": None,
        "user": None
    }
    chat_completion_result = api_call(endpoint_name="chat/completions",
                                      body=body,
                                      deployment_id="swe-gpt35-turbo-exp1")
    print(f"Chat Completion\n{chat_completion_result}")
    print("\n--------------\n")


    # # Embeddings ---------------------------------------------------
    # input = "AMD was founded in 1969"
    # body = {"input": input, "user": None}
    # embeddings_result = api_call(endpoint_name="Embeddings",
    #                              body=body,
    #                              deployment_id="text-embedding-ada-002")
    # # Just show the first 20 entries of the embedding vector
    # embeddings_result['data'][0]['embedding'] = embeddings_result['data'][0]['embedding'][:20]
    # embeddings_result['data'][0]['embedding'].append("...")
    # print(f"Embeddings\n{embeddings_result}")
    # print("\n--------------\n")
