import argparse
import pandas as pd
from datetime import datetime
import json
import logging
import requests
logging.disable('WARN') # don't show debug/info logs for cleaner output

from influence_rate_from_llm import InfluenceRateManager
from database import DatabaseManager
from github_api import GithubAPI
from elk import query_elk
from elk import update_elk
from elasticsearch_dsl import Q


class InfluenceRateCaller:
    def __init__(self, ghe_token, llm_token):
        self.log_to_db = True
        self.ghe_token = ghe_token
        self.llm_token = llm_token
        self.program_start_time = datetime.utcnow().replace(microsecond=0)
        self.cache = {}
        self.initialize_components()

    def initialize_components(self) -> None:
        """This function initializes a set of managers needed
        """
        with open('project_settings.json') as parameters:
            project_settings     = json.load(parameters)
        self.db                  = DatabaseManager(project_settings["DatabaseManager"], self.log_to_db, self.program_start_time)
        self.github_api          = GithubAPI(project_settings["GithubAPI"], self.ghe_token)
        self.irm                 = InfluenceRateManager(self.ghe_token, self.llm_token)

    def get_prs_since_date(self, start_date: str, end_date: str, repo: str):
        end_date = end_date or None  # Convert empty string to None for COALESCE
        used_end_date = end_date or "Today"

        query = """
        SELECT DISTINCT owner, repository, pr_number
        FROM (
            SELECT owner, repository, pr_number, COUNT(*) AS comment_count
            FROM "comments_data"
            WHERE program_start_timestamp IS NOT NULL
            AND program_start_timestamp >= %s
            AND program_start_timestamp <= COALESCE(%s, CURRENT_DATE)
            AND resolution IS NULL
            GROUP BY owner, repository, pr_number
        ) AS grouped_data
        WHERE comment_count <= 20;
        """
        query_params = (start_date, end_date)
        result = self.db.read_data((query, query_params))
        result = pd.DataFrame(result, columns=['owner', 'repository', 'pr_number'])
        if repo.strip():  # Check if repo is not an empty string or contains only spaces
            result = result[result['repository'] == repo]
        print(f'Retrieved {result.shape[0]} PRs between {start_date} and {used_end_date} for {repo or "all repos"}!')
        return result

    def get_prs_since_date_elk(self, start_date: str, end_date: str, repo: str):
        end_date = end_date or None  # Convert empty string to None for COALESCE
        used_end_date = end_date or "Today"

        # Create a date range query
        date_range = Q("range", **{"@timestamp": {"gte": start_date, "lte": end_date or "now"}})

        # Query Elasticsearch
        response = query_elk("ai_comment_data", date_range, size=10000)  # Increase size if you expect more results

        # Parse the response to a DataFrame
        result = []
        for hit in response:
            owner = hit['msg.owner']
            repository = hit['msg.repository']
            pr_number = hit['msg.pr_number']
            result.append((owner, repository, pr_number))

        result = pd.DataFrame(result, columns=['owner', 'repository', 'pr_number'])

        if repo.strip():  # Check if repo is not an empty string or contains only spaces
            result = result[result['repository'] == repo]

        result = result.drop_duplicates()  # Remove duplicate rows

        print(f'Retrieved {result.shape[0]} PRs between {start_date} and {used_end_date} for {repo or "all repos"}!')
        return result

    def get_merge_status(self, row):
        owner, repository, pr_number = row['owner'], row['repository'], row['pr_number']
        pr_url = f'https://github.amd.com/{owner}/{repository}/pull/{pr_number}' # needed for influence rate script

        # GraphQL query to get PR merge status and latest commit ID
        query_template = """
        query {{
            repository(owner: "{owner}", name: "{repository}") {{
                pullRequest(number: {pr_number}) {{
                    merged
                    headRefOid
                }}
            }}
        }}
        """
        query = query_template.format(owner=owner, repository=repository, pr_number=pr_number)

        url = "https://github.amd.com/api/graphql"
        headers = {
            "Authorization": "Bearer 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",
            "Content-Type": "application/json",
        }

        response = requests.post(url, headers=headers, data=json.dumps({"query": query}))
        response.raise_for_status()
        response_data = response.json()

        if "errors" in response_data:
            print(f"Error in GraphQL response: {response_data['errors']}")
            return False

        pr_data = response_data["data"]["repository"]["pullRequest"]

        row['pr_url'] = pr_url
        row['is_merged'] = pr_data['merged']
        row['latest_commit_id'] = pr_data["headRefOid"]
        return row

    def find_merged_prs(self, df):
        print(f'Checking merge status of {df.shape[0]} PRs')
        df = df.apply(lambda row: self.get_merge_status(row), axis=1)
        df = df[df['is_merged']]
        print(f'Found {df.shape[0]} merged PRs')

        return df


    def compute_influence_on_pr(self, pr_url: str, pr_merge_commit_id: str):
        print(f'Computing Influence For PR: {pr_url}')
        comments = self.irm.get_total_influence(pr_url, pr_merge_commit_id=pr_merge_commit_id)
        influence_comments = comments[comments['resolution'] == 1]
        total_comments, num_influential = len(comments), len(influence_comments)
        print(f'Comments: {total_comments}. Influential Comments: {num_influential}. Influence Rate: {(num_influential/total_comments)*100:.2f}%')
        return comments

    def get_influence_data(self, df):
        comments_list = []
        for _, row in df.iterrows():
            pr_url = row['pr_url']
            pr_merge_commit_id = row['latest_commit_id']
            comments_list.append(self.compute_influence_on_pr(pr_url, pr_merge_commit_id))
        comments = pd.concat(comments_list, ignore_index=True)
        return comments

    def get_data_to_update(self, row):
        return (row['resolution'], row['percent_match'], row['reaction'], str(row['comment_id']))

    def update_db(self, df):
        query = """
        UPDATE comments_data
        SET resolution = data.resolution, percent_match = data.percent_match, reaction = data.reaction
        FROM (VALUES %s) AS data (resolution, percent_match, reaction, comment_id)
        WHERE comments_data.comment_id = data.comment_id
        """
        update_data = df.apply(lambda row: self.get_data_to_update(row), axis=1).tolist()
        print(f'Updating Database...')
        self.db.update_data(query, update_data)
        print('Succesfully Updated Database!')

    def update_elk(self, df, index):
        print(f'Updating Elasticsearch...')
        for _, row in df.iterrows():
            doc_id = row['_id']  # Get the document ID from the DataFrame
            update = {
                'msg.resolution': row['resolution'],
                'msg.percent_match': row['percent_match'],
                'msg.reaction': row['reaction']
            }
            update_elk(index, doc_id, update)
        print('Successfully Updated Elasticsearch!')


    def delete_comments_db(self, df) -> None:
        query = """
        DELETE FROM comments_data WHERE (comment_id) in (%s)
        """
        deleted_comment_ids = [(str(i),) for i in df.loc[df[df['deleted']].index, 'comment_id']]
        if len(deleted_comment_ids) == 0: # dont update if there are no deletions
            return
        print(f'Deleting {len(deleted_comment_ids)} Comments From the Database...')
        self.db.update_data(query, deleted_comment_ids)
        print(f'Succesfully Deleted Comments From the Database')

    def print_and_save(self, df, total_prs, save, start_date, end_date, repo):
        influence_comments = df[df['resolution'] == 1]
        total_comments, num_influential = len(df), len(influence_comments)
        print(f'For {total_prs} PRs. Total Comments: {total_comments}. Influential Comments: {num_influential}. Influence Rate: {(num_influential/total_comments)*100:.2f}%')
        if save:
            save_file = f'influence_{repo}_{start_date}_{end_date}.csv'
            print(f'Saving data to: {save_file}')
            df.to_csv(save_file, index=False)

    def main(self, start_date, end_date='', repo='', save=True, update_elk=True):
        prs_df = self.get_prs_since_date_elk(start_date, end_date, repo)
        # If there are no PRs, stop execution
        if prs_df.empty:
            print('No PRs found. Stopping execution...')
            return
        prs_df = self.find_merged_prs(prs_df)
        comments = self.get_influence_data(prs_df)
        total_prs = prs_df.shape[0]
        self.print_and_save(comments, total_prs, save, start_date, end_date, repo)
        if update_elk:
            self.update_elk(comments, 'ai_comment_data')
        return comments

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-start_date',  type=str, help='earliest date to get PRs, in yyyy-mm-dd format')
    parser.add_argument('-end_date',  type=str, default='', help='[optional] latest date to get PRs, in yyyy-mm-dd format. default, today.')
    parser.add_argument('-repo',  type=str, default='', help='[optional] get prs from specific repository, default, all repos')
    parser.add_argument('-save',  type=int, default=1, help='[optional] get prs from specific repository, default 1')
    parser.add_argument('-update_db', type=int, default=0, help='[optional] update database with resolution/reaction data and remove deleted comments, default 0')
    parser.add_argument('-update_elk', type=int, default=0, help='[optional] update ELK with resolution/reaction data, default 1')
    parser.add_argument('-ghe_token', '-ghe', type=str, required=True, help='token for GHE API')
    parser.add_argument('-llm_token', '-llm', type=str, required=True, help='token for LLM API')
    args = parser.parse_args()

    irc = InfluenceRateCaller(ghe_token=args.ghe_token, llm_token=args.llm_token)
    irc.main(args.start_date, args.end_date, args.repo, bool(args.save), bool(args.update_elk))

