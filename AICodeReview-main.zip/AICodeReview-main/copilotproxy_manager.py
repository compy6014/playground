from copilotproxy_api import CopilotProxyAPI
from comment import Comment
from pr_info import PrInfo
from query import Query
from comment_manager import CommentManager
import time
import requests
from logger import get_module_logger
from typing import List, Tuple

class CopilotProxyManager:
    '''Class that manages the CopilotProxyAPI and Comment objects
    '''
    def __init__(self, comment_manager: CommentManager) -> None:
        self.copilot_proxy_api = CopilotProxyAPI()
        self.comment_manager = comment_manager
        self.logger = get_module_logger('CopilotProxyManager')
        self.retry_attempts = 3
        self.wait_time = 5

    def parse_code_from_comment(self, comment_text: str) -> Tuple[str, str]:
        """
        Parses the code snippet from a comment text that starts and ends with triple backticks (```)
        and extracts the language and code snippet. It captures lines starting with `+` and ensures code consistency.

        Args:
        - comment_text (str): The comment text containing the code snippet.

        Returns:
        - tuple: A tuple containing the language of the code snippet and the code snippet itself.
        """
        self.logger.debug(f'Parsing code from comment text: {comment_text}')
        lines = comment_text.split('\n')
        code_snippet_lines = []
        inside_code_snippet = False
        language = ""
        capture_lines = False

        for line in lines:
            if '```' in line:
                if inside_code_snippet:
                    break
                else:
                    inside_code_snippet = True
                    language = line.strip('```').strip()
                    continue
            if inside_code_snippet:
                if line.lstrip().startswith('+'):
                    capture_lines = True
                    code_snippet_lines.append(line.lstrip('+').strip())
                elif capture_lines:
                    if line.strip() == "":
                        code_snippet_lines.append(line.strip())
                    else:
                        break

        code_snippet = '\n'.join(code_snippet_lines)
        return language, code_snippet

    def post_code_to_copilotproxy(self, comments: List[Comment], pr: PrInfo, query: Query) -> None:
        """
        Posts the code snippet from a comment to the CopilotProxy API for processing.

        Args:
        - comments (List[Comment]): The list of Comment objects containing the code snippets to post.
        - pr (PrInfo): The PR information.
        - query (Query): The query information.
        """
        for comment in comments:
            comment_type = comment.get_comment_type()
            if comment_type == 'review':
                language, code_snippet = self.parse_code_from_comment(comment.get_text())

                if code_snippet:
                    data = {
                        "org": "SW Infra",
                        "commit_id": pr.get_pr_base_commit_id(),
                        "pull_request_id": pr.get_pr_number(),
                        "user_id": pr.get_pr_author_id(),
                        "request_url": "N/A",
                        "language": language,
                        "editor": "vscode/1.82.2",
                        "plugin": "ai-code-review/1.0.0",
                        "model": query.get_model(),
                        "ui_type": "Unknown",
                        "file_name": comment.get_filename(),
                        "file_path": comment.get_filename(),
                        "ai_code": code_snippet,
                        "source_application": "AICodeReview",
                        "prompt_excerpt": "string",
                        "prompt_tokens": 0,
                        "suffix_tokens": 0
                    }
                    prep_data = self.copilot_proxy_api.prepare_ai_tracking_data(**data)

                    for attempt in range(1, self.retry_attempts + 1):
                        try:
                            self.copilot_proxy_api.ai_tracking(prep_data)
                        except requests.exceptions.HTTPError as e:
                            self.logger.error(f"HTTPError occurred: {e}. Attempt {attempt} of {self.retry_attempts}.")
                            if attempt < self.retry_attempts:
                                time.sleep(self.wait_time)
                            else:
                                self.logger.error("Max attempts reached. Continuing to the next comment.")
                        except Exception as e:
                            self.logger.error(f"Unexpected error occurred: {e}. Continuing to the next comment.")
                            break
                else:
                    self.logger.info('Skipping empty code snippet. Continuing to the next comment...')
