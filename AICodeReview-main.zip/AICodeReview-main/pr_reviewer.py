import argparse
import sys
from datetime import datetime
import json

from logger import get_module_logger
from github_api import GithubAPI
from pr_info import PrInfo
from github_get_diff import GithubGetDiff
from github_post_comment import GithubPostComment
from llm_manager import LLMManager
from query_manager import QueryManager
from comment_manager import CommentManager
from query import Query
from io_utility import IOUtility
from database import DatabaseManager
from exception_logger_db import ExceptionLoggerDB
from post_process_comment_manager import PostProcessCommentManager
from elk_manager import ElkManager
from copilotproxy_manager import CopilotProxyManager

class Reviewer():
    """Class that reviews a given PR.
    """
    summarize_threshold = 1

    def __init__(self,
                pr_url: str,
                llm_token: str,
                ghe_token: str,
                queries_files = ['queries/sample_queries.json'],
                whitelist_file = 'white_list_ext.json',
                black_list_file = 'black_list_ext.json',
                diff_type = 'file',
                save_debug_log = True,
                post_comment = False,
                force_full_diff = False,
                log_to_db = True,
                post_test_comment = False
                ) -> None:

        self.program_start_time = datetime.utcnow().replace(microsecond=0) # use utc timezone for consistency with github
        # setup loggers
        self.logger = get_module_logger('REVIEWER')
        self.query_debug_log = {'Token Usage': []}
        self.logger.info(f'Running AI Code Review on PR URL: {pr_url}')
        self.exit_issue_level = 0 # initialized to 0

        # setup url, queries_files, and whitelist_file
        self.pr_url = pr_url
        self.queries_files = queries_files
        self.whitelist_file = whitelist_file
        self.black_list_file = black_list_file

        # setup behaviour
        self.save_debug_log = save_debug_log
        self.post_comment = post_comment
        self.diff_type = diff_type
        self.force_full_diff = force_full_diff
        self.log_to_db = log_to_db
        self.post_test_comment = post_test_comment

        # setup tokens
        self.ghe_token = ghe_token
        self.llm_token = llm_token

        self.initialize_components()


    def initialize_components(self) -> None:
        """This function initializes a set of managers needed to run the AI Code Review Pipeline.
        It creates instances of GithubManager, LLMManager, QueryManager, and CommentManager.
        """
        try:
            self.logger.info(f'Initializing components...')
            with open('project_settings.json') as parameters:
                project_settings     = json.load(parameters)
            # load components
            self.io                  = IOUtility(project_settings["IOUtility"])
            self.elk                 = ElkManager()
            self.github_api          = GithubAPI(project_settings["GithubAPI"], self.ghe_token)
            self.pr_info             = PrInfo(project_settings["PrInfo"], self.github_api, self.pr_url)
            self.github_get_diff     = GithubGetDiff(project_settings["GithubGetDiff"],self.github_api, self.pr_info, self.whitelist_file, self.force_full_diff, self.elk)
            self.github_post_comment = GithubPostComment(project_settings["GithubPostComment"], self.github_api, self.pr_info, self.elk)
            self.llm_manager         = LLMManager(project_settings["LLMManager"], self.llm_token)
            self.query_manager       = QueryManager(project_settings["QueryManager"], self.queries_files, self.post_test_comment)
            self.comment_manager     = CommentManager(project_settings["CommentManager"])
            self.post_process_comment_manager = PostProcessCommentManager(self.llm_manager,
                                                                  self.comment_manager,
                                                                  self.elk,
                                                                  self.github_api,
                                                                  self.pr_info,
                                                                  project_settings["PostProcessCommentManager"],
                                                                  self.force_full_diff)
            self.copilot_proxy_manager = CopilotProxyManager(self.comment_manager)
            # setup class settings
            self.load_reviewer_settings(project_settings["Reviewer"])

        except Exception as e:
            self.logger.exception(e)
            if hasattr(self, 'exceptions_logger'):
                self.elk.log_exception(e, getattr(self, 'pr_info', None), self.pr_url)
            raise


    def load_reviewer_settings(self, reviewer_settings: dict) -> None:
        """Load configuration settings

        Args:
            reviewer_settings (dict): dict constructed from settings fule
        """
        self.max_files_to_review = reviewer_settings["max_files_to_review"]


    def generate_ai_response_by_query(self, query: Query, diffs: dict[str, str], full_files: dict[str, str], function_contexts: dict[str, str]) -> int:
        """Generates AI responses based on a query and optionally posts them as comments on GitHub.
            Processes each query, prepares an AI prompt, retrieves AI responses, and formats them as comments.

        Args:
            query (Query): A Query object
            diffs (dict[str, str]): A list of diffs to process
            full_files (dict[str, str]): A list of file blobs to provide extra context for diffs
        Returns:
            int: number of posted comments
        """
        if query.get_comment_type() == 'deprecated':
            self.logger.debug('Query is deprecated. Skipping...')
            return 0
        num_of_left_issue_comments = self.post_process_comment_manager.get_num_of_left_issue_comments()
        if num_of_left_issue_comments <= 0:
            self.logger.debug(f'Number of left issue comments is {num_of_left_issue_comments}')
            return 0

        max_prompt_length = self.llm_manager.get_max_prompt_length(query.get_engine())
        prompts = self.query_manager.prepare_prompts(query, diffs, full_files, function_contexts, max_prompt_length)

        self.logger.info(f'Generating response for query: {query.get_short_name()}')
        llm_responses = self.llm_manager.get_responses(prompts, query.get_engine(), query.get_model())

        comments = self.comment_manager.create_comments(query, llm_responses)
        if not comments:
            self.logger.debug('No comments generated after LLM response. Skipping...')
            return 0
        comments = self.post_process_comment_manager.handle_post_process_prompt(query, comments, len(diffs))
        if not comments:
            self.logger.debug('No comments generated after post-processing. Skipping...')
            return 0
        self.comment_manager.update_comment_text(query, comments)
        if self.post_comment:
            self.github_post_comment.post_comments(comments)
        # send AI generated code to CopilotProxy
        self.copilot_proxy_manager.post_code_to_copilotproxy(comments, self.pr_info, query)
        return len(comments)


    def generate_ai_responses(self) -> None:
        """Generates responses from the LLM over a list of queries
        """
        query_short_name = 'default'
        try:
            queries = self.query_manager.get_queries()
            diffs = self.github_get_diff.get_diffs(self.diff_type)
            full_files = {}
            function_contexts = {}
            # Expected behaviour:
            # If force_full_context, need to get full files AND function context just in case, but use full context as primary.
            # If force_func_context and not force_full_context, need to get full files AND function context, but just pass in function context.
            # If both, do same as force_full_context.

            #Need to collect function context if any context_level is not diff
            if any(query.get_context_level() != 'diff' for query in queries):
                full_files = self.github_get_diff.get_full_files()

                full_base_files = self.github_get_diff.get_full_base_files()
                function_contexts = self.github_get_diff.get_function_contexts(full_files, full_base_files)

            self.num_files = len(diffs)
            self.logger.debug(f'Reviewing {self.num_files} whitelisted files')
            if self.num_files > self.max_files_to_review:
                self.logger.warning(f'Whitelisted Files: {self.num_files} > Max Files: {self.max_files_to_review}! Ignoring PR...')

                return
            if self.num_files == 0:
                self.logger.info('No whitelist files. Ignoring PR...')
                return
            for query in queries:
                query_short_name = query.get_short_name()

                # Pass in the appropriate info based on context level
                context_level = query.get_context_level()
                if context_level == 'full':
                    num_generated_comments = self.generate_ai_response_by_query(query, diffs, full_files, function_contexts)
                elif context_level == 'function':
                    num_generated_comments = self.generate_ai_response_by_query(query, diffs, {}, function_contexts)
                else:
                    num_generated_comments = self.generate_ai_response_by_query(query, diffs, {}, {})

                self.update_exit_issue_level(num_generated_comments, query)
                if self.save_debug_log: self.save_debug_info(query_short_name)
            # log API usage once all queries are processed
            self.log_api_usage()
        except Exception as e:
            self.logger.exception(f"An error occurred! {e}", exc_info=True)
            if hasattr(self, 'exceptions_logger'):
                self.elk.log_exception(e, getattr(self, 'pr_info', None), self.pr_url)
            if self.save_debug_log: self.save_debug_info(query_short_name)
            raise


    def collect_debug_info(self) -> dict[str, str]:
        """Retrieves debug data from other components and saves into dict

        Returns:
            dict[str, str]: prepared debug content
        """
        debug = {
            "Program Start Timestamp": self.program_start_time.strftime('%Y-%m-%d_%H:%M:%S'),
            "PR Info Details": self.pr_info.get_debug_info(),
            "GitHub Post Comment Details": self.github_post_comment.get_debug_info(),
            "LLM Details": self.llm_manager.get_debug_info(),
            }
        self.pr_info.reset_debug()
        self.github_post_comment.reset_debug()
        self.llm_manager.reset_debug()
        return debug


    def save_debug_info(self, query_short_name: str) -> None:
        """Collect and save debug info to a file with strucutre of `debug/repo/pull/short_name.json`.

        Args:
            query (Query): query for which to create a debug file
        """
        debug_info = self.collect_debug_info()
        self.io.save_debug_info(debug_info, query_short_name, self.pr_info.get_repository(), self.pr_info.get_pr_number())


    def log_api_usage(self) -> None:
        if hasattr(self, 'pr_info'):

            # Call the ElkManager log_api_usage function
            self.elk.log_api_usage(self.pr_info.get_repository(), self.pr_url, self.github_api.get_num_api_calls(),
                                  self.llm_manager.get_num_llm_api_calls(), self.llm_manager.get_num_llm_total_tokens(),
                                  self.llm_manager.get_avg_llm_time_in_ms(), self.num_files)

    def update_exit_issue_level(self, num_comments: int, query: Query) -> None:
        """Update the class-level exit code based on whether comments were made for this query

        Args:
            num_comments (int): the number of comments made
            query (Query): the current Query
        """
        if num_comments > 0:
            self.logger.info(f'AI Code Review generated {num_comments} comments for {query.get_short_name()}!')
            self.exit_issue_level = max(self.exit_issue_level, query.get_exit_issue_level())


    def get_program_exit_code(self) -> int:
        """Returns the exit_code of the program
        """
        exit_code = self.exit_issue_level
        self.logger.info(f'Returning with Exit code: {exit_code}')
        return exit_code


    def check_blacklist_paths(self) -> bool:
        """Check if any of the changed file paths in the PR match the paths from the blacklist, including owner and repo.
    
        Args:
            pr_info (dict[str, str]): Dictionary containing PR information including owner, repository, and PR number.
    
        Returns:
            bool: True if any of the changed file paths match the paths from the blacklist, False otherwise.
        """
        try:
            self.logger.info(f'Reading blacklisted paths data from {self.black_list_file}...')
            with open(self.black_list_file, 'r') as file:
                blacklist_entries = json.load(file)
        except FileNotFoundError as fnf_error:
            self.logger.error(f"Blacklist file not found: {fnf_error}")
            return False
        except json.JSONDecodeError as json_error:
            self.logger.error(f"Error decoding JSON from blacklist file: {json_error}")
            return False
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while reading the blacklist file: {e}")
            return False
    
        try:
            pr_owner = self.pr_info.get_owner()
            pr_repo = self.pr_info.get_repository()
            changed_files = self.github_api.get_changed_files(pr_owner, pr_repo, self.pr_info.get_pr_number())
        except Exception as e:
            self.logger.error(f"An error occurred while fetching changed files: {e}")
            return False
    
        try:
            for file_path in changed_files:
                for entry in blacklist_entries:
                    if pr_owner == entry['owner'] and pr_repo == entry['repo'] and file_path.startswith(entry['path']):
                        return True
        except Exception as e:
            self.logger.error(f"An error occurred while checking the blacklist paths: {e}")
            return False
    
        return False


def run_single_pr(args, pr_url:str) -> int:
    """Runs the review process for a single pull request URL using the provided arguments.

    Args:
        args (Namespace): A namespace object containing the required arguments for the review process.
        pr_url (str): The pull request URL to be reviewed.
    """
    # initialize an empty list in the JSON file at the start of each PR review

    reviewer = Reviewer(pr_url = pr_url,
                        llm_token = args.llm_token,
                        ghe_token = args.ghe_token,
                        queries_files = args.json_queries.split(','),
                        whitelist_file = args.json_white_list_ext,
                        black_list_file= args.json_black_list_ext,
                        diff_type = args.diff_type,
                        save_debug_log = bool(args.debug),
                        post_comment = bool(args.post_comments),
                        force_full_diff = bool(args.force_full_diff),
                        log_to_db = bool(args.log_to_db),
                        post_test_comment = bool(args.post_test_comment)
                        )
    if reviewer.check_blacklist_paths():
        reviewer.logger.info('PR contains blacklisted paths. Skipping...')
        return 0
    reviewer.generate_ai_responses()
    return reviewer.get_program_exit_code()


def multiple_run(args) -> None:
    """Running multiple PRs.
    Args:
        parsed_args: parsed args from a user
    """
    with open(args.pr_list_file, "r") as file:
        pr_urls = [line.rstrip('\n') for line in file if line.strip()]

    for pr_url in pr_urls:
        exit_code = run_single_pr(args, pr_url)
        print(f'Exit Code: {exit_code} for PR: {pr_url}')


if __name__ == "__main__":
    try:
        # parse arguments
        parser = argparse.ArgumentParser(description='')
        parser.add_argument('-pr_url', '-u', type=str, help='URL to PR')
        parser.add_argument('-post_comments', type=int, default=1,
                            help='default 1, posts comments to PR. 0 does not')
        parser.add_argument('-force_full_diff', type=int, default=0,
                            help='defaults to 0, use the last posted comment to determine diff. 1 uses full diff')
        parser.add_argument('-debug', type=int, default=1,
                            help='default 1, saves debug information. 0 suppresses.')
        parser.add_argument('-pr_list_file', '-l', type=str, default='',
                            help='a path to a file with list of pr urls')
        parser.add_argument('-json_queries', '-q',  type=str, default='queries/sample_queries.json',
                            help='paths to different JSON files with queries')
        parser.add_argument('-json_white_list_ext', '-wl', type=str, default='white_list_ext.json',
                            help='a path to json with white list extensions')
        parser.add_argument('-json_black_list_ext', '-bl', type=str, default='black_list_ext.json',
                            help='a path to json with black list extensions')
        parser.add_argument('-diff_type', '-dt', type=str, default='file',
                            help='whether to pass LLM diff for entire pr, each file or each hunk')
        parser.add_argument('-llm_token', '-llm', type=str,
                            help='token for LLM API')
        parser.add_argument('-ghe_token', '-ghe', type=str,
                            help='token for GHE API')
        parser.add_argument('-log_to_db', type=int, default=1,
                            help="enable/disable logging to database (1 to enable, 0 to disable)")
        parser.add_argument('-post_test_comment', type=int, default=0,
                            help="post AI comments with test header to prevent dev confusion (1 to enable, 0 to disable)")
        args = parser.parse_args()

        exit_code = 0
        if args.pr_url:
            exit_code = run_single_pr(args, args.pr_url)
        if args.pr_list_file:
            multiple_run(args) # dont set exit code, instead just print it for each pr_url run
        sys.exit(exit_code)

    except Exception as e:
        sys.exit(-1)
