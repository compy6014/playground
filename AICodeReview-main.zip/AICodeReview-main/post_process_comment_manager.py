from query import Query
from comment import Comment
from logger import get_module_logger
from exceptions import CommonException
from comment_manager import CommentManager
from llm_manager import LLMManager
from database import DatabaseManager
from elk_manager import ElkManager
from github_api import GithubAPI
from pr_info import PrInfo
import json
import re
import ast


class PostProcessCommentManager:
    def __init__(self,
                llm_manager: LLMManager,
                comment_manager: CommentManager,
                db_manager:ElkManager,
                github_api: GithubAPI,
                pr_info: PrInfo,
                post_process_handler_settings: dict[str, str],
                force_full_diff = False):
        """
        Args:
            llm_manager: A Language Learning Model manager instance.
            comment_manager: A Comment manager instance.
            post_process_handler_settings (dict): Settings for the post process handler.
                Should contain "logger_name", "description_max_summary_points",
                "potential_issues_max_comments", and "code_clarity_issues_max_comments".
        """
        self.logger = get_module_logger(
            post_process_handler_settings.get("logger_name"))
        if not self.logger:
            raise CommonException(
                "No logger_name in PostProcessCommentManager settings")
        self.post_process_handler_settings = post_process_handler_settings
        self.llm_manager = llm_manager
        self.comment_manager = comment_manager
        self.db_manager = db_manager
        self.github_api = github_api
        self.pr_info = pr_info
        self.force_full_diff = force_full_diff
        self.num_of_left_issue_comments = self.post_process_handler_settings.get(
            "issues_max_comments")
        self.issues_confidence_threshold = self.post_process_handler_settings.get(
            "issues_confidence_threshold")
        self.issues_significance_threshold = self.post_process_handler_settings.get(
            "issues_significance_threshold")
        self.description_max_num_of_comments = self.post_process_handler_settings.get(
            "description_max_summary_points")

    def handle_post_process_prompt(self,
                                   query: Query,
                                   comments: list[Comment],
                                   num_of_diffs: int) -> list[Comment]:
        """
        Args:
            query (Query): The input Query.
            comments (list[Comment]): The list of comments generated.
            num_of_diffs (int): The number of diifs(whitelist files).

        Returns:
            list[Comment]: Either the original comments list or a new set of comments based on the post_process.
        """
        if not comments:
            return []

        self.logger.info(f"Post process {query.get_short_name()} comments")
        if query.get_comment_type() == "conversation":
            return self.handle_post_process_prompt_common(query, comments, num_of_diffs, self.description_max_num_of_comments)
        old_comments_body = []
        if not self.force_full_diff:
            old_comments_body = self.get_all_previous_pr_comments(query)
        return self.handle_post_process_prompt_issues(query, comments, old_comments_body, self.num_of_left_issue_comments)

    def get_all_previous_pr_comments(self, query: Query) -> list[str]:
        """
        Retrieve all previous pull request comments except those with the 'description' issue type.
        Args:
            query (Query): The input query.

        Returns:
            list[str]: A list containing the comment bodies of previous pull request comments.
        """
        comments_list_dict = self.db_manager.read_latest_comment_data_by_pr(
            self.pr_info.get_owner(),
            self.pr_info.get_repository(),
            int(self.pr_info.get_pr_number()),
            False
        )
        
        comments_body_list = []
        for comment_dict in comments_list_dict:
            if comment_dict['issue_type'] == 'description':
                continue
            base_url = self.github_api.amd_base_api_url
            comment_url = base_url + f"{comment_dict['owner']}/{comment_dict['repository']}/pulls/comments/{comment_dict['comment_id']}"
            comment_body = self.github_api.get_comment_body(comment_url)
            if not comment_body:
                continue
            comment_body = comment_body.removeprefix(query.get_response_header())
            comment_body = comment_body.removesuffix(query.get_response_footer())
            comments_body_list.append(comment_body)
        return comments_body_list

    def get_num_of_left_issue_comments(self) -> int:
        '''Returns:
            int: number of leftissue comments
        '''
        return self.num_of_left_issue_comments

    def handle_post_process_prompt_common(self, query: Query, comments: list[Comment], num_of_comments: int, max_num_of_ai_comments: int) -> list[Comment]:
        """Performs the same routine as generate_ai_response_by_query, but using comments already created.

        Args:
            query (Query): the input Query
            comments (list[Comment]): the list of comments generated
            num_of_comments (int): number of comments(). Somtimes there are 5 points in 1 comment (num_of_comments will be 5)
            max_num_of_ai_comments: The maximum number of AI comments allowed for the given query.

        Returns:
            list[Comment]: either the original comments list or a new set of comments based on the post_process
        """
        if not query.get_post_process_prompt() or num_of_comments < max_num_of_ai_comments:
            return comments

        comment_string = '\n'.join([c.get_text() for c in comments])
        post_process_prompt_str = query.get_post_process_prompt() + comment_string
        post_process_prompt = {'post_process': [post_process_prompt_str]}
        llm_responses = self.llm_manager.get_responses(post_process_prompt, query.get_engine(), query.get_model())
        comments = self.comment_manager.create_comments(query, llm_responses)

        return comments

    def parse_significance(self, llm_response: str) -> dict[int, int]:
        """
        Parse a string containing a dictionary with integer keys and values.
        Args:
            llm_response (str): A string containing a dictionary with integer keys and values.
        Returns:
            dict[int, int]: A dictionary with integer keys and values.
        """
        regex = r"\{[^{]*?(\d+|\"?\d+\"?|'?\d+'?): ?-?\d+(, ?((\d+|\"?\d+\"?|'?\d+'?): ?-?\d+))*[^}]*?\}"
        match = re.search(regex, llm_response)

        if match:
            dict_str = match.group(0)
            output_dict = ast.literal_eval(dict_str)
            return {int(k): int(v) for k, v in output_dict.items()}
        else:
            return {}

    def update_comments_significance(self, comments: list[Comment], ranked_dict: dict[int, int], num_of_old_comments: int) -> None:
        """
        Update the significance score of the given comments based on the rank dictionary.

        Args:
            comments (list[Comment]): A list of comments.
            ranked_dict (dict[int, int]): A dictionary containing index-to-rank mappings.
        """
        if ranked_dict and ((len(ranked_dict)-num_of_old_comments) == len(comments)):
            new_comments_dict = {key: value for key, value in list(ranked_dict.items())[num_of_old_comments:]}
            self.logger.info(f"New comments significance rank: {new_comments_dict}")
            for comment_ind, significance_score in new_comments_dict.items():
                comment_ind -= num_of_old_comments
                if comment_ind < len(comments):
                    comments[comment_ind].set_significance_score(significance_score)
        else:
            if not ranked_dict:
                self.logger.warning("Ranked dictionary is empty")
            elif (len(ranked_dict)-num_of_old_comments) != len(comments):
                self.logger.warning(f"Bad parsing! Rank dictionary size: {len(ranked_dict)}. The number of old comments: {num_of_old_comments}. The number of new comments: {len(comments)}")


    def filter_output_comments(self, comments: list[Comment], confidence_threshold: int, significance_threshold: int, max_num_issues: int) -> list[Comment]:
        """
        Filter output comments based on the confidence threshold, significance threshold, and maximum summary points.

        Args:
            comments (list[Comment]): A list of comments.
            confidence_threshold (int): The confidence threshold for filtering comments.
            significance_threshold (int): The significance threshold for filtering comments.
            max_num_issues (int): The maximum number of summary points allowed.

        Returns:
            list[Comment]: A list of filtered comments.
        """
        if not comments:
            return []
        filtered_in_comments = []

        comments.sort(key=lambda x: x.get_confidence_score(), reverse=True)
        message_before_filtering = "Before filtering commmets are: "
        message_after_filtering = "After filtering commmets are: "
        for ind, comment in enumerate(comments):
            confidence_score = comment.get_confidence_score()
            significance_score = comment.get_significance_score()
            message_before_filtering += f"{{{ind}: c:{int(comment.get_confidence_score())},s:{comment.get_significance_score()}}}, "
            if confidence_score < confidence_threshold or (significance_score < significance_threshold and significance_score != 0.0) or len(filtered_in_comments) >= max_num_issues:
                continue
            filtered_in_comments.append(comment)
            message_after_filtering += f"{{{ind}: c:{int(comment.get_confidence_score())},s:{comment.get_significance_score()}}}, "

        self.logger.info(message_before_filtering)
        if filtered_in_comments:
            self.logger.info(message_after_filtering)
        return filtered_in_comments

    def handle_post_process_prompt_issues(self, query: Query, comments: list[Comment], old_comments_body: list[str], max_num_of_ai_comments: int) -> list[Comment]:
        """
        Args:
            query (Query): The input Query.
            comments (list[Comment]): The list of comments generated.
            max_num_of_ai_comments (int): The maximum number of AI comments allowed for the given query.

        Returns:
            list[Comment]: Either the original comments list or a new set of comments based on the post_process.
        """
        comment_dict = {}
        if old_comments_body:
            for i, comment in enumerate(old_comments_body):
                comment_dict[i] = {"comment": comment}

        new_comments = comments
        for j, comment in enumerate(new_comments):
            comment_dict[len(old_comments_body)+j] = {"comment": comment.get_text()}

        old_plus_new_comments_str = json.dumps(comment_dict, indent=2)
        post_process_prompt_str = query.get_post_process_prompt() + old_plus_new_comments_str
        post_process_prompt = {'post_process': [post_process_prompt_str]}
        llm_response = self.llm_manager.get_responses(post_process_prompt, query.get_engine(), query.get_model())
        if not llm_response:
            self.logger.warning("PostProcessing Manager: LLM Response is empty!")
            return comments
        try:
            llm_response_str = llm_response['post_process']
            ranked_dict = self.parse_significance(llm_response_str)
            self.update_comments_significance(comments, ranked_dict, len(old_comments_body))
            filtered_in_comments = self.filter_output_comments(
                comments, self.issues_confidence_threshold, self.issues_significance_threshold, max_num_of_ai_comments)
            num_of_filtered_comments = len(filtered_in_comments)
            self.num_of_left_issue_comments -= num_of_filtered_comments
            self.logger.info(
                f"Number of filtered comments is {num_of_filtered_comments}. Max number of issue comments left: {self.num_of_left_issue_comments}")

            return filtered_in_comments
        except ValueError as e:
            self.logger.warning(
                f"Error in handle post process parse output: {llm_response['post_process']}. {e}. Posting all the comments without cutting")
            return comments
