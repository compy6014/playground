import json
import re
from logger import get_module_logger
from query import Query
from llm_manager import LLMManager

class QueryManager():
    """Class that prepares queries from given query files and uses this to prepare prompts for an LLM
    """
    def __init__(self, query_manager_settings: dict, queries_files: list, post_test_comment: bool) -> None:
        self.queries_files = queries_files
        self.logger = get_module_logger(query_manager_settings["logger_name"])
        self.post_test_comment = post_test_comment


    def get_queries(self) -> list[Query]:
        """Return a list of Query objects from a list of files containing query data.

        Args:
            queries_files (list): list of query files

        Returns:
            list[Query]: list of queries
        """
        queries = []
        self.logger.info('Constructing queries...')
        for query_file in self.queries_files:
            data = self.read_data_from_json(query_file)
            if not data:
                continue
            common_data = data.pop(0) # first dict always contains common data
            self.load_common_query_data(common_data)
            for query_data in data:
                query = self.create_query_from_dict(query_data)
                queries.append(query)

        return queries


    def read_data_from_json(self, queries_file: str) -> list[dict]:
        """Returns the query information stored in queries_file

        Args:
            queries_file (str): file containing query data stored as json

        Returns:
            list[dict]: list of query data from a json
        """
        self.logger.info(f'Reading query data from {queries_file}...')
        try:
            with open(queries_file, 'r', encoding="utf-8") as json_file:
                data = json.load(json_file)
            return data
        except FileNotFoundError:
            self.logger.debug(f'File {queries_file} not found. Skipping...')
            return []


    def load_common_query_data(self, data: dict[str, str]) -> None:
        """Saves common query data to instance attributes e.g. response header and footer.

        Args:
            data (dict[str, str]): common data across queries
        """
        for key, value in data.items():
            setattr(self, key, value)


    def create_query_from_dict(self, query: dict[str, str]) -> Query:
        """Creates a query instance from a given a dictionary representing a query.

        Args:
            query (dict[str, str]): dict representing a query

        Returns:
            Query: initialized query object
        """
        header = self.common_header
        if self.post_test_comment:
            header = self.common_header_test
        query['response_header'] = header + query['response_header']
        query['response_footer'] = self.common_footer + query['response_footer']
        query_obj = Query(**query)
        return query_obj

    def split_into_hunks(self, diff: str) -> dict[str, str]:
        """
        Split the diff into hunks and return a dictionary where keys are hunk notations and values are hunk diffs.
        Parameters:
            diff (str): A string containing the diff of a file.
        Returns:
            dict[str, str]: A dictionary where keys are hunk notations, and values are hunk diffs.
        """
        hunks = re.findall(r'@@ -\d+,\d+ \+\d+,\d+ @@', diff)
        hunk_dict = {hunk: diff.split(hunk, 1)[1].split('@@', 1)[0] for hunk in hunks}
        return hunk_dict


    def filter_added_code_only_diffs(self, diffs: dict[str,str]) -> dict[str, str]:
        """
        Filter the added code hunks from the diffs and return a dictionary where keys are filenames and values are added code hunks.
        Parameters:
            diffs (dict[str, str]): A dictionary where keys are filenames, and values are the diffs corresponding to each file.
        Returns:
            dict[str, str]: A dictionary where keys are filenames, and values are added code hunks.
        """
        self.logger.info("Filtering added code only")
        added_code_only_diffs = {}
        for filename, file_diff in diffs.items():
            hunk_dict = self.split_into_hunks(file_diff)
            file_diff = ""
            for hunk_notation, hunk_diff in hunk_dict.items():
                are_added_lines = self.check_for_added_lines(hunk_diff)
                if not are_added_lines:
                    continue
                modified_text = self.remove_minus_lines(hunk_diff)

                lines = modified_text.split('\n')
                # Discard the first line (Example @@ -30,7 +30,6 @@ class SceneDetection)
                modified_text = '\n'.join(lines[1:])
                modified_text = modified_text.strip('\n')

                file_diff += hunk_notation + '\n' + modified_text + '\n\n'
            if file_diff:
                added_code_only_diffs[filename] = file_diff

        return added_code_only_diffs


    def check_for_added_lines(self, hunk_diff:str) -> bool:
        """
        Check if there are any added lines in the hunk. Return True if added lines are found, False otherwise.
        Parameters:
            hunk_diff (str): A string containing the hunk diff.
        Returns:
            bool: True if added lines are found, False otherwise.
        """
        lines = hunk_diff.split('\n')
        return any(line.startswith('+') for line in lines)


    def remove_minus_lines(self, hunk_diff:str) -> str:
        """
        Remove minus lines from the hunk diff and return the modified hunk diff.
        Parameters:
            hunk_diff (str): A string containing the hunk diff.
        Returns:
            str: The modified hunk diff with minus lines removed.
        """
        # Split the text into lines
        lines = hunk_diff.split('\n')

        # Iterate through each line in reverse order
        for i in reversed(range(len(lines))):
            # If the line starts with a '-', remove the line
            if lines[i].startswith('-'):
                lines.pop(i)
        modified_text = '\n'.join(lines)
        return modified_text


    def prepare_prompts(self, query: Query, diffs: dict[str, str], full_files: dict[str, str], function_contexts: dict[str, str], max_prompt_length: int) -> dict[str, str]:
        """Returns a dict of prompts based on the input query and diffs

        Args:
            query (Query): the query to evaluate
            diffs (dict[str, str]): keys are identifiers, values are diffs
            full_files (dict[str, str]): keys are identifiers, values are entire file blobs
            max_prompt_length (int): The max prompt length passed in from the LLMManager Class

        Returns:
            dict[str, str]: dict of prompts with same keys as diffs
        """
        self.logger.info(f'Preparing prompts for query: {query.get_short_name()}')
        if query.use_only_added_code():
            diffs = self.filter_added_code_only_diffs(diffs)
        all_prompts = {}

        def add_extension(context):
            # Add the context to the prompt if it fits
            extension = extension_text + context[filename] + "\n```"
            if len(prompts[0] + extension) < max_prompt_length:
                prompts[0] += extension
                return True
            return False

        for filename, diff in diffs.items():
            prompts = [query.get_prompts()[0] + str(diff)] + query.get_prompts()[1:] # Add diff to first prompt; rest for handling LLM output

            # If full_files, try to provide the full file first, revert to function context if too much
            # If not full_files, but function_contexts, provide function context
            extension_text = "\n The following code, delimited by three backticks (```), defines the the overall context:\n```\n"
            if full_files:
                if not add_extension(full_files):
                    self.logger.info(f'Failed to add file level contexts for {filename}, adding function level')
                    add_extension(function_contexts)
            elif function_contexts:
                self.logger.info(f'Adding function level contexts for {filename}')
                add_extension(function_contexts)

            all_prompts[filename] = prompts

        return all_prompts
