import os
import json
from logger import get_module_logger
from exceptions import IOException

class IOUtility():

    def __init__(self, io_utility_settings: dict):
        self.logger = get_module_logger(io_utility_settings["logger_name"])


    def clean_newline_debug_log(self, data: dict[str, str]) -> None:
        """Modify the debug dictionary to render newline characters by converting them into elements of a list.

        Args:
            data (dict[str, str]): debug dictionary
        """
        if isinstance(data, dict):
            for key, value in data.items():
                if key in ['content', 'body', 'Responses']:
                    if isinstance(value, str): # only do this for specific keys
                        value = value.replace('\n\n', '\n')
                        data[key] = value.split('\n')[:-1]
                    elif isinstance(value, list):
                        for response_per_file in value:
                            if isinstance(response_per_file, dict):
                                for filename, response in response_per_file.items():
                                    if isinstance(response, str):
                                        response = response.replace('\n\n', '\n')
                                        response_per_file[filename] = response.split('\n')[:-1]
                else:
                    self.clean_newline_debug_log(value)
        elif isinstance(data, list):
            for item in data:
                self.clean_newline_debug_log(item)


    def save_debug_info(self, debug_info: dict[str, str], query_short_name: str, repo: str, pull_number: str) -> None:
        """Collect and save debug info to a file with strucutre of `debug/repo/pull/short_name.json`.

        Args:
            query (Query): query for which to create a debug file
        """
        json_debug_file_path = f'debug/{repo}/{pull_number}/{query_short_name}.json'
        self.logger.info(f'Saving to: {json_debug_file_path}')
        try:
            os.makedirs(os.path.dirname(json_debug_file_path), exist_ok=True)
            with open(json_debug_file_path, "w") as f:
                self.clean_newline_debug_log(debug_info)
                json_data = json.dumps(debug_info, indent=2, ensure_ascii=False)
                f.write(json_data)
        except Exception as e:
            self.logger.error(f'Failed to create or write to {json_debug_file_path}. {str(e)}', exc_info=True)
            raise IOException(f'Failed to create or write to {json_debug_file_path}. {str(e)}')
