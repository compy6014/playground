import requests
import json
from requests.exceptions import HTTPError, RequestException
from datetime import datetime, timedelta
import io
import logging

BASE_URL = "https://copilotproxy.amd.com"
API_KEY = "+DBml2Iv5MSm4+68chUVGrTOFq1Va89IImgWlUPRYplwm2PtB6wZljkZJL/3zMO10A2eRbjn7vnIo5CpSfTf/w=="

class CopilotProxyAPI():
    def __init__(self) -> None:
        self.headers = {
            "Content-Type": "application/json",
            "X-API-Key": API_KEY
        }

    def _post_request(self, endpoint, headers, **kwargs):
        try:
            response = requests.post(f"{BASE_URL}{endpoint}", headers=headers, verify=False, **kwargs)
            response.raise_for_status()
            return response
        except HTTPError as http_err:
            logging.error(f"HTTP error occurred: {http_err}")
            raise
        except RequestException as req_err:
            logging.error(f"Request error occurred: {req_err}")
            raise
        except Exception as e:
            logging.error(f"An error occurred: {e}")
            raise

    def ai_tracking(self, data):
        endpoint = "/api/v1/AITracking"
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": API_KEY
        }
        response = self._post_request(endpoint, headers, data=json.dumps(data))
        if response.status_code == 204:
            print("AI Code data record created successfully. Returns no content.")

    def file_check(self, finalFilename, cutoffDays, file_content):
        endpoint = '/api/v1/FileCheck/fileCheck'
        headers = {'X-API-Key': API_KEY}
        cutoffDT = datetime.now() - timedelta(days=cutoffDays)
        params = {
            'cutOffDT': cutoffDT.strftime('%Y-%m-%dT%H:%M:%SZ'),
            'minimumLength': 5,
            'searchAllRequests': True,
        }
        file_like_object = io.StringIO(file_content)
        files = {'file': (finalFilename, file_like_object)}

        response = self._post_request(endpoint, headers, params=params, files=files)
        if response.status_code == 200:
            print("AI code sections returned")
        return response.json()

    def patch_check(self, fileName, cutoffDays, patch_content):
        endpoint = '/api/v1/FileCheck/patchCheck'
        headers = {'Content-Type': 'text/plain',
                   'X-API-Key': API_KEY}
        cutoffDT = datetime.now() - timedelta(days=cutoffDays)
        params = {
            'fileName': fileName,
            'cutOffDT': cutoffDT,
            'minimumLength': 5,
            'searchAllRequests': True,
        }
        response = self._post_request(endpoint, headers, params=params, data=patch_content)
        if response.status_code == 200:
            print("AI code sections returned")
        return response.json()

    def prepare_ai_tracking_data(self, org: str, commit_id: str, pull_request_id: str, user_id: str, request_url: str, language: str, editor: str, plugin: str, model: str, ui_type: str, file_name: str, file_path: str, ai_code: str, source_application: str, prompt_excerpt: str, prompt_tokens: int, suffix_tokens: int):
        return [
            {
                "org": org,
                "commitId": commit_id,
                "pullRequestId": pull_request_id,
                "userID": user_id,
                "details": {
                    "requestURL": request_url,
                    "language": language,
                    "editor": editor,
                    "plugin": plugin,
                    "model": model,
                    "uI_Type": ui_type
                },
                "fileName": file_name,
                "filePath": file_path,
                "aiCode": ai_code,
                "sourceApplication": source_application,
                "promptExcerpt": prompt_excerpt,
                "promptTokens": prompt_tokens,
                "suffixTokens": suffix_tokens
            }
        ]