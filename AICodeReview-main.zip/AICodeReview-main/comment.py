from message import Message

class Comment(Message):
    """Class that stores comment-related data as an object
    """

    def get_lines(self) -> tuple[int]:
        """Returns the start and end line for a review comment

        Returns:
            tuple(int): integers representing start line, end line
        """
        start_line = getattr(self, 'start_line', 0)
        end_line = start_line + getattr(self, 'num_lines', 0) - 1
        return start_line, end_line


    def get_position(self) -> str:
        """Returns the position

        Returns:
            str: _description_
        """
        return getattr(self, 'position', '')


    def get_filename(self) -> str:
        return getattr(self, 'filename', '')


    def get_significance_score(self) -> float:
        """Return the significance score of the comment

        Returns:
            float: comment significance score
        """
        return float(getattr(self, 'significance_score', 0.0))


    def set_significance_score(self, significance_score:float) -> None:
        setattr(self, 'significance_score', significance_score)


    def get_confidence_score(self) -> float:
        """Return the confidence score of the comment

        Returns:
            float: comment confidence score
        """
        return float(getattr(self, 'confidence_score', 0.0))


    def set_confidence_score(self, confidence_score:float) -> None:
        setattr(self, 'confidence_score', confidence_score)


    def get_category(self) -> str:
        """Return the category of the comment

        Returns:
            str: comment category
        """
        return getattr(self, 'category', '')

