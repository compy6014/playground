# this contains code to run the influence rate script on a single
from influence_rate_from_llm import InfluenceRateManager
import argparse

def compute_influence(pr_url: str):
    print(f'Computing Influence For PR: {pr_url}')
    irm = InfluenceRateManager()
    comments = irm.get_total_influence(pr_url)
    influence_comments = comments[comments['influence_pred'] == 1]
    total_comments, num_influential = len(comments), len(influence_comments)
    print(f'Total Comments: {total_comments}. Influential Comments: {num_influential}. Influence Rate: {(num_influential/total_comments)*100:.2f}')
    print(f"Comment Links:\n{influence_comments['comment_url']}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-pr_url', type=str, help='URL to a PR')
    args = parser.parse_args()
    compute_influence(args.pr_url)
    
    