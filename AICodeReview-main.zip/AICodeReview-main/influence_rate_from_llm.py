import pandas as pd
from datetime import datetime
import json
import re

from llm_manager import LLMManager
from database import DatabaseManager
from github_api import GithubAPI
from elk_manager import ElkManager


class InfluenceRateManager():

    default_prompt_text = """
            In this task, you will be given three inputs related to a merged Github pull request:
            1. A code review comment made on a specific file of that pull request.
            2. Initial diff that the developer pushed to this file.
            3. Final diff of this file that was submitted for this file.

            Your task is to:

            1. Determine whether the review comment has been addressed between the Initial and Final code diffs. Provide a step-by-step explanation for your decision. If you are confident that the comment has been addressed, provide '1'. Otherwise, provide '0'.

            2. Compare the code review comment to the final code diff for similarity. If any parts of the code diff are similar to any of the code snippets in the comment, calculate the similarity using the Levenshtein distance. Then, calculate the percentage similarity as follows: (1 - (Levenshtein distance / max(len(code diff), len(comment)))) * 100.

            Your output should be in the following JSON format, but without ```json ```:
            {
              "explanation": "<your explanation>",
              "resolved": "<1 or 0>",
              "levenshtein_distance": "<Levenshtein distance>",
              "percent": "<percentage similarity>"
            }
            """

    def __init__(self, ghe_token: str = None, llm_token: str = None) -> None:
        self.log_to_db = False
        self.program_start_time = datetime.utcnow().replace(microsecond=0)
        self.ghe_token = ghe_token
        self.llm_token = llm_token
        self.cache = {}
        self.initialize_components()
        self.load_header_footer()

    def initialize_components(self) -> None:
        """This function initializes a set of managers needed
        """
        with open('project_settings.json') as parameters:
            project_settings     = json.load(parameters)
        self.db                  = DatabaseManager(project_settings["DatabaseManager"], self.log_to_db, self.program_start_time)
        self.github_api          = GithubAPI(project_settings["GithubAPI"], self.ghe_token)
        project_settings["LLMManager"]['deployment_id'] = 'swe-gpt4-8k-exp1'
        self.llm_manager         = LLMManager(project_settings["LLMManager"], self.llm_token)
        self.elk_manager         = ElkManager()

    def load_header_footer(self) -> None:
        with open('queries.json', 'r', encoding="utf-8") as json_file:
            queries = json.load(json_file)
        self.header = queries[0]['common_header']
        self.footer = queries[0]['common_footer']

    def get_pr_info(self, pr_url: str) -> tuple[str]:
        pattern = re.compile(r"https://github.amd.com\/([\w\-]+)\/([\w\-]+)\/pull\/(\d+)")
        match = re.match(pattern, pr_url)
        owner, repository, pr_number = match.groups()
        return owner, repository, pr_number

    def get_comments(self, owner, repository, pr_number) -> pd.DataFrame:
        comments = pd.DataFrame(self.elk_manager.read_latest_comment_data_by_pr(owner, repository, pr_number, single_comment=False))
        print(f'Retrieved {comments.shape[0]} comments from DB')
        comments['deleted'] = False
        comments = comments.apply(lambda row: self.create_comment_columns(row), axis=1)
        return comments

    def get_diffs(self, owner, repository, pr_number) -> dict[str, str]:
        diff_url = f"https://github.amd.com/api/v3/repos/{owner}/{repository}/pulls/{pr_number}.diff"
        diff_content = self.github_api.get_diffs(diff_url)
        diffs = {}
        filename_pattern = re.compile(r'a/(.+?) b/')
        for diff in diff_content.split('diff --git ')[1:]: # always ignore first element since its empty
            match = filename_pattern.search(diff) # find filename
            if not match:
                continue
            filename = match.group(1)
            diffs[filename] = diff
        return diffs

    def get_first_diffs(self, owner: str, repository: str, pr_number: int, filenames: list[str]) -> dict[str, str]:
        """Retrieves the first diff of each file in the PR.
    
        Args:
            owner (str): The owner of the repository.
            repository (str): The name of the repository.
            pr_number (int): The pull request number.
            filenames (list[str]): The list of filenames to retrieve diffs for.
    
        Returns:
            dict[str, str]: A dictionary where keys are filenames and values are the diffs.
        """
        # 1. Query to get list of list of commits
        commits_url = f"https://github.amd.com/api/v3/repos/{owner}/{repository}/pulls/{pr_number}/commits"
        response_text = self.github_api.get_url(commits_url)
        if response_text is None or not isinstance(response_text, str):
            raise CommonException("Error retrieving commits from github")
        commits = json.loads(response_text)
    
        if not commits:
            return {}
    
        first_diffs = {}
        for commit in commits:
            commit_sha = commit['sha']
            commit_url = f"https://github.amd.com/api/v3/repos/{owner}/{repository}/commits/{commit_sha}"
            commit_response = self.github_api.get_url(commit_url)
            if commit_response is None or not isinstance(commit_response, str):
                raise CommonException(f"Error retrieving commit {commit_sha}")
            commit_data = json.loads(commit_response)
    
            # 2. Get the first commit for each file
            for file in commit_data['files']:
                if file['filename'] in filenames and file['filename'] not in first_diffs:
                    # 3. Check if 'patch' key exists
                    if 'patch' in file:
                        first_diffs[file['filename']] = file['patch']
                    else:
                        print(f"No patch found for file {file['filename']} in commit {commit_sha}")
    
            # Stop if we have found a diff for each file
            if len(first_diffs) == len(filenames):
                break
    
        return first_diffs

    def get_reaction_value(self, reactions):
        if reactions['+1'] > 0:
            return 1
        elif reactions['-1'] > 0:
            return -1
        else:
            return 0

    def create_comment_columns(self, row):
        issue_type = 'pulls' if row['issue_type'] != 'description' else 'issues'
        url = f"https://github.amd.com/api/v3/repos/{row['owner']}/{row['repository']}/{issue_type}/comments/{row['comment_id']}"
        comment_data = self.github_api.get_comments(url)
        if not comment_data:
            row['deleted'] = True
            row['reaction'] = 0
            return row

        if issue_type == 'pulls':
            row["comment_text"] = comment_data["body"].replace(self.header, '').replace(self.footer, '')
            row["comment_file"] = comment_data["path"]

        row['reaction'] = self.get_reaction_value(comment_data['reactions'])
        return row


    def get_llm_response(self, comment_text:str, final_diff:str,  initial_diff:str, prompt_text='') -> str:
        if not prompt_text:
            prompt_text = self.default_prompt_text

        prompt = f"""
                {prompt_text}\n\n
                review comment:\n {comment_text}\n
                Initial diff:\n {initial_diff}\n
                Final diff:\n {final_diff}\n
                """
        prompts = {
            "influence_rate_prompt": [prompt]
        }
        llm_engine = 'openai'
        llm_model = ''
        try:
            responses = self.llm_manager.get_responses(prompts, llm_engine, llm_model)
            for response in responses:
                try:
                    response = json.loads(responses[response])
                    # Convert the percent value to a float
                    response['percent'] = float(response['percent'])
                    print(f"Response percent: {response['percent']}")
                    return response
                except Exception as e:
                    print(f'Failed to parse llm_response due to {e}. llm_response: {response}')
            # If no response is successfully parsed, return a default error response
            return {'explanation': 'Error in parsing', 'resolved': 0, 'percent': 0}
        except Exception as e:
            print(f'Failed to get responses due to {e}.')
            return {'explanation': 'Error in getting responses', 'resolved': 0, 'percent': 0}

    def get_comment_influence(self, row, diffs, first_diffs, prompt_text, pr_merge_commit_id) -> pd.DataFrame:

        if row['deleted']:
            print('Comment was deleted.')
            explanation = 'Comment was deleted.'
            row['resolution'] = 0
            row['explanation'] = explanation
            row['percent_match'] = 0
            return row

        if row['issue_type'] == 'description':
            print('Description comments can not be resolved.')
            explanation = 'Description comments can not be resolved.'
            row['resolution'] = 0
            row['explanation'] = explanation
            row['percent_match'] = 0
            return row

        comment_text = row['comment_text']
        filename = row['comment_file']

        if filename not in diffs: # TODO: check files that had an accepted comment and were later deleted
            explanation = f'File {filename} no longer exists in PR.'
            row['resolution'] = 0
            row['explanation'] = explanation
            row['percent_match'] = 0
            return row

        if pr_merge_commit_id == row['commit_id']:
            print('Comment was made on the last commit when the PR was merged, so no further changes could be incorporated.')
            explanation = 'Comment was made on the last commit when the PR was merged, so no further changes could be incorporated.'
            row['resolution'] = 0
            row['explanation'] = explanation
            row['percent_match'] = 0
            return row

        diff = diffs[filename]
        initial_diff = first_diffs[filename]
        response = self.get_llm_response(comment_text, diff, initial_diff, prompt_text)
        row['resolution'] = response['resolved']
        row['explanation'] = response['explanation']
        row['percent_match'] = response['percent']
        return row


    def load_comment_and_diffs(self, pr_url) -> tuple[pd.DataFrame]:
        if pr_url in self.cache:  # avoids extra calls to API when testing
            return self.cache[pr_url]['comments'], self.cache[pr_url]['diffs']

        owner, repository, pr_number = self.get_pr_info(pr_url)
        comments = self.get_comments(owner, repository, pr_number)
        diffs = self.get_diffs(owner, repository, pr_number)
        first_diffs = self.get_first_diffs(owner, repository, pr_number, diffs.keys())
        # cache data for next retrieval
        if pr_url not in self.cache:
            self.cache[pr_url] = {}
        self.cache[pr_url]['comments'] = comments
        self.cache[pr_url]['diffs'] = diffs
        self.cache[pr_url]['first_diffs'] = first_diffs
        return comments, diffs, first_diffs

    def get_total_influence(self, pr_url: str, prompt_text='', pr_merge_commit_id='') -> pd.DataFrame:
        print(f'Getting influence for PR: {pr_url}')
        comments, diffs, first_diffs = self.load_comment_and_diffs(pr_url)
        comments = comments.apply(lambda row: self.get_comment_influence(row, diffs, first_diffs, prompt_text, pr_merge_commit_id), axis=1)
        return comments
