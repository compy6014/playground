import random
from datetime import datetime
from elasticsearch import Elasticsearch
from elasticsearch import NotFoundError
from elasticsearch_dsl import Search, Q
import sys
import os
import socket
import getpass
import platform

__version__ = "1.1.0"

def create_elasticsearch_client(host_group):
    """
    Create an Elasticsearch client with shuffled hosts.

    :param host_group: The group of hosts to use
    :return: Elasticsearch client instance
    """
    host_groups = {
        'eckdev_elk': {
            'hosts': ['https://elasticdev.amd.com:9200/'],
            'auth_type': 'api_key',
            'auth': ('sOzbxI8BZ-tVYEn288EQ', 'y18Wmh5lRmqtBP9btdCJbQ'),
            'shuffle': False,
            'verify_certs': False
        },
        'aks_elk': {
            'hosts': ['https://aks-elk-elastic.amd.com:9200', 'https://DevOps-Es-ingest-2:9200','https://DevOps-Es-ingest-3:9200'],
            'auth_type': 'http_auth',
            'auth': ('elasticLoad', 'elasticLoad2021'),
            'shuffle': True,
            'verify_certs': False
        }
    }

    if host_group not in host_groups:
        raise ValueError(f"Invalid host group: {host_group}")

    group = host_groups[host_group]
    hosts = group['hosts']
    if group['shuffle']:
        random.shuffle(hosts)
    es = Elasticsearch(
        hosts,
        **{group['auth_type']: group['auth']},
        verify_certs=group['verify_certs'],
    )
    return es


def elastic_bulk_index(index, json_message_list, mapping=None, host_group='eckdev_elk'):
    """
    Index a list of JSON messages in Elasticsearch.

    :param index: Index name
    :param json_message_list: List of JSON messages to index
    :param mapping: Optional mapping for the index
    """
    es = create_elasticsearch_client(host_group)

    # Check if the index exists, create it if it doesn't
    if not es.indices.exists(index=index):
        es.indices.create(index=index, ignore=400, body=mapping)

    # Prepare documents by adding timestamp, host_name, and nesting original fields under jsonMessage
    prepared_documents = [prepare_document(message, __version__) for message in json_message_list]

    # Index the documents
    for doc in prepared_documents:
        try:
            es.index(index=index, body=doc)
        except NotFoundError as e:
            print(f"Failed to index document: {e}")

def prepare_document(input_document, script_version):
    """
    Prepare a document by adding metadata and nesting original fields under the jsonMessage key.

    :param input_document: Input JSON document
    :param script_version: Version of the script
    :return: Prepared JSON document with metadata
    """
    timestamp = datetime.utcnow().isoformat()
    host_name = socket.gethostname()
    python_version = sys.version
    script_name = os.path.basename(sys.argv[0])
    user = getpass.getuser()
    os_name = platform.system()
    os_version = platform.release()
    app_name = "SysArch-AiCodeReview"

    output_document = {
        "@timestamp": timestamp,
        "host_name": host_name,
        "python_version": python_version,
        "script_name": script_name,
        "user": user,
        "os_name": os_name,
        "os_version": os_version,
        "app_name": app_name,
        "script_version": script_version,
    }

    # Add the input_document fields under the jsonMessage key
    for key, value in input_document.items():
        output_document[f"msg.{key}"] = value

    return output_document

def query_elk(index: str, query: dict, sort: dict = None, size: int = 10, host_group='eckdev_elk'):
    """
    Query Elasticsearch with the given parameters.
    :param index: The name of the Elasticsearch index to query.
    :param query: The Elasticsearch query as a dictionary.
    :param sort: The sort parameter as a dictionary. Default is None.
    :param size: The number of results to return. Default is 10.
    :param host_group: The group of hosts to use. Default is 'eckdev_elk'.
    :return: The Elasticsearch query results.
    """
    es = create_elasticsearch_client(host_group)
    s = Search(using=es, index=index).query(Q(query)).extra(size=size)
    if sort is not None:
        s = s.sort(sort)
    response = s.execute()
    return response

def update_elk(index: str, doc_id: str, update: dict, host_group='eckdev_elk'):
    """
    Update an Elasticsearch document with the given parameters.
    :param index: The name of the Elasticsearch index to update.
    :param doc_id: The ID of the document to update.
    :param update: The update as a dictionary.
    :param host_group: The group of hosts to use. Default is 'eckdev_elk'.
    """
    es = create_elasticsearch_client(host_group)
    es.update(index=index, id=doc_id, body={'doc': update})
