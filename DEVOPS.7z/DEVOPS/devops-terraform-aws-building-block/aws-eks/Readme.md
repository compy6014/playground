# AWS EKS RBAC

1. Use aws config profile with you create AWS EKS cluster to add users

    ```bash
    export AWS_PROFILE=terraform-cloud-blueprint
    ```

2. Run command to update ~/.kube/config

    ```bash
    aws eks --region eu-central-1 update-kubeconfig --name blueprints-sandbox-eks-a-v1-21
    ```

3. Edit RBAC file `rbac/aws-auth-cm-eks-a.yaml` 

    ```yaml
   # You have to be careful about editing, choose the right IAM ROLE
   apiVersion: v1
   kind: ConfigMap
   metadata:
   name: aws-auth
   namespace: kube-system
   data:
   mapRoles: | 
   - rolearn: arn:aws:iam::689675151532:role/blueprints-sandbox-eks-a-nodes-iam-role
   username: system:node:{{EC2PrivateDNSName}}
   groups:
     - system:bootstrappers
     - system:nodes
     - rolearn: arn:aws:iam::689675151532:role/blueprints-sandbox-eks-a-cluster
     username: system:node:{{EC2PrivateDNSName}}
     groups:
     - system:bootstrappers
     - system:nodes
     mapUsers: |
     - userarn: arn:aws:iam::689675151532:user/slavko.stojadinovic@teornd
     username: slavko
     groups:
     - system:masters

   ```

4. Apply kubernetes manifest
    ```bash
     kubectl apply -f aws-auth-cm-eks-a.yaml
    ```

5. Swich back to your aws profile
    ```bash
    export AWS_PROFILE=blueprints-dev
    ```

6. Reconfig kubectl file
    ```bash
    aws eks --region eu-central-1 update-kubeconfig --name blueprints-dev1-eks
    ```

7. Try to get pods from aws eks
    ```bash
    kubectl get pods -n kube-system
    ```

<br><br><br>