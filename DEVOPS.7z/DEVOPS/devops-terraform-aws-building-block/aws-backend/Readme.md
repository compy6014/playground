# Setup terraform backend





## Links

#### 1. AWS S3

https://www.terraform.io/language/settings/backends/s3

https://quileswest.medium.com/how-to-lock-terraform-state-with-s3-bucket-in-dynamodb-3ba7c4e637

