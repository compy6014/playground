# AWS EKS SETUP 


Here is basic setup for two aws eks cluster.

More details see repo for Kubernetes Setup [link](https://bitbucket.org/dusankosic/devops-kubernetes-setup-terraform/src/master/)



# Setup is moved to [git repo](https://bitbucket.org/dusankosic/devops-kubernetes-setup-terraform/src/master/)

Please visit tihs repo https://bitbucket.org/dusankosic/devops-kubernetes-setup-terraform/src/master/



<br><br><br><br>

## Update local kubeconfig with new eks cluster
   
```bash
aws eks --region eu-central-1 update-kubeconfig --name blueprints-sandbox-eks-a-v1-24   
```