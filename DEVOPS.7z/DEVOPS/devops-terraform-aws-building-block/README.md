# AWS Bulding Bloks #



## Building bloks: ##

1. [AWS VPC](./aws-vpc/) 
2. [AWS EKS Setup](./aws-eks-setup/) - moved to new repo [link](https://bitbucket.org/dusankosic/devops-kubernetes-setup-terraform/src/master/)