import os
import subprocess
 
# Read profiles and regions from files
with open("profiles.txt", "r") as profiles_file:
    profiles = profiles_file.read().splitlines()
 
with open("regions.txt", "r") as regions_file:
    regions = regions_file.read().splitlines()
 
for aws_profile in profiles:
    for aws_region in regions:
        aws_profile_clean = aws_profile.replace('"', '')
        aws_region_clean = aws_region.replace('"', '')
 
        filename = f"0_stacks_{aws_region_clean}.txt"
        output_directory = f"C:\\LCI\\CF3\\{aws_profile_clean}\\{aws_region_clean}"
 
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)
 
        cmd_list = [
            "powershell",
            f"aws cloudformation list-stacks --stack-status-filter 'CREATE_COMPLETE' 'UPDATE_COMPLETE' --profile {aws_profile_clean} --region {aws_region_clean} --query 'StackSummaries[*].[StackName]' --output text | Out-File -Encoding ASCII -FilePath {output_directory}\\{filename}"
        ]
        subprocess.run(cmd_list, shell=True)
 
        with open(os.path.join(output_directory, filename), "r") as stack_file:
            for stack_name in stack_file.read().splitlines():
                template_file = os.path.join(output_directory, f"{stack_name}_template.yaml")
                config_file = os.path.join(output_directory, f"{stack_name}_config.json")
                params_file = os.path.join(output_directory, f"{stack_name}_params.txt")
 
                cmd_list = [
                    "aws",
                    "cloudformation",
                    "get-template",
                    f"--profile {aws_profile_clean}",
                    f"--region {aws_region_clean}",
                    f"--stack-name {stack_name}",
                    "--query TemplateBody --output text",
                ]
                with open(template_file, "w") as tf:
                    subprocess.run(cmd_list, shell=True, stdout=tf)
 
                cmd_list = [
                    "aws",
                    "cloudformation",
                    "describe-stacks",
                    f"--profile {aws_profile_clean}",
                    f"--region {aws_region_clean}",
                    f"--stack-name {stack_name}",
                ]
                with open(config_file, "w") as cf:
                    subprocess.run(cmd_list, shell=True, stdout=cf)
 
                with open(config_file, "r") as cf:
                    stack_params = [
                        f"ParameterKey: {param['ParameterKey']}, ParameterValue: {param['ParameterValue']}"
                        for param in eval(cf.read())["Stacks"][0]["Parameters"]
                    ]
                    with open(params_file, "w") as pf:
                        pf.write("\n".join(stack_params))
 
                os.remove(config_file)