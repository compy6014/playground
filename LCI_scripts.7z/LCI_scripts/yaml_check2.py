import os
import yaml
 
def is_valid_yaml(yaml_content):
    try:
        yaml.safe_load(yaml_content)
        return True
    except yaml.YAMLError as e:
        #print(f"YAML Error: {e}")
        return False
 
def check_yaml_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                file_path = os.path.join(root, file)
                with open(file_path, 'r') as f:
                    yaml_content = f.read()
                    if is_valid_yaml(yaml_content):
                        print(f"{file_path}: YAML structure is valid.")
                    else:
                        print(f"{file_path}: YAML structure is invalid.")
 
# Example usage:
folder_path = r"C:\LCI\CF_current_state"
check_yaml_files(folder_path)