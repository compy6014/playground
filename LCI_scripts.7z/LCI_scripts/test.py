import json
import os
import yaml
 
def custom_constructor(loader, node):
    # Skip lines with !Ref during YAML loading
    if isinstance(node, yaml.nodes.ScalarNode) and node.tag == u'tag:yaml.org,2002:ref':
        return loader.construct_scalar(node)
    else:
        raise ValueError("Unexpected YAML tag: {}".format(node.tag))
 
def get_config_rules_from_template(template_path):
    with open(template_path, 'r') as file:
        loader = yaml.Loader(file)
        loader.add_constructor('!Ref', custom_constructor)
        template_content = yaml.load(loader)
 
    resources = template_content.get('Resources', {})
 
    config_rules = []
    for resource_name, resource_definition in resources.items():
        if resource_definition.get('Type') == 'AWS::Config::ConfigRule':
            config_rule_name = resource_definition['Properties']['ConfigRuleName']
            config_rules.append(config_rule_name)
 
    return config_rules
 
def get_deployed_config_rules_from_json(json_path):
    with open(json_path, 'r') as file:
        deployed_config_rules = [rule['ConfigRuleName'] for rule in json.load(file).get('ConfigRules', [])]
 
    return deployed_config_rules
 
def main():
    # Specify the directory where your CloudFormation templates and AWS Config rule descriptions are stored
    templates_directory = r'c:\LCI\testing\CF2\g2p\ap-northeast-1'
    json_descriptions_directory = r'c:\LCI\testing\Config_rules\g2p\ap-northeast-1'
    # List all CloudFormation templates in the specified directory
    template_files = [file for file in os.listdir(templates_directory) if file.endswith('.yaml') or file.endswith('.yml')]
 
    # List all JSON files in the specified directory for AWS Config rule descriptions
    json_files = [file for file in os.listdir(json_descriptions_directory) if file.endswith('.json')]
 
    # Filter out non-relevant files (e.g., .txt files)
    template_files = [file for file in template_files if file not in {'non_relevant_file1.txt', 'non_relevant_file2.txt'}]
    json_files = [file for file in json_files if file not in {'non_relevant_file3.json', 'non_relevant_file4.json'}]
 
    for template_file in template_files:
        template_path = os.path.join(templates_directory, template_file)
 
        # Get AWS Config rules defined in the CloudFormation template
        defined_config_rules = get_config_rules_from_template(template_path)
 
        for json_file in json_files:
            json_path = os.path.join(json_descriptions_directory, json_file)
 
            # Get deployed AWS Config rules from pre-downloaded JSON
            deployed_config_rules = get_deployed_config_rules_from_json(json_path)
 
            # Compare defined rules with deployed rules
            for rule in defined_config_rules:
                if rule in deployed_config_rules:
                    print(f"Config rule '{rule}' is defined in '{template_file}' and is deployed.")
                else:
                    print(f"Config rule '{rule}' is defined in '{template_file}' but is not deployed.")
 
if __name__ == '__main__':
    main()