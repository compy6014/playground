import os
import yaml
 
def validate_yaml_file(file_path):
    try:
        with open(file_path, 'r') as file:
            yaml.safe_load(file)
        print(f"Validation successful for: {file_path}")
    except Exception as e:
        print(f"Validation failed for: {file_path}\nError: {str(e)}")
 
def validate_yaml_files_in_folder(folder_path):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                file_path = os.path.join(root, file)
                validate_yaml_file(file_path)
 
# Specify the folder path containing YAML files
folder_path = r"C:\LCI\CF_current_state\fnp"
 
# Call the function to validate YAML files in the specified folder and its subfolders
validate_yaml_files_in_folder(folder_path)

