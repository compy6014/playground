import requests
import base64
import re
import json
from helpers.logger import get_module_logger
from requests.exceptions import HTTPError
from typing import List, Dict, Tuple, Optional

class GitHubHelper:
    """Helper class for interacting with the GitHub API."""

    BASE_URL = 'https://github.amd.com/api/v3'
    ACCEPT_HEADER = 'application/vnd.github.v3+json'

    def __init__(self, ghe_token: str, api_base_url: str = BASE_URL):
        self.ghe_token = ghe_token
        self.api_base_url = api_base_url
        self.logger = get_module_logger('GitHubHelper')

        self.diff_header = {
            "Accept": "application/vnd.github.diff",
            "Authorization": f"Bearer {ghe_token}"
        }

        self.comment_header = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {ghe_token}"
        }

    def _get_headers(self, raw: bool = False) -> Dict[str, str]:
        accept = self.ACCEPT_HEADER + ('.raw' if raw else '')
        return {
            'Authorization': f'Bearer {self.ghe_token}',
            'Accept': accept
        }

    def get_pull_request_graphql_details(self, owner: str, repo: str, pull_number: int) -> Dict:
        """
        Fetch detailed pull request data (including latest commit and file changes) using GitHub's GraphQL API.

        :param owner: Owner of the repository.
        :param repo: Repository name.
        :param pull_number: Pull request number.
        :return: A dictionary containing pull request details, or an empty dict if an error occurs.
        """
        graphql_url = f"{self.api_base_url.replace('/api/v3', '/api/graphql')}"
        query = """
        query($owner: String!, $name: String!, $pullNumber: Int!) {
          repository(owner: $owner, name: $name) {
            pullRequest(number: $pullNumber) {
              number
              title
              commits(last: 1) {
                nodes {
                  commit {
                    oid
                    message
                    additions
                    deletions
                    changedFiles
                  }
                }
              }
              files(first: 100) {
                nodes {
                  path
                  additions
                  deletions
                  changeType
                  patch
                }
              }
            }
          }
        }
        """
        variables = {
            "owner": owner,
            "name": repo,
            "pullNumber": pull_number
        }
        headers = {
            "Authorization": f"Bearer {self.ghe_token}",
            "Content-Type": "application/json"
        }

        try:
            self.logger.info(f"Fetching pull request details via GraphQL for PR #{pull_number}")
            response = requests.post(graphql_url, json={"query": query, "variables": variables}, headers=headers)
            response.raise_for_status()
            return response.json().get('data', {})
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching PR details: {http_err}")
        except Exception as e:
            self.logger.error(f"An error occurred while fetching PR details via GraphQL: {str(e)}")
        return {}

    def get_latest_commit_sha_from_pr(self, owner: str, repo: str, pr_number: int) -> str:
        """
        Fetches the latest commit SHA from a pull request using the REST API.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/commits"
        self.logger.info(f"Fetching commits for PR #{pr_number} from {url}")

        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            commits_data = response.json()

            if commits_data:
                # The last item is typically the latest commit
                return commits_data[-1]["sha"]
            return ""
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"An error occurred while fetching commits for PR #{pr_number}: {str(e)}")
        return ""
    
    def get_commit_details(self, owner: str, repo: str, commit_sha: str) -> Dict:
        """Fetches the details of a commit based on the commit SHA."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/commits/{commit_sha}"
        self.logger.info(f"Fetching commit details for commit {commit_sha} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"An error occurred while fetching commit details for {commit_sha}: {str(e)}")
        return {}
    
    def get_commit_by_id(self, owner: str, repo: str, commit_id: str) -> Dict:
        """Fetches a single commit based on the commit ID."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/commits/{commit_id}"
        self.logger.info(f"Fetching commit {commit_id} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"Error occurred while fetching commit {commit_id}: {str(e)}")
        return {}

    def get_new_commits(self, owner: str, repo: str, branch: str, since: Optional[str] = None) -> List[Dict]:
        """Fetches new commits for the specified branch in a repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/commits?sha={branch}&per_page=100"
        if since:
            url += f"&since={since}"
        self.logger.info(f"Fetching commits for branch {branch} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
        except Exception as e:
            self.logger.error(f"Error occurred while fetching commits for branch {branch}: {str(e)}")
        return []

    def get_latest_commit_sha(self, owner: str, repo: str, branch_name: str) -> str:
        """Fetches the latest commit SHA for a given branch."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/branches/{branch_name}"
        self.logger.info(f"Fetching latest commit SHA for repo: {repo}, branch: {branch_name}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()['commit']['sha']
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_repository_default_branch(self, owner: str, repo: str) -> str:
        """Fetches the default branch for a repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}"
        self.logger.info(f"Fetching default branch for repo: {owner}/{repo}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()['default_branch']
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching default branch: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while fetching default branch: {e}")
            raise

    def get_file_content(self, owner: str, repo: str, branch_sha: str, file_path: str) -> str:
        """Fetches the content of a file from a repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/contents/{file_path}?ref={branch_sha}"
        self.logger.info(f"Fetching file content for repo: {repo}, branch_sha: {branch_sha}, file_path: {file_path}")
        try:
            response = requests.get(url, headers=self._get_headers(raw=True))
            response.raise_for_status()
            file_info = response.json()
            return base64.b64decode(file_info['content']).decode()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_diff(self, owner: str, repo: str, commit_id: str) -> str:
        """Fetch the diff for a specific commit."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/commits/{commit_id}"
        self.logger.info(f"Fetching diff for commit {commit_id} from {url}")
        try:
            response = requests.get(url, headers=self.diff_header)
            response.raise_for_status()
            return response.text
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_pr_diff(self, owner: str, repo: str, pr_number: str) -> str:
        """Fetch the diff for a specific pull request."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}"
        self.logger.info(f"Fetching diff for PR #{pr_number} from {url}")
        try:
            response = requests.get(url, headers=self.diff_header)
            response.raise_for_status()
            return response.text
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_pr_data(self, owner: str, repo: str, pr_number: str) -> str:
        """Fetch the metadata for specific pull request"""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}"
        self.logger.info(f"Fetching PR data for {pr_number} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def get_pr_files(self, owner: str, repo: str, pr_number: str) -> list:
        """
        Fetch the list of files changed in a pull request.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/files"
        self.logger.info(f"Fetching files changed in PR #{pr_number} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()  # This is a list of file dicts
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except requests.exceptions.RequestException as req_err:
            self.logger.error(f"Request error occurred: {req_err}")
            raise

    def create_branch(self, owner: str, repo: str, base_sha: str, new_branch: str) -> None:
        """Create a new branch in the repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/git/refs"
        new_ref = {"ref": f"refs/heads/{new_branch}", "sha": base_sha}
        try:
            response = requests.post(url, json=new_ref, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Branch '{new_branch}' created successfully.")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def delete_branch(self, owner: str, repo: str, branch_name: str) -> None:
        """Delete a branch from the repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/git/refs/heads/{branch_name}"
        try:
            response = requests.delete(url, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Branch '{branch_name}' deleted successfully.")
        except HTTPError as http_err:
            if http_err.response.status_code == 422:
                self.logger.error(f"Cannot delete branch '{branch_name}': {http_err}")
                self.logger.error("This usually means the branch is the default branch or doesn't exist")
            elif http_err.response.status_code == 404:
                self.logger.warning(f"Branch '{branch_name}' not found (may have been already deleted)")
            else:
                self.logger.error(f"HTTP error occurred while deleting branch: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while deleting branch: {e}")
            raise

    def get_file_sha(self, owner: str, repo: str, branch: str, file_path: str) -> Optional[str]:
        """Retrieve the SHA of a file in the specified branch."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/contents/{file_path}?ref={branch}"
        try:
            response = requests.get(url, headers=self._get_headers())
            if response.status_code == 200:
                return response.json()['sha']
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def commit_file(self, owner: str, repo: str, branch: str, file_path: str, file_content: str, commit_message: str) -> None:
        """Commit a file to the specified branch."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/contents/{file_path}"
        file_sha = self.get_file_sha(owner, repo, branch, file_path)
        encoded_content = base64.b64encode(file_content.encode()).decode()
        commit_data = {"message": commit_message, "content": encoded_content, "branch": branch}
        if file_sha:
            commit_data["sha"] = file_sha
        try:
            response = requests.put(url, json=commit_data, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"File '{file_path}' committed successfully.")
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def create_pull_request(self, owner: str, repo: str, base: str, head: str, title: str, body: str, isDraft: bool) -> str:
        """Create a new pull request."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls"
        pr_data = {"title": title, "body": body, "head": head, "base": base, "draft": isDraft}
        try:
            response = requests.post(url, json=pr_data, headers=self._get_headers())
            response.raise_for_status()
            pr_url = response.json()['html_url']
            self.logger.info(f"Pull request created successfully. PR url: {pr_url}")
            return pr_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def add_labels_to_pr(self, pr_url: str, labels: List[str]) -> None:
        """Add labels to a pull request."""
        owner, repo, pr_number = self.extract_pr_details(pr_url)
        url = f"{self.api_base_url}/repos/{owner}/{repo}/issues/{pr_number}/labels"
        try:
            response = requests.post(url, json={"labels": labels}, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Labels added successfully to PR #{pr_number}")
        except HTTPError as http_err:
            # Provide more specific error information
            status_code = http_err.response.status_code
            if status_code == 422:
                # Common case: invalid labels or validation errors
                try:
                    error_details = http_err.response.json()
                    error_msg = error_details.get('message', 'Unknown error')
                    self.logger.error(f"Failed to add labels (422): {error_msg}")
                    if 'errors' in error_details:
                        for error in error_details['errors']:
                            self.logger.error(f"  - {error.get('message', error)}")
                except:
                    self.logger.error(f"Failed to add labels: 422 Unprocessable Entity")
                    self.logger.error("This usually means invalid label names or validation errors")
            elif status_code == 403:
                self.logger.error(f"Failed to add labels: Permission denied (403)")
                self.logger.error("The token may not have sufficient permissions to add labels")
            elif status_code == 404:
                self.logger.error(f"Failed to add labels: PR or repository not found (404)")
            else:
                self.logger.error(f"Failed to add labels: HTTP {status_code} - {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while adding labels: {e}")
            raise

    def add_reviewers_to_pr(self, pr_url: str, reviewers: List[str]) -> None:
        """Add reviewers to a pull request."""
        if not reviewers:
            self.logger.info(f"No reviewers to add for PR {pr_url}")
            return
        owner, repo, pr_number = self.extract_pr_details(pr_url)
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/requested_reviewers"
        try:
            response = requests.post(url, json={"reviewers": reviewers}, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Reviewers added successfully to PR #{pr_number}")
        except HTTPError as http_err:
            # Provide more specific error information
            status_code = http_err.response.status_code
            if status_code == 422:
                # Common case: invalid usernames or users who can't be added as reviewers
                try:
                    error_details = http_err.response.json()
                    error_msg = error_details.get('message', 'Unknown error')
                    self.logger.error(f"Failed to add reviewers (422): {error_msg}")
                    if 'errors' in error_details:
                        for error in error_details['errors']:
                            self.logger.error(f"  - {error.get('message', error)}")
                except:
                    self.logger.error(f"Failed to add reviewers: 422 Unprocessable Entity")
                    self.logger.error("This usually means invalid usernames or users who cannot be added as reviewers")
            elif status_code == 403:
                self.logger.error(f"Failed to add reviewers: Permission denied (403)")
                self.logger.error("The token may not have sufficient permissions to add reviewers")
            elif status_code == 404:
                self.logger.error(f"Failed to add reviewers: PR or repository not found (404)")
            else:
                self.logger.error(f"Failed to add reviewers: HTTP {status_code} - {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while adding reviewers: {e}")
            raise

    def get_pr_data(self, owner: str, repo: str, pr_number: str) -> Dict:
        """
        Fetches pull request data from the GitHub API.
        Args:
            owner (str): The repository owner.
            repo (str): The repository name.
            pr_number (str): The pull request number.
        Returns:
            Dict: The pull request data as a dictionary.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}"
        self.logger.info(f"Fetching PR data for PR #{pr_number} from {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            pr_data = response.json()
            return pr_data
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching PR data: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while fetching PR data: {e}")
            raise

    def extract_pr_details(self, pr_url: str) -> Tuple[str, str, str]:
        """Extracts owner, repo, and PR number from a PR URL."""
        patterns = {
            "internal": re.compile(r"https://github\.amd\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)"),
            "external": re.compile(r"https://github\.com/([\w\-]+)/([\w\-]+)/pull/(\d+)")
        }
        for pattern in patterns.values():
            match = pattern.match(pr_url)
            if match:
                return match.groups()
        raise ValueError(f"Invalid PR URL: {pr_url}")

    # Comment related methods

    def get_pr_review_comment(self, owner: str, repo: str, pr_number: str, comment_id: str) -> Dict:
        """Fetches the review comment from a pull request based on comment ID."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/comments/{comment_id}"
        self.logger.info(f"Fetching review comment {comment_id} from PR #{pr_number} at {url}")
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_reply_comment(self, owner: str, repo: str, pr_number: str, comment_id: str, body: str) -> str:
        """Posts a reply comment to a review comment on a pull request."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/comments/{comment_id}/replies"
        comment_data = {"body": body}
        try:
            response = requests.post(url, json=comment_data, headers=self._get_headers())
            response.raise_for_status()
            comment_url = response.json().get('html_url')
            self.logger.info(f"Reply comment posted successfully on PR #{pr_number}. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_pr_review_comment(self, owner: str, repo: str, pr_number: str, comment_body: Dict) -> str:
        """Post a positional review comment on a pull request diff using the provided comment_body.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param pr_number: Pull request number.
        :param comment_body: Dictionary containing the comment data.
        :return: URL of the posted comment.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/comments"
        self.logger.info(f"Posting review comment to PR #{pr_number} at {url}")
        self.logger.debug(f"Comment body to post as review comment: {comment_body}")
        try:
            response = requests.post(url, json=comment_body, headers=self.comment_header)
            response.raise_for_status()
            comment_url = response.json().get('html_url', '')
            self.logger.info(f"Review comment posted successfully. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def post_commit_comment(self, owner: str, repo: str, commit_id: str, comment_body: Dict) -> str:
        """Post a comment on a commit using the provided comment_body.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param commit_id: Commit SHA.
        :param comment_body: Dictionary containing the comment data.
        :return: URL of the posted comment.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/commits/{commit_id}/comments"
        self.logger.info(f"Posting comment to commit {commit_id} at {url}")
        self.logger.debug(f"Comment body to post as commit comment: {comment_body}")
        try:
            response = requests.post(url, json=comment_body, headers=self.comment_header)
            response.raise_for_status()
            comment_url = response.json().get('html_url', '')
            self.logger.info(f"Commit comment posted successfully. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def create_pull_request_review(
        self,
        owner: str,
        repo: str,
        pr_number: str,
        review_data: Dict
    ) -> str:
        """
        Creates a review on the specified pull request.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param pr_number: Pull request number.
        :param review_data: Dictionary containing the review details:
            {
                "commit_id": "string",
                "body": "string",
                "event": "APPROVE|REQUEST_CHANGES|COMMENT",
                "comments": [
                    {
                        "path": "string",
                        "position": integer,
                        "body": "string",
                        "start_line": integer,
                        "line": integer,
                        "side": "string"
                    }
                ]
            }
        :return: URL of the posted review.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/pulls/{pr_number}/reviews"
        self.logger.info(f"Creating review for PR #{pr_number} at {url}")
        #self.logger.debug(f"Review data to post: {review_data}")
        try:
            response = requests.post(url, json=review_data, headers=self.comment_header)
            response.raise_for_status()
            review_url = response.json().get('html_url', '')
            self.logger.info(f"Review created successfully. Review URL: {review_url}")
            return review_url
        except HTTPError as http_err:
            self.logger.error(f"Response: {response.content.decode()}")
            self.logger.error(f"HTTP error occurred: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"Response: {response.content.decode()}")
            self.logger.error(f"An error occurred: {e}")
            raise
    
    def post_issue_comment(self, owner: str, repo: str, pr_number: str, comment_body: Dict) -> str:
        """
        Post an issue/conversation comment on a pull request using the provided comment_body.
        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param pr_number: Pull request number.
        :param comment_body: Dictionary containing the comment data.
        :return: URL of the posted comment.
        """
        url = f"{self.api_base_url}/repos/{owner}/{repo}/issues/{pr_number}/comments"
        self.logger.info(f"Posting issue comment to PR #{pr_number} at {url}")
        payload = {
            "body": comment_body
        }
        try:
            response = requests.post(url, json=payload, headers=self.comment_header)
            response.raise_for_status()
            comment_url = response.json().get('html_url', '')
            self.logger.info(f"Issue comment posted successfully. Comment URL: {comment_url}")
            return comment_url
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred: {http_err}")
            if http_err.response is not None:
                self.logger.error(f"Response status code: {http_err.response.status_code}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred: {e}")
            raise

    def delete_comment(self, comment_url: str) -> bool:
        """
        Delete a comment using its URL.
        
        Args:
            comment_url (str): The URL of the comment to delete.
            
        Returns:
            bool: True if the comment was deleted successfully, False otherwise.
        """
        self.logger.info(f"Deleting comment at URL: {comment_url}")
        try:
            response = requests.delete(comment_url, headers=self.comment_header)
            response.raise_for_status()
            self.logger.info(f"Comment deleted successfully: {comment_url}")
            return True
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while deleting comment: {http_err}")
            if http_err.response is not None:
                self.logger.error(f"Response status code: {http_err.response.status_code}")
            return False
        except Exception as e:
            self.logger.error(f"An error occurred while deleting comment: {e}")
            return False

    def get_pr_review_threads(self, owner: str, repo: str, pr_number: str) -> Dict:
        """
        Get review threads for a pull request using GraphQL API.
        
        Args:
            owner (str): Repository owner.
            repo (str): Repository name.
            pr_number (str): Pull request number.
            
        Returns:
            Dict: GraphQL response containing review threads data.
        """
        graphql_url = f"{self.api_base_url.replace('/api/v3', '/api/graphql')}"
        query = """
        query($owner: String!, $name: String!, $pullNumber: Int!) {
          repository(owner: $owner, name: $name) {
            pullRequest(number: $pullNumber) {
              reviewThreads(first: 100) {
                nodes {
                  id
                  comments(first: 100) {
                    nodes {
                      id
                      bodyText
                      url
                    }
                  }
                }
              }
            }
          }
        }
        """
        variables = {
            "owner": owner,
            "name": repo,
            "pullNumber": int(pr_number)
        }
        headers = {
            "Authorization": f"Bearer {self.ghe_token}",
            "Content-Type": "application/json"
        }

        try:
            self.logger.info(f"Fetching review threads for PR #{pr_number}")
            response = requests.post(graphql_url, json={"query": query, "variables": variables}, headers=headers)
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching review threads: {http_err}")
            return {"data": {"repository": {"pullRequest": {"reviewThreads": {"nodes": []}}}}}
        except Exception as e:
            self.logger.error(f"An error occurred while fetching review threads: {e}")
            return {"data": {"repository": {"pullRequest": {"reviewThreads": {"nodes": []}}}}}

    def get_pr_comments(self, owner: str, repo: str, pr_number: str) -> Dict:
        """
        Get issue comments for a pull request using GraphQL API.
        
        Args:
            owner (str): Repository owner.
            repo (str): Repository name.
            pr_number (str): Pull request number.
            
        Returns:
            Dict: GraphQL response containing comments data.
        """
        graphql_url = f"{self.api_base_url.replace('/api/v3', '/api/graphql')}"
        query = """
        query($owner: String!, $name: String!, $pullNumber: Int!) {
          repository(owner: $owner, name: $name) {
            pullRequest(number: $pullNumber) {
              comments(first: 100) {
                nodes {
                  id
                  body
                  url
                }
              }
            }
          }
        }
        """
        variables = {
            "owner": owner,
            "name": repo,
            "pullNumber": int(pr_number)
        }
        headers = {
            "Authorization": f"Bearer {self.ghe_token}",
            "Content-Type": "application/json"
        }

        try:
            self.logger.info(f"Fetching comments for PR #{pr_number}")
            response = requests.post(graphql_url, json={"query": query, "variables": variables}, headers=headers)
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while fetching comments: {http_err}")
            return {"data": {"repository": {"pullRequest": {"comments": {"nodes": []}}}}}
        except Exception as e:
            self.logger.error(f"An error occurred while fetching comments: {e}")
            return {"data": {"repository": {"pullRequest": {"comments": {"nodes": []}}}}}

    # Utility methods

    def is_line_range_in_hunk(self, hunk_header, line_range):
        """
        Function to check if given line numbers [first_line, last_line] are within
        the diff hunk on the right side (new file), based on the hunk header.

        Parameters:
            hunk_header (str): The diff hunk header line (e.g., "@@ -13987,17 +14040,30 @@").
            line_range (list[int]): A list containing [first_line, last_line].

        Returns:
            bool: True if the line range is within the hunk, False otherwise.
        """
        first_line, last_line = line_range

        try:
            first_line = int(first_line)
            last_line = int(last_line)
        except ValueError:
            print(f"Invalid line numbers provided: {line_range}")
            return False

        if first_line > last_line:
            first_line, last_line = last_line, first_line

        # Regular expression to match hunk headers
        hunk_header_regex = re.compile(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@')

        hunk_header_match = hunk_header_regex.match(hunk_header.strip())
        if not hunk_header_match:
            print(f"Invalid hunk header: {hunk_header}")
            return False

        # Extract starting line number and line count from hunk header (right side)
        start_line = int(hunk_header_match.group(1))
        length_str = hunk_header_match.group(2)
        if length_str is not None:
            length = int(length_str)
        else:
            length = 1  # Default length if not specified

        end_line = start_line + length - 1

        # Check if the given line range overlaps with the hunk range
        if last_line < start_line:
            return False
        elif first_line > end_line:
            return False
        else:
            return True

    def is_line_range_in_added_lines(self, diff_hunk: str, line_range: tuple[int, int]) -> bool:
        """
        Check if the given line range [start_line, end_line] is entirely within
        added lines in the diff hunk. Handles new file additions and insertions
        where the original line count is zero.

        Args:
            diff_hunk (str): The diff hunk string.
            line_range (tuple[int, int]): A tuple containing start and end line numbers.

        Returns:
            bool: True if the entire line_range is within added lines in the diff hunk.
        """
        hunk_header_pattern = re.compile(r'^@@ -(\d+),?(\d+)? \+(\d+),?(\d+)? @@')

        lines = diff_hunk.rstrip('\n').split('\n')
        if not lines:
            self.logger.info("Empty diff hunk.")
            return False

        header_match = hunk_header_pattern.match(lines[0])
        if not header_match:
            self.logger.info("Invalid diff hunk format.")
            return False

        # Extracting line numbers and counts from the hunk header
        original_line_start = int(header_match.group(1))
        original_line_count = header_match.group(2)
        new_line_start = int(header_match.group(3))
        new_line_count = header_match.group(4)

        # If counts are not specified, default to 1
        original_line_count = int(original_line_count) if original_line_count else 1
        new_line_count = int(new_line_count) if new_line_count else 1

        start_line, end_line = line_range
        if end_line < start_line:
            self.logger.info("End line is smaller than start line.")
            return False

        # Check for insertion (original_line_count == 0)
        if original_line_count == 0 and new_line_count > 0:

            # Calculate the end line number in the new file
            new_file_end_line = new_line_start + new_line_count - 1

            # If both start_line and end_line are within the range of added lines
            if new_line_start <= start_line <= end_line <= new_file_end_line:
                self.logger.info("Line range is within the inserted lines.")
                return True
            else:
                self.logger.info("Line range is outside the inserted lines.")
                return False

        # Check for deletion (new_line_count == 0)
        if new_line_count == 0 and original_line_count > 0:
            # Deletions don't add lines to the new file, so the line range cannot be within added lines
            return False

        # Existing logic for modifications
        new_line_num = new_line_start - 1  # Initialize to one less for correct incrementing

        total_lines_in_range = end_line - start_line + 1
        lines_in_range_checked = 0

        # Process each line in the hunk
        for index, line in enumerate(lines[1:], start=1):
            if line.startswith('+++') or line.startswith('---') or line.startswith('@@'):
                continue

            if line.startswith('+') and not line.startswith('+++'):
                # Added line: line is present in new file
                new_line_num += 1
                if start_line <= new_line_num <= end_line:
                    lines_in_range_checked += 1
                    if lines_in_range_checked == total_lines_in_range:
                        return True
                elif new_line_num > end_line:
                    break
            elif line.startswith('-') and not line.startswith('---'):
                # Removed line: line is from original file
                pass
            else:
                # Context line
                new_line_num += 1
                if start_line <= new_line_num <= end_line:
                    return False
                elif new_line_num > end_line:
                    break

        # If the loop ends and we have not checked all lines in range, return False
        if lines_in_range_checked == total_lines_in_range:
            self.logger.info("All lines in the range were added lines.")
            return True
        else:
            self.logger.info("Did not find all lines in the range or encountered non-added lines.")
            return False

    # Secret management methods

    def list_org_secrets(self, org: str) -> List[Dict]:
        """List all organization secrets."""
        url = f"{self.api_base_url}/orgs/{org}/actions/secrets"
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json().get('secrets', [])
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while listing org secrets: {http_err}")
            return []
        except Exception as e:
            self.logger.error(f"An error occurred while listing org secrets: {e}")
            return []

    def list_repo_secrets(self, owner: str, repo: str) -> List[Dict]:
        """List all repository secrets."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/actions/secrets"
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json().get('secrets', [])
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while listing repo secrets: {http_err}")
            return []
        except Exception as e:
            self.logger.error(f"An error occurred while listing repo secrets: {e}")
            return []

    def secret_exists_in_org(self, org: str, secret_name: str) -> bool:
        """Check if a secret exists in organization."""
        url = f"{self.api_base_url}/orgs/{org}/actions/secrets/{secret_name}"
        try:
            response = requests.get(url, headers=self._get_headers())
            return response.status_code == 200
        except Exception as e:
            self.logger.debug(f"Secret {secret_name} not found in org {org}: {e}")
            return False

    def secret_exists_in_repo(self, owner: str, repo: str, secret_name: str) -> bool:
        """Check if a secret exists in repository."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/actions/secrets/{secret_name}"
        try:
            response = requests.get(url, headers=self._get_headers())
            return response.status_code == 200
        except Exception as e:
            self.logger.debug(f"Secret {secret_name} not found in repo {owner}/{repo}: {e}")
            return False

    def get_org_public_key(self, org: str) -> Dict:
        """Get organization public key for secret encryption."""
        url = f"{self.api_base_url}/orgs/{org}/actions/secrets/public-key"
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while getting org public key: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while getting org public key: {e}")
            raise

    def get_repo_public_key(self, owner: str, repo: str) -> Dict:
        """Get repository public key for secret encryption."""
        url = f"{self.api_base_url}/repos/{owner}/{repo}/actions/secrets/public-key"
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except HTTPError as http_err:
            self.logger.error(f"HTTP error occurred while getting repo public key: {http_err}")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while getting repo public key: {e}")
            raise

    def encrypt_secret(self, public_key: str, secret_value: str) -> str:
        """Encrypt a secret value using the public key."""
        try:
            from nacl import encoding, public as nacl_public
            
            # Convert the public key and secret to bytes
            public_key_bytes = base64.b64decode(public_key)
            secret_bytes = secret_value.encode("utf-8")
            
            # Create a Box for encryption
            sealed_box = nacl_public.SealedBox(nacl_public.PublicKey(public_key_bytes))
            encrypted = sealed_box.encrypt(secret_bytes)
            
            # Return base64 encoded encrypted value
            return base64.b64encode(encrypted).decode("utf-8")
        except ImportError:
            self.logger.error("PyNaCl library is required for secret encryption. Install with: pip install PyNaCl")
            raise
        except Exception as e:
            self.logger.error(f"An error occurred while encrypting secret: {e}")
            raise

    def create_org_secret(self, org: str, secret_name: str, secret_value: str, selected_repository_ids: List[int] = None) -> bool:
        """Create or update an organization secret."""
        try:
            # Get public key for encryption
            public_key_data = self.get_org_public_key(org)
            encrypted_value = self.encrypt_secret(public_key_data['key'], secret_value)
            
            url = f"{self.api_base_url}/orgs/{org}/actions/secrets/{secret_name}"
            payload = {
                "encrypted_value": encrypted_value,
                "key_id": public_key_data['key_id'],
                "visibility": "selected" if selected_repository_ids else "all"
            }
            
            if selected_repository_ids:
                payload["selected_repository_ids"] = selected_repository_ids
            
            response = requests.put(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Successfully created/updated org secret: {secret_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create org secret {secret_name}: {e}")
            return False

    def create_repo_secret(self, owner: str, repo: str, secret_name: str, secret_value: str) -> bool:
        """Create or update a repository secret."""
        try:
            # Get public key for encryption
            public_key_data = self.get_repo_public_key(owner, repo)
            encrypted_value = self.encrypt_secret(public_key_data['key'], secret_value)
            
            url = f"{self.api_base_url}/repos/{owner}/{repo}/actions/secrets/{secret_name}"
            payload = {
                "encrypted_value": encrypted_value,
                "key_id": public_key_data['key_id']
            }
            
            response = requests.put(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            self.logger.info(f"Successfully created/updated repo secret: {secret_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create repo secret {secret_name}: {e}")
            return False

    def ensure_secret_exists(self, owner: str, repo: str, secret_name: str, secret_value: str, try_org_first: bool = True) -> bool:
        """
        Ensure a secret exists, trying organization level first, then repository level.
        
        Args:
            owner: Repository owner/organization
            repo: Repository name
            secret_name: Name of the secret
            secret_value: Value of the secret
            try_org_first: Whether to try organization level first
            
        Returns:
            bool: True if secret exists or was created successfully
        """
        # First check if secret already exists in org or repo
        if self.secret_exists_in_org(owner, secret_name):
            self.logger.info(f"Secret {secret_name} already exists in organization {owner}")
            return True
            
        if self.secret_exists_in_repo(owner, repo, secret_name):
            self.logger.info(f"Secret {secret_name} already exists in repository {owner}/{repo}")
            return True
        
        # Secret doesn't exist, try to create it
        if try_org_first:
            self.logger.info(f"Attempting to create secret {secret_name} at organization level...")
            if self.create_org_secret(owner, secret_name, secret_value):
                return True
            
            self.logger.info(f"Failed to create org secret, falling back to repository level...")
        
        self.logger.info(f"Attempting to create secret {secret_name} at repository level...")
        return self.create_repo_secret(owner, repo, secret_name, secret_value)
