# helpers/diff_handler.py
from typing import Tuple, List
from helpers.logger import get_module_logger
import re

class DiffHandler:
    """Helper class for handling diffs."""

    def __init__(self):
        self.logger = get_module_logger('DiffHandler')

    def apply_diff_to_file(self, original_file: str, file_name: str, code_diff: str) -> str:
        """Apply a diff to a specific file."""
        lines = original_file.splitlines(keepends=True)
        file_pattern = re.compile(r'^--- a/(\S+)')
        diff_lines = code_diff.split('\n')

        apply_changes = False

        for i, line in enumerate(diff_lines):
            file_match = file_pattern.match(line)
            if file_match:
                current_file = file_match.group(1)
                apply_changes = (current_file == file_name)
                continue

            if apply_changes:
                updated_lines, start_line, removed_lines, added_lines = self._apply_diff(lines, diff_lines[i:])
                self.logger.info(f"Applied diff to file: {file_name}, start_line: {start_line}, removed_lines: {removed_lines}, added_lines: {added_lines}")
                return ''.join(updated_lines)

        return original_file

    def apply_unified_diff_to_content(self, original_content: str, code_diff: str) -> Tuple[bool, str]:
        """Apply a unified diff to the original content."""
        if not code_diff.strip():
            reason = 'Empty diff.'
            return False, reason

        lines = original_content.splitlines(keepends=True)
        updated_lines, start_line, removed_lines, added_lines = self._apply_diff(lines, code_diff.split('\n'))

        if not removed_lines and not added_lines:
            reason = 'No lines were added or removed.'
            return False, reason

        self.logger.info(f"Applied diff to content at start_line: {start_line}, removed_lines: {removed_lines}, added_lines: {added_lines}")
        return True, ''.join(updated_lines)

    def _apply_diff(self, lines: List[str], diff_lines: List[str]) -> Tuple[List[str], int, List[int], List[Tuple[int, str]]]:
        """Helper method to apply a diff to lines."""
        diff_pattern = re.compile(r'@@ -(\d+),\d+ \+(\d+),\d+ @@')
        added_lines = []
        removed_lines = []
        rem_count = 0
        start_line = 0

        for i, line in enumerate(diff_lines):
            match = diff_pattern.match(line)
            if match:
                start_line = int(match.group(2)) - 1
                for j, diff_line in enumerate(diff_lines[i+1:], start=1):
                    if diff_line.startswith('+') and not diff_line.startswith('+++'):
                        add_pos = start_line + j - 1 - rem_count
                        added_lines.append((add_pos, diff_line[1:] + '\n'))
                    elif diff_line.startswith('-') and not diff_line.startswith('---'):
                        rem_count += 1
                        removed_lines.append(start_line + j - 1)
                    elif diff_line.startswith('@@'):
                        break

                # Remove lines in reverse order to avoid index shifting
                for pos in sorted(removed_lines, reverse=True):
                    if 0 <= pos < len(lines):
                        del lines[pos]

                # Adjust positions for added lines after removals
                offset = 0
                for pos, added_line in added_lines:
                    if 0 <= pos + offset <= len(lines):
                        lines.insert(pos + offset, added_line)

                break

        return lines, start_line, removed_lines, added_lines
