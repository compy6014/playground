from helpers.utils import remove_line_numbers
import logging


class AICommentHelper():
    """Helper class for handling comment preparation."""

    def __init__(self):
        pass

    def prepare_suggestion_comment(
        self,
        header: str = None,
        subheader: str = None,
        text: str = None,
        explanation_text_1: str = None,
        code_suggestion: str = None,
        original_source_code: str = None,
        explanation_text_2: str = None,
        disclaimer_text: str = None,
        commitable_suggestion: bool = True,
        disclaimer_title: str = "Note",
        expansion_summary: str = "Click for details",
        language: str = None
    ) -> str:
        """
        Prepare a versatile review comment with optional and modular components.

        This function combines the capabilities of both suggestion and general comment preparation.
        It allows for the inclusion of headers, subheaders, explanatory texts, code suggestions,
        original source code, disclaimers, and expandable details sections.

        This produces Markdown similar to:

        ## AI Code Review

        Naming Conventions Violation

        Pointers must be prefixed with 'p'.

        Here is more context about why this convention is important.

        <details><summary>Click for details</summary>

        **Original source code:**
        ```
        Some original code here...
        ```

        **Code Suggestion:**
        ```suggestion
        Some fixed code here...
        ```

        **Explanation:** Explanation of the fix details.

        </details>

        > **Note:** Please confirm your changes.

        :param header: Header text for the comment (e.g., "AI Code Review", "General Feedback").
        :param subheader: Subheader text in bold (e.g., "**Preprocessor:** Commented code").
        :param text: Descriptive text explaining the comment or violation.
        :param explanation_text_1: Additional explanation or context for the comment.
        :param code_suggestion: Suggested code modification.
        :param original_source_code: The original source code snippet related to the comment.
        :param explanation_text_2: Further explanation, such as reasoning behind the code suggestion.
        :param disclaimer_text: Optional disclaimer or note to be appended at the end.
        :param commitable_suggestion: Flag indicating if the code suggestion should be marked as a commitable suggestion.
        :param disclaimer_title: Title for the disclaimer section (default is "Note").
        :param expansion_summary: Summary text for the expandable details section (default is "Click for details").
        :param language: Programming language for syntax highlighting in code blocks.
        :return: Formatted review comment as a string.
        """
        comment_parts = []

        # Header
        if header:
            comment_parts.append(f"## {header}\n")

        # Subheader
        if subheader:
            comment_parts.append(f"{subheader}\n")

        # Main Text
        if text:
            comment_parts.append(f"{text}\n")

        # Explanation Text 1
        if explanation_text_1:
            comment_parts.append(f"{explanation_text_1}\n")

        # Details Section (Original Source Code and/or Code Suggestion)
        if original_source_code or code_suggestion or explanation_text_2:
            comment_parts.append(f"<details><summary>{expansion_summary}</summary>\n\n")

            # Original Source Code
            if original_source_code:
                comment_parts.append("**Original source code:**\n")
                if language:
                    comment_parts.append(f"```{language}\n{original_source_code}\n```\n")
                else:
                    comment_parts.append(f"```\n{original_source_code}\n```\n")

            # Code Suggestion
            if code_suggestion:
                if commitable_suggestion:
                    code_suggestion = remove_line_numbers(code_suggestion)
                    code_block = f"```suggestion\n{code_suggestion}\n```"
                else:
                    code_block = f"```\n{code_suggestion}\n```"

                comment_parts.append("**Code Suggestion:**\n")
                comment_parts.append(f"{code_block}\n")

            # Explanation Text 2
            if explanation_text_2:
                comment_parts.append(f"{explanation_text_2}\n")

            comment_parts.append("</details>\n")

        # Disclaimer Section
        if disclaimer_text:
            comment_parts.append(f"> **{disclaimer_title}:** {disclaimer_text}")

        # Join all parts with newlines
        comment = "\n".join(comment_parts)
        return comment

    def prepare_general_suggestion_comment(
        self,
        header: str = None,
        subheader: str = None,
        text: str = None,
        original_source_code: str = None,
        code_suggestion: str = None,
        language: str = None
    ) -> str:
        """
        Prepare a formatted general suggestion review comment with all input parameters optional.
        """
        parts = []

        # Header
        if header:
            parts.append(f"## {header}\n")

        # Subheader
        if subheader:
            parts.append(f"**{subheader}**\n")

        # Text
        if text:
            parts.append(f"{text}\n")

        # Show the details section only if original_source_code or code_suggestion is provided
        if original_source_code or code_suggestion:
            parts.append("<details><summary>Click for code details</summary>\n\n")

            # Original Source Code
            if original_source_code:
                parts.append("Original source code:\n")
                if language:
                    parts.append(f"```{language}\n{original_source_code}\n```\n")
                else:
                    parts.append(f"```\n{original_source_code}\n```\n")

            # Code Suggestion
            if code_suggestion:
                parts.append("Code suggestion:\n")
                if language:
                    parts.append(f"```{language}\n{code_suggestion}\n```\n")
                else:
                    parts.append(f"```\n{code_suggestion}\n```\n")

            parts.append("</details>")

        return "\n".join(parts)

    def create_dual_review_comments(
        self,
        commit_id: str,
        file_path: str,
        line_position: tuple,
        position: str,
        header: str = None,
        subheading: str = None,
        explanation_text_1: str = None,
        code_suggestion: str = None,
        explanation_text_2: str = None,
        disclaimer_text: str = None
    ) -> tuple:
        """
        Creates two review comments for the same code suggestion:
          1) A comment with commitable_suggestion=True
          2) A comment with commitable_suggestion=False

        Then calls 'create_comment_body_for_position' for both and returns both comments.

        :param commit_id: The commit SHA to which the comment should be attached.
        :param file_path: Path to the file being reviewed.
        :param line_position: A tuple (start_line, end_line).
        :param position: The side of the diff ("LEFT" or "RIGHT").
        :param header: Comment header text.
        :param subheading: Comment subheading text.
        :param explanation_text_1: First part of the explanation text.
        :param code_suggestion: The code suggestion snippet.
        :param explanation_text_2: Further explanation text.
        :param disclaimer_text: Optional disclaimer text for the note.
        :return: A tuple of two comment dictionaries (commitable and non-commitable).
        """

        # 1) Prepare commitable suggestion
        commitable_comment_str = self.prepare_suggestion_comment(
            header=header,
            subheading=subheading,
            explanation_text_1=explanation_text_1,
            code_suggestion=code_suggestion,
            explanation_text_2=explanation_text_2,
            disclaimer_text=disclaimer_text,
            commitable_suggestion=True
        )
        commitable_comment_body = self.create_comment_body_for_position(
            comment=commitable_comment_str,
            commit_id=commit_id,
            file_path=file_path,
            line_position=line_position,
            position=position
        )

        # 2) Prepare non-commitable suggestion
        non_commitable_comment_str = self.prepare_suggestion_comment(
            header=header,
            subheading=subheading,
            explanation_text_1=explanation_text_1,
            code_suggestion=code_suggestion,
            explanation_text_2=explanation_text_2,
            disclaimer_text=disclaimer_text,
            commitable_suggestion=False
        )
        non_commitable_comment_body = self.create_comment_body_for_position(
            comment=non_commitable_comment_str,
            commit_id=commit_id,
            file_path=file_path,
            line_position=line_position,
            position=position
        )

        return commitable_comment_body, non_commitable_comment_body

    def create_comment_body_for_position(self, comment, commit_id, file_path, line_position, position) -> dict:
        """Creates a comment body for position-based comments.

        Args:
            comment: The comment object containing the text and filename.
            start_line (int): The starting line number of the comment.
            end_line (int): The ending line number of the comment.
            position (str): The side of the diff ("LEFT" or "RIGHT").

        Returns:
            dict: A dictionary containing the necessary information for post_review_comment.
        """
        start_line, end_line = line_position
        comment_body = {
            "body": comment,
            'commit_id': commit_id,
            'path': file_path,
            'line': start_line,
            'side': position
        }
        if end_line > start_line:
            comment_body['start_line'] = start_line
            comment_body['line'] = end_line

        return comment_body

    def prepare_pr_review_data(
        self,
        commit_id: str,
        header: str = None,
        subheading: str = None,
        text: str = None,
        disclaimer_title: str = "Note",
        disclaimer_text: str = None,
        comments: list = None,
        event: str = "COMMENT"
    ) -> dict:
        """
        Prepares the pull request review data.

        :param commit_id: The commit SHA to which the review data are related.
        :param header: Optional review header.
        :param subheading: Optional review subheading.
        :param text: Optional body text for the review.
        :param comments: A list of comment dictionaries, each containing path, position, and body.
        :param event: The event type for the review ("COMMENT" by default).
        :return: A dictionary containing the review data.
        """
        lines = []
        if header:
            lines.append(f"## {header}\n")
        if subheading:
            lines.append(f"**{subheading}**\n")
        if text:
            lines.append(f"{text}\n")
        if disclaimer_text:
            lines.append(f"> **{disclaimer_title}:** {disclaimer_text}\n")
        review_body = "\n".join(lines)

        review_data = {
            "commit_id": commit_id,
            "body": review_body,
            "event": event,
            "comments": comments if comments else []
        }

        return review_data

    def prepare_review_comment_data(
        self,
        path: str,
        body: str,
        position: str = None,
        line: int = None,
        side: str = None,
        start_line: int = None
    ) -> dict:
        """
        Prepare the data for a review comment.
        """
        comment_data = {
            "path": path,
            "body": body
        }
        if position:
            comment_data["position"] = position
        if line:
            comment_data["line"] = line
        if side:
            comment_data["side"] = side
        if start_line and start_line < line:
            comment_data["start_line"] = start_line

        return comment_data

    def create_conversation_comment(
        self,
        header=None,
        description=None,
        subheading=None,
        expansions=None,  # List of dicts with 'summary', 'header', 'text', 'original_source_code', 'code_suggestion', 'nested_expansions'
        original_source_code=None,  # Dict with 'language' and 'code'
        code_suggestion=None,       # Dict with 'language' and 'code'
        disclaimer_title="Note",    # Title for the disclaimer section, defaults to "Note"
        disclaimer_text=None        # Text for the disclaimer section
    ):
        """
        Generates a GitHub comment with optional sections, including original source code and code suggestions
        both at the top level and within expansions.

        Parameters:
        - header (str): The main header (e.g., "## AI Code Review").
        - description (str): Description text under the header.
        - subheading (str): A subheading or additional information.
        - expansions (list of dict): Each dict can have:
            - 'summary' (str): Summary text for the expansion (default: 'Click to expand').
            - 'header' (str): Header for the expansion.
            - 'text' (str): Text inside the expansion.
            - 'original_source_code' (dict): {'language': 'cpp', 'code': '...'}
            - 'code_suggestion' (dict): {'language': 'cpp', 'code': '...'}
            - 'nested_expansions' (list of dict): Further expansions with the same structure.
        - original_source_code (dict): {'language': 'cpp', 'code': '...'}
        - code_suggestion (dict): {'language': 'cpp', 'code': '...'}
        - disclaimer_title (str): Title for the disclaimer section. Defaults to "Note".
        - disclaimer_text (str): Text for the disclaimer section. The disclaimer is displayed only if this is provided.

        Returns:
        - str: Markdown-formatted GitHub comment.
        """
        comment_lines = []

        # Header
        if header:
            comment_lines.append(f"## {header}")
            comment_lines.append("")

        # Description
        if description:
            comment_lines.append(description)
            comment_lines.append("")

        # Subheading
        if subheading:
            comment_lines.append(f"**{subheading}**")
            comment_lines.append("")

        # Top-level Original Source Code
        if original_source_code:
            #language = original_source_code.get('language', '')
            #code = original_source_code.get('code', '')
            code = original_source_code
            language = "cpp"
            comment_lines.append("**Original Source Code:**")
            comment_lines.append(f"```{language}\n{code}\n```")
            comment_lines.append("")

        # Top-level Code Suggestion
        if code_suggestion:
            #language = code_suggestion.get('language', '')
            #code = code_suggestion.get('code', '')
            code = code_suggestion
            language = "cpp"
            comment_lines.append("**Suggested Code:**")
            comment_lines.append(f"```{language}\n{code}\n```")
            comment_lines.append("")

        # Expansions
        if expansions:
            for expansion in expansions:
                comment_lines.extend(self._process_expansion(expansion, level=1))

        # Disclaimer
        if disclaimer_text:
            disclaimer_line = f"> **{disclaimer_title}:** {disclaimer_text}"
            comment_lines.append(disclaimer_line)
            comment_lines.append("")

        # Join all lines into a single string
        return "\n".join(comment_lines)

    def create_markdown_comment(
        self,
        header=None,
        subheader=None,
        body=None,
        disclaimer_title="Note",
        disclaimer_text=None
    ):
        """
        Generates a simplified Markdown-formatted GitHub comment with optional sections.

        Parameters:
        - header (str): The main header (e.g., "## Main Header").
        - subheader (str): A subheader or secondary heading (e.g., "### Subheader").
        - body (str): The main body text of the comment.
        - disclaimer_title (str): Title for the disclaimer section. Defaults to "Note".
        - disclaimer_text (str): Text for the disclaimer section. The disclaimer is displayed only if this is provided.

        Returns:
        - str: Markdown-formatted GitHub comment.
        """
        comment_lines = []

        # Heading 1
        if header:
            comment_lines.append(f"## {header}")
            comment_lines.append("")

        # Heading 2 (Subheader)
        if subheader:
            comment_lines.append(f"### {subheader}")
            comment_lines.append("")

        # Body
        if body:
            comment_lines.append(body)
            comment_lines.append("")

        # Disclaimer
        if disclaimer_text:
            disclaimer_line = f"> **{disclaimer_title}:** {disclaimer_text}"
            comment_lines.append(disclaimer_line)
            comment_lines.append("")

        # Join all lines into a single string
        return "\n".join(comment_lines)

    def create_expansion(
        self,
        summary: str = "Click to expand",
        header: str = None,
        text: str = None,
        original_source_code: dict = None,
        code_suggestion: dict = None,
        nested_expansions: list = None
    ) -> dict:
        """
        Creates a single expansion dictionary.

        Parameters:
        - summary (str): Summary text for the expansion.
        - header (str): Header for the expansion.
        - text (str): Text inside the expansion.
        - original_source_code (dict): {'language': 'cpp', 'code': '...'}
        - code_suggestion (dict): {'language': 'cpp', 'code': '...'}
        - nested_expansions (list of dict): Further expansions.

        Returns:
        - dict: A dictionary representing a single expansion.
        """
        expansion = {
            "summary": summary,
            "header": header,
            "text": text,
            "original_source_code": original_source_code,
            "code_suggestion": code_suggestion,
            "nested_expansions": nested_expansions or []
        }
        return expansion

    def _process_expansion(self, expansion, level=1):
        """
        Helper function to process an expansion or nested expansion.

        Parameters:
        - expansion (dict): Expansion details.
        - level (int): Current depth level for nested expansions.

        Returns:
        - list of str: Lines of Markdown for the expansion.
        """
        lines = []
        indent = "  " * (level - 1)  # Indentation based on level for readability

        # Collect key data
        summary_text = expansion.get('summary', 'Click to expand')
        expansion_header = expansion.get('header')
        text = expansion.get('text')
        original_source_code = expansion.get('original_source_code')
        code_suggestion = expansion.get('code_suggestion')
        nested_expansions = expansion.get('nested_expansions')

        # If there's a header, place it above the <details> block
        if expansion_header:
            lines.append(f"{indent}{expansion_header}\n")

        # Start the collapsible section
        lines.append(f"{indent}<details><summary>{summary_text}</summary>\n")
        content_indent = "  " * level

        # Main text within expansion
        if text:
            lines.append(f"{content_indent}{text}\n")

        # Original Source Code within expansion
        if original_source_code:
            language = original_source_code.get('language', '')
            code = original_source_code.get('code', '')
            lines.append(f"{content_indent}**Original Source Code:**")
            if language:
                lines.append(f"{content_indent}```{language}\n{code}\n{content_indent}```\n")
            else:
                lines.append(f"{content_indent}```\n{code}\n{content_indent}```\n")

        # Code Suggestion within expansion
        if code_suggestion:
            language = code_suggestion.get('language', '')
            code = code_suggestion.get('code', '')
            lines.append(f"{content_indent}**Suggested Code:**")
            lines.append(f"{content_indent}```{language}\n{code}\n{content_indent}```\n")

        # Nested expansions
        if nested_expansions:
            for nested_exp in nested_expansions:
                lines.extend(self._process_expansion(nested_exp, level=level + 1))

        # Close the collapsible section
        lines.append(f"{indent}</details>\n")
        return lines

    def is_within_scope(self, provided_lines: list, scope_lines: list) -> bool:
        """
        Check if the provided line numbers [first, last] are within the comment scope lines [first, last].

        :param provided_lines: List containing the first and last line numbers of the provided lines.
        :param scope_lines: List containing the first and last line numbers of the scope lines.
        :return: True if the provided lines are within the scope lines, False otherwise.
        """
        provided_first, provided_last = provided_lines
        scope_first, scope_last = scope_lines

        return scope_first <= provided_first <= provided_last <= scope_last
