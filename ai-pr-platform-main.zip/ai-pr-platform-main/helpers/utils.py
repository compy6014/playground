# helpers/utils.py
import os
import re
import json
import fnmatch
import smtplib
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from urllib.parse import urlparse

def save_to_file(content: str, file_path: str) -> None:
    """Save content to a file at the specified file path."""
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def read_from_file(file_path: str) -> str:
    """Read content from a file at the specified file path."""
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    else:
        raise FileNotFoundError(f"The file {file_path} does not exist.")

def extract_pr_info(pr_url: str) -> dict:
    """Extract host, owner, repo, and PR number from a PR URL for various GitHub hosts."""
    parsed = urlparse(pr_url)
    host = parsed.netloc
    # Generic pattern for GitHub PR URLs
    pattern = r'https://[^/]+/(?P<owner>[^/]+)/(?P<repo>[^/]+)/pull/(?P<pr_number>\d+)'    
    match = re.match(pattern, pr_url)
    if match:
        return {
            "host": host,
            "owner": match.group('owner'),
            "repo": match.group('repo'),
            "pr_number": match.group('pr_number')
        }
    else:
        return {"error": "URL does not match the expected pattern", "host": host}
    
def get_suggestion_line_numbers(suggestion: str) -> list[int]:
    """Return the first and last line number from a code suggestion."""
    line_numbers = re.findall(r'^\s*(\d+)', suggestion, re.MULTILINE)
    if line_numbers:
        first_line = int(line_numbers[0])
        last_line = int(line_numbers[-1])
        return [first_line, last_line]
    else:
        return []

def remove_line_numbers(suggestion: str, offset: int = -1) -> str:
    """
    Remove line numbers and leading spaces from a code suggestion while adjusting indentation based on offset.

    Args:
        suggestion (str): The code suggestion string containing line numbers.
        offset (int, optional): The number of spaces to adjust indentation.
                                Negative values remove spaces, positive values add spaces.
                                Defaults to -1.

    Returns:
        str: The code suggestion with line numbers and leading spaces removed, and indentation adjusted.
    """
    lines = suggestion.split('\n')
    processed_lines = []
    for line in lines:
        # Match leading spaces, digits, spaces, rest of line
        match = re.match(r'^(\s*)(\d+)(\s+)(.*)', line)
        if match:
            # Spaces after the line number
            spaces_after_line_number = match.group(3)
            code = match.group(4)
            # Reconstruct the line without leading spaces and line number
            processed_line = spaces_after_line_number + code
        else:
            processed_line = line

        # Adjust indentation based on offset
        if offset != 0:
            if offset > 0:
                # Add spaces to the beginning
                processed_line = (' ' * offset) + processed_line
            else:
                # Remove spaces from the beginning, up to the absolute value of offset
                remove_spaces = -offset
                # Count leading spaces
                leading_spaces_match = re.match(r'^ *', processed_line)
                leading_spaces_count = len(leading_spaces_match.group(0))
                # Determine how many spaces to remove
                spaces_to_remove = min(remove_spaces, leading_spaces_count)
                # Remove the spaces
                processed_line = processed_line[spaces_to_remove:]
        processed_lines.append(processed_line)
    return '\n'.join(processed_lines)

def get_team_name(owner, repo, branch=None, config_path=None):
    """
    Get the team name based on the owner, repo, and optionally branch.
    Reads configuration from a JSON file (config/teams_mapping.json).

    Args:
        owner (str): The repository owner.
        repo (str): The repository name.
        branch (str, optional): The branch name. Defaults to None.
        config_path (str, optional): Path to the JSON configuration file. Defaults to 'config/teams_mapping.json'.

    Returns:
        str: The team name or a default value if no match is found.
    """
    # Default path to the JSON configuration file
    if not config_path:
        # Use a relative path based on the location of this script
        base_dir = os.path.dirname(os.path.abspath(__file__))  # Path to helpers directory
        config_path = os.path.join(base_dir, '..', 'config', 'teams_mapping.json')  # Navigate to config/teams_mapping.json

    # Convert inputs to lowercase for case-insensitive matching
    owner_lower = owner.lower() if owner else ""
    repo_lower = repo.lower() if repo else ""
    branch_lower = branch.lower() if branch else None

    # Read and parse the JSON configuration file
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"The configuration file {config_path} does not exist.")
    except json.JSONDecodeError as e:
        raise ValueError(f"Error decoding JSON configuration file {config_path}: {e}")

    # Use case-insensitive lookup
    for config_owner, owner_repos in config.items():
        if config_owner.lower() == owner_lower:
            for config_repo, repo_rules in owner_repos.items():
                if config_repo.lower() == repo_lower:
                    # If a branch is provided, check for a branch-specific team name
                    if branch_lower:
                        for pattern, rule in repo_rules.items():
                            if fnmatch.fnmatch(branch_lower, pattern.lower()):
                                team_name = rule.get('team_name') if isinstance(rule, dict) else rule
                                if team_name:
                                    return get_last_team_name(team_name)
                    # If branch not specified or no match found, use the default rule
                    rule = repo_rules.get("default")
                    if rule:
                        team_name = rule.get('team_name') if isinstance(rule, dict) else rule
                        return get_last_team_name(team_name)
                    return f"{owner}/{repo}"
    # Return owner/repo as the team name if no match found
    return f"{owner.lower()}/{repo.lower()}"

def get_team_name_by_team(owner, repo, branch=None, config_path=None):
    """
    Get the team name based on the owner, repo, and optionally branch using the inverted team mapping structure.
    Reads configuration from a JSON file where team names are top-level keys (config/teams_mapping_by_team.json).

    Args:
        owner (str): The repository owner.
        repo (str): The repository name.
        branch (str, optional): The branch name. Defaults to None.
        config_path (str, optional): Path to the JSON configuration file. Defaults to 'config/teams_mapping_by_team.json'.

    Returns:
        str: The team name or a default value if no match is found.
    """
    # Default path to the JSON configuration file
    if not config_path:
        # Use a relative path based on the location of this script
        base_dir = os.path.dirname(os.path.abspath(__file__))  # Path to helpers directory
        config_path = os.path.join(base_dir, '..', 'config', 'teams_mapping_by_team.json')  # Navigate to config/teams_mapping_by_team.json

    # Convert inputs to lowercase for case-insensitive matching
    owner_lower = owner.lower() if owner else ""
    repo_lower = repo.lower() if repo else ""
    branch_lower = branch.lower() if branch else None
    
    # Create the organization/repository key to search for
    org_repo_key = f"{owner_lower}/{repo_lower}"

    # Read and parse the JSON configuration file
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"The configuration file {config_path} does not exist.")
    except json.JSONDecodeError as e:
        raise ValueError(f"Error decoding JSON configuration file {config_path}: {e}")

    # Iterate through all teams to find a match
    for team_name, team_repos in config.items():
        # Check each organization/repository entry for this team
        for config_org_repo, branch_rules in team_repos.items():
            # Skip metadata keys (keys starting with underscore)
            if config_org_repo.startswith('_'):
                continue
                
            if config_org_repo.lower() == org_repo_key:
                # Found a matching organization/repository
                
                # If a branch is provided, check for a branch-specific rule
                if branch_lower:
                    for pattern, rule in branch_rules.items():
                        if fnmatch.fnmatch(branch_lower, pattern.lower()):
                            # Found a matching branch pattern, return the team name
                            return get_last_team_name(team_name)
                    # If branch was specified but no pattern matched, continue to next team
                    continue
                else:
                    # No branch specified - return the team name if there are any rules
                    if branch_rules:
                        return get_last_team_name(team_name)
    
    # Return owner/repo/branch as the team name if no match found
    if branch_lower:
        return f"{owner_lower}/{repo_lower}/{branch_lower}"
    else:
        return f"{owner_lower}/{repo_lower}"

def get_last_team_name(team_name):
    """
    If team_name is a comma-separated string, return the last value (stripped).
    """
    if isinstance(team_name, str) and ',' in team_name:
        return team_name.split(',')[-1].strip()
    return team_name

def decode_comment_id(encoded_id: str) -> str:
    """
    Decode a base64 encoded comment ID.

    Args:
        encoded_id: Base64 encoded comment ID.

    Returns:
        Decoded comment ID string.
    """
    return base64.b64decode(encoded_id).decode('utf-8')

def count_coverity_fix_lines(text: str) -> tuple[int, int]:
    """
    Calculate the number of lines in the hunk from the text suggestion.

    Args:
        text (str): The text containing the code suggestion.

    Returns:
        tuple: The start line number and the number of lines in the hunk.
    """
    # Regular expression to extract the code block between "```suggestion" and "```"
    match = re.search(r'```suggestion\n(.*?)\n```', text, re.DOTALL)
    if match:
        code_block = match.group(1)
        # Extract the start line number from the first line of the code block
        first_line_match = re.search(r'(\d+)', code_block)
        if first_line_match:
            start_line = int(first_line_match.group(1))
        else:
            start_line = 0
        # Split the code block by newline characters and count the lines
        lines = code_block.split('\n')
        return start_line, len(lines)
    else:
        return 0, 0

def count_coverity_source_code_lines(text: str) -> tuple[int, int]:
    """
    Calculate the number of lines in the hunk from the text suggestion and return the start line number.

    Args:
        text (str): The text containing the code suggestion.

    Returns:
        tuple: The start line number and the number of lines in the hunk.
    """
    # Regular expression to extract the start line number and the code block
    match = re.search(r'(\d+)\s+(.*)', text, re.DOTALL)
    if match:
        start_line = int(match.group(1))
        code_block = match.group(2)
        # Split the code block by actual newline characters and count the lines
        lines = code_block.split('\n')
        return start_line, len(lines)
    else:
        return 0, 0

def remove_line_numbers_from_suggestion(suggestion: str) -> str:
    """
    Remove line numbers from the suggestion text.

    Args:
        suggestion (str): The suggestion text with line numbers.

    Returns:
        str: The cleaned suggestion text without line numbers.
    """
    pattern = r'```suggestion\n(.*?)\n```'

    def clean_code_block(match):
        code_block = match.group(1)
        lines = code_block.split('\n')
        cleaned_lines = [re.sub(r'^\s*\d+\s', '', line) for line in lines]
        cleaned_code_block = '\n'.join(cleaned_lines)
        return f'```suggestion\n{cleaned_code_block}\n```'

    cleaned_suggestion = re.sub(pattern, clean_code_block, suggestion, flags=re.DOTALL)
    return cleaned_suggestion

def get_json_files_from_paths(coverity_json: str = None, coverity_json_dir: str = None, logger=None) -> list[str]:
    """
    Get list of JSON files from the specified directory or single file.
    Includes basic error/exception handling for missing files/directories.

    Args:
        coverity_json (str, optional): Path to a single JSON file.
        coverity_json_dir (str, optional): Path to directory containing JSON files.
        logger: Logger instance for error logging.

    Returns:
        List of JSON file paths to process.
    """
    if coverity_json:
        # Check if the single JSON file exists
        if not os.path.isfile(coverity_json):
            if logger:
                logger.error(f"Specified Coverity JSON file does not exist: {coverity_json}")
            return []
        return [coverity_json]

    elif coverity_json_dir:
        # Check if the directory exists
        if not os.path.isdir(coverity_json_dir):
            if logger:
                logger.error(f"Specified Coverity JSON directory does not exist: {coverity_json_dir}")
            return []

        try:
            json_files = [
                os.path.join(coverity_json_dir, file)
                for file in os.listdir(coverity_json_dir)
                if file.endswith(".json")
            ]
        except Exception as e:
            if logger:
                logger.error(f"Error reading directory {coverity_json_dir}: {e}")
            return []

        if not json_files and logger:
            logger.warning(f"No JSON files found in directory: {coverity_json_dir}")
        return json_files

    if logger:
        logger.warning("No Coverity JSON file or directory specified.")
    return []

def send_email(smtp_server, smtp_port, from_email, subject, body, to_email, attachments=None):
    """
    Send an email with optional attachments.
    
    Args:
        smtp_server (str): SMTP server hostname
        smtp_port (int): SMTP server port
        from_email (str): Sender email address
        subject (str): Email subject
        body (str): Email body (HTML format)
        to_email (str or list): Recipient email address(es)
        attachments (list, optional): List of file paths to attach
    
    Returns:
        bool: True if email sent successfully, False otherwise
    """
    try:
        # Create MIMEText object to represent email
        msg = MIMEMultipart()
        msg['From'] = from_email
        
        # Handle multiple recipients
        if isinstance(to_email, list):
            msg['To'] = ', '.join(to_email)
            recipients = to_email
        else:
            msg['To'] = to_email
            recipients = [to_email]
            
        msg['Subject'] = subject

        # Attach email body
        msg.attach(MIMEText(body, 'html'))

        # Attach files if provided
        if attachments:
            for filepath in attachments:
                if not os.path.isfile(filepath):
                    print(f"Attachment {filepath} does not exist, skipping.")
                    continue
                with open(filepath, 'rb') as f:
                    part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'  
                msg.attach(part)

        # Create SMTP session and send email
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.send_message(msg)
        server.quit()
        print("Email sent successfully")
        return True
        
    except Exception as e:
        print(f"Failed to send email: {e}")
        return False
