import argparse  
from scripts.workflow_executor import WorkflowExecutor  
  

def parse_arguments():  
    parser = argparse.ArgumentParser(description='Execute workflow with specified parameters')  
      
    parser.add_argument('-a', '--alerts', type=str, help='List of alerts (comma-separated integers and/or ranges, e.g., 1123, 1130-1135, 1147)')
    parser.add_argument('-fd', '--from-date', type=str, help='Start date in ISO format (e.g., 2025-03-15T00:00:00Z)')
    parser.add_argument('-td', '--to-date', type=str, help='End date in ISO format (e.g., 2025-03-15T00:00:00Z)')  
    parser.add_argument('-t', '--team-name', type=str, required=True, help='Team name')  
    parser.add_argument('-r', '--rule-override', type=str, help='Override template rules')
    parser.add_argument('-te', '--trigger-event', type=str, required=True, help='Trigger event type')
  
    return parser.parse_args()  
  
def main():  
    args = parse_arguments()  
      
    context = {
        "alert_numbers": args.alerts,  
        "from_date": args.from_date,  
        "to_date": args.to_date,
        "team_name": args.team_name, 
        "rule_override": args.rule_override,
        "trigger_event": args.trigger_event
    }   
  
    executor = WorkflowExecutor(workflow_name="demo_codeql", team_name=args.team_name)  
    executor.execute(context)  
  
if __name__ == "__main__":  
    main() 

