# API Integration and Workflow Automation Framework

## System Overview

Modular API integration and workflow automation framework is designed to interact with various services through a flexible, configuration-driven approach. The system consists of several key components that work together to provide a robust solution for API interactions, workflow execution, and formatted output generation.

## Core Components

### 1. [BaseAPI](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/scripts/base_api.py)

**Purpose**: Provides a foundation for API communication with configurable authentication methods and request handling.

**Key Features**:
- Multiple configurable environments with specific base URLs
- Multiple authentication methods (bearer token, basic auth, custom headers)
- Multiple configurable headers
- Error handling and retry mechanisms
- Environment variable-based secret management

**Important Notes**: Number of defined environments and headers is not limited, but each need to have an unique name. This name will be used in creating specific API request via SpecificAPI. 

**Configuration Source**: `api_config.json`

**Integration**: It relies on centralized ConfigLoader and creates a foundation for SpecificAPI to build upon.


### 2. [SpecificAPI](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/scripts/specific_api.py)

**Purpose**: Extends BaseAPI with template-based request construction and response processing capabilities.

**Key Features**:
- Template-based request construction
- Pagination handling
- Response filtering and extraction
- Post-processing filters (value matching, date ranges)
- Sensitive data masking in logs

**Important Notes**: Request template needs to follow naming established by BaseAPI in api_config.json. Implemented API response processing can extract one or more specific values (response_filter) of structures (post_filter). 

**Configuration Source**: `request_templates.json`

**Integration**: It relies on centralized ConfigLoader and builds specific API request upon foundation created by BaseAPI. 


### 3. [Formatter](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/scripts/template_formatter.py)

**Purpose**: Handles formatting of strings, messages, and other output based on templates that can be customized per team.

**Key Features**:
- Team-specific formatting templates
- Context-based variable substitution
- Support for external template files
- Default templates as fallback

**Important Notes**: If specific template is missing in team-specific customization, it will fallback to default template.

**Configuration Source**: `formatting_templates.json`

**Integration**: It relies on centralized ConfigLoader.


### 4. [WorkflowExecutor](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/scripts/workflow_executor.py)

**Purpose**: Executes workflows defined in templates, with support for team-specific customizations through hooks.

**Key Features**:
- Phase-based workflow execution
- Team-specific workflow customization through hooks (before, after, override)
- Dynamic code execution with proper context
- External script loading

**Important Notes**: Phase definition must follow established rules. Phases can be nested. 

**Configuration Source**: `workflow_templates.json`

**Integration**: It uses all components in actual workflow execution. 


### 5. [ConfigLoader](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/utils/config_loader.py)

**Purpose**: Centralizes the loading of various configuration files used throughout the system.

**Key Features**:
- Loads API configurations
- Loads request templates
- Loads formatter templates
- Loads workflow templates
- Supports external file loading

**Important Notes**: It is a part of utils with FunctionLibrary.

**Configuration Sources**: All JSON configuration and template files.

**Integration**: Integral part used in other classes for reading config and template files.


### 6. [FunctionLibrary](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/utils/utility_functions.py)

**Purpose**: Provides utility functions used across the system.

**Key Features**:
- Base64 encoding/decoding
- Diff handling and application
- Email sending
- Git operations
- Data masking

**Integration**: Functions used in specific workflows and/or other classes.


## Configuration Files

### 1. [api_config.json](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/config/api_config.json)

**Purpose**: Defines API endpoints, authentication methods, and connection parameters.

**Structure**:
- API name as the top-level key
- Base URLs for different environments
- Authentication method and credentials
- Headers, retries, and timeout settings

### 2. [request_templates.json](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/templates/request_templates.json)

**Purpose**: Defines templates for API requests, including endpoints, parameters, and response handling.

**Structure**:
- API name as the top-level key
- Request name as the second-level key
- Method, endpoint, variables, and body parameters
- Response filtering and post-processing options

### 3. [formatting_templates.json](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/templates/formatting_templates.json)

**Purpose**: Defines templates for formatting output such as commit messages, PR titles, and email content.

**Structure**:
- Template category as the top-level key
- Team name as the second-level key
- Template names and their content as key-value pairs

### 4. [workflow_templates.json](https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/templates/workflow_templates.json)

**Purpose**: Defines workflow execution templates, including phases and team-specific customizations.

**Structure**:
- Workflow name as the top-level key
- Phases, imports, and general script path
- Team-specific customizations with before/after/override hooks

## Workflow Execution Process

1. **Initialization**:
   - A `WorkflowExecutor` is created for a specific workflow and team
   - The executor loads the workflow template and prepares the execution environment

2. **Phase Execution**:
   - The workflow is executed phase by phase
   - For each phase, team-specific hooks are inserted at appropriate points
   - Each phase can access and modify the shared execution context

3. **API Interaction**:
   - Phases use `SpecificAPI` to interact with external services
   - API requests are constructed from templates with variable substitution
   - Responses are filtered and processed according to template configuration

4. **Output Formatting**:
   - The `Formatter` class is used to generate consistent, team-specific output
   - Templates are loaded from team configurations or fall back to defaults
   - Context variables are substituted into templates

5. **Post Formatting API Interaction**:
   - Additional API interactions are executed
   
6. **Post Execution**:
   - If defined, email report is generated and sent out



## Configuration Dependencies

```
1. BaseAPI
   ├── Depends on: ConfigLoader
   └── Uses: api_config.json

2. SpecificAPI
   ├── Depends on: BaseAPI
   ├── Depends on: ConfigLoader
   └── Uses: request_templates.json

3. ConfigLoader
   ├── Loads: api_config.json
   ├── Loads: request_templates.json
   ├── Loads: formatting_templates.json
   └── Loads: workflow_templates.json

4. Formatter
   ├── Depends on: ConfigLoader
   └── Uses: formatting_templates.json

5. WorkflowExecutor
   ├── Depends on: ConfigLoader
   ├── Uses: workflow_templates.json
   ├── Uses: SpecificAPI
   └── Uses: Formatter

6. FunctionLibrary
   └── Used by: SpecificAPI and other components
```

