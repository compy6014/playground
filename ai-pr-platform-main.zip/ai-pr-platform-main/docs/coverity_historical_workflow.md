# Coverity Historical Workflow

## Overview

The Coverity Historical workflow is designed to process Coverity CIDs (Coverity Issue IDs) and generate automated fixes by creating pull requests. This workflow is similar to the CodeQL workflow but adapted for Coverity's specific requirements.

## Key Differences from CodeQL Workflow

1. **CIDs instead of Alerts**: Uses Coverity CIDs instead of GitHub CodeQL alert numbers
2. **Project-based Search**: Uses Coverity projects instead of GitHub branches for CID discovery
3. **Branch Parameter for PRs**: Branch is still used for PR creation but not for CID discovery
4. **Coverity Historical API**: Calls the Coverity Historical API instead of CodeQL API
5. **CID Validation**: Validates provided CIDs against specified projects before processing
6. **Date-based Discovery**: Supports fetching CIDs by date range from Coverity servers
7. **CID Utils Integration**: Uses dedicated CID utility functions for server communication

## Configuration

### API Configuration

The workflow uses the `coverity_historical` API configuration in `config/api_config.json`:

```json
{
    "coverity_historical": {
        "base_url": {
            "prod": "https://intelligence.amd.com/lcfg/na/fix_from_cid",
            "dev": "https://intelligence.amd.com/lcfg/stg/fix_from_cid"
        },
        "auth_method": "custom_header",
        "custom_headers": {
            "Ocp-Apim-Subscription-Key": {"from_env": "COVERITY_FIX_GENERATION_API_KEY"},
            "username": {"from_env": "USER_NAME"}
        },
        "retries": 3,
        "timeout": 400,
        "verify_ssl": false
    }
}
```

### Request Template

The API request template is defined in `templates/request_templates.json`:

```json
{
    "coverity_historical": {
        "coverity_historical": {
            "method": "POST",
            "header_type": "custom_header",
            "body_params": ["cid", "is_aecg", "is_xhd", "return_diff", "get_file_information", "include_explanation"]
        }
    }
}
```

### Formatting Templates

Templates are defined in `templates/formatting_templates.json` under `coverity_historical_templates`:

```json
{
    "coverity_historical_templates": {
        "default": {
            "coverity_historical_environment": "prod",
            "git_environment": "enterprise",
            "owner": "",
            "repo": "",
            "projects": "project1,project2",
            "base_branch": "main",
            "generate_branch_name": "amd/dev/a1-pr-platform/{ticket_id}/coverity-historical-{CID}",
            "generate_pr_title": "[{ticket_id}] Coverity Historical for {CID}",
            "generate_commit_header": "{ticket_id} - Coverity Historical for {CID}",
            "generate_commit_description": "Coverity Historical fix for CID {CID}",
            "generate_pr_description": "Coverity Historical fix for CID {CID}\n\n{fix_explanation}",
            "label_list": "CoverityHistorical, skip-ci",
            "ticket_id": "DEFAULT-001",
            "detect_fp": true,
            "include_explanation": true,
            "is_aecg": false,
            "is_xhd": false,
            "return_diff": true,
            "get_file_information": true,
            "draft_pr": true,
            "branch_delete": true,
            "alert_process_limit": 50,
            "send_no_alert_email": false,
            "email_server": "atlsmtp10.amd.com",
            "email_port": 25,
            "email_sender": "Coverity Historical <no-reply.CoverityHistorical@amd.com>",
            "email_recipients": "POPULATE",
            "email_subject": "Coverity Historical Summary for {owner}/{repo} projects {projects}",
            "email_body": "external:templates/external/email_body_coverity_historical.html"
        }
    }
}
```

## CID Utils Integration

The workflow integrates with `utils/cid_utils.py` which provides the following key functions:

### `validate_cids_against_project(server, project_name, cids)`
Validates a list of CIDs against a specific project and returns valid/invalid CIDs.

### `get_cids(server, project_name, start_date, end_date, number_of_issues)`
Fetches CIDs from a Coverity server based on date range and project.

### `get_coverity_server_for_project(project_name)`
Returns the appropriate Coverity server URL for a given project.

### `does_cid_exist_in_project(server, project_name, cid)`
Checks if a specific CID exists in a project.

## Environment Variables

The following environment variables are required:

- `COVERITY_FIX_GENERATION_API_KEY`: API key for Coverity Historical API
- `USER_NAME`: Username for the API call
- `GITHUB_API_KEY`: GitHub API token for repository operations
- `COVERITY_USERNAME`: Username for Coverity server authentication (defaults to 'a1_code_gen')
- `COVERITY_PASSWORD`: Password for Coverity server authentication

## Usage

### Command Line Usage

The Coverity Historical workflow can be executed using the command-line entrypoint:

```bash
# Process specific CIDs with repository and project information
python coverity_historical.py -t default -c "12345,67890" -te workflow_dispatch \
  -o "AMD-Radeon-Driver" -r "drivers" -b "amd/stg/kmd" -p "KMD3"

# Process CIDs with date range and project information
python coverity_historical.py -t default -fd "2024-01-01T00:00:00Z" -td "2024-01-31T23:59:59Z" \
  -te workflow_dispatch -o "AMD-Radeon-Driver" -r "drivers" -b "amd/stg/kmd" -p "KMD3"

# Process CIDs with range expansion
python coverity_historical.py -t default -c "12345,12350-12355,67890" -te workflow_dispatch \
  -o "AMD-Radeon-Driver" -r "drivers" -b "amd/stg/kmd" -p "KMD3"
```

### Command Line Parameters

- `-t, --team-name`: Team name (required) - corresponds to template name
- `-c, --cids`: List of CIDs (optional) - comma-separated integers and/or ranges
- `-fd, --from-date`: Start date in ISO format (optional)
- `-td, --to-date`: End date in ISO format (optional)
- `-te, --trigger-event`: Trigger event type (required)
- `-o, --owner`: GitHub repository owner/organization (optional)
- `-r, --repo`: GitHub repository name (optional)
- `-b, --branch`: GitHub branch name for PR creation (optional)
- `-p, --projects`: Coverity projects (optional) - comma-separated

### Basic Usage

```python
# Set up global variables for CID-based processing
globals().update({
    'team_name': 'default',
    'cid_numbers': '12345,67890',
    'trigger_event': 'workflow_dispatch'
})

# Execute the workflow
exec(open('templates/external/coverity_historical_workflow.py').read())
```

```python
# Set up global variables for date-based processing (placeholder)
globals().update({
    'team_name': 'default',
    'from_date': '2024-01-01T00:00:00Z',
    'to_date': '2024-01-31T23:59:59Z',
    'trigger_event': 'workflow_dispatch'
})

# Execute the workflow
exec(open('templates/external/coverity_historical_workflow.py').read())
```

### Parameters

- `team_name`: Template name to use (defaults to 'default')
- `cid_numbers`: Comma-separated list of Coverity CIDs to process (optional)
- `from_date`: Start date for CID discovery (optional, format: YYYY-MM-DDTHH:MM:SSZ)
- `to_date`: End date for CID discovery (optional, format: YYYY-MM-DDTHH:MM:SSZ)
- `trigger_event`: Source of the trigger ('workflow_dispatch' for on-demand)

**Note**: If `cid_numbers` is provided, the workflow will process only those CIDs. If no `cid_numbers` are provided, the workflow will attempt to fetch CIDs from the Coverity Server based on date ranges (currently a placeholder).

### Workflow Steps

1. **Pre-processing**: Load configuration and set up API connections
2. **CID Discovery**: 
   - If `cid_numbers` provided: Use the specified CIDs directly
   - If no `cid_numbers`: Fetch CIDs from Coverity Server based on date range and projects (placeholder)
3. **CID Processing**: For each CID in the list:
   - Call Coverity Historical API
   - Check if issue is predicted as false positive
   - Get file information and diff from API response
   - Apply diff to current file content
4. **Branch and PR Creation**: For each fix:
   - Create or update branch
   - Create pull request with fix
   - Add labels and reviewers
5. **Email Summary**: Send email with results summary

## API Response Format

The Coverity Historical API is expected to return a response with the following structure:

```json
{
    "predicted_as_fp": false,
    "explanation": "Fix explanation text",
    "diff": "unified diff format",
    "file_path": "path/to/file.cpp"
}
```

## Test Scripts

The project includes several test scripts to demonstrate different usage scenarios:

### `tests/run_coverity_historical.py`
A flexible test script that supports both CID-based and date-based scenarios:

```bash
# Run CID-based workflow (default)
python tests/run_coverity_historical.py cid_based

# Run date-based workflow
python tests/run_coverity_historical.py date_based
```

### `tests/run_coverity_both_scenarios.py`
A demonstration script that runs both scenarios side by side:

```bash
python tests/run_coverity_both_scenarios.py
```

This script shows the difference between:
- **CID-based**: Processing specific CIDs (5792988, 6054543)
- **Date-based**: Fetching CIDs from Coverity server based on date range (last 7 days)

## Limitations

1. **File Path Dependency**: The API must return the correct file path for the fix
2. **Coverity Server Access**: Requires proper authentication to Coverity servers
3. **Project-Server Mapping**: Limited to predefined project-server mappings in CID utils
3. **Branch Requirement**: Branch must be specified since Coverity doesn't provide diff context

## Future Enhancements

1. **Date Range Support**: Add support for processing CIDs within date ranges
2. **Enhanced Error Handling**: Improve error handling for API failures
3. **Batch Processing**: Optimize for processing large numbers of CIDs
4. **Coverity Server Integration**: Add direct integration with Coverity Server for CID discovery

## Troubleshooting

### Common Issues

1. **Missing File Path**: If the API doesn't return a file path, the CID will be skipped
2. **API Authentication**: Ensure `COVERITY_FIX_GENERATION_API_KEY` is set correctly
3. **GitHub Permissions**: Verify GitHub API token has sufficient permissions
4. **Branch Access**: Ensure the specified branch exists and is accessible

### Debug Mode

Enable debug logging by setting appropriate log levels in the workflow configuration. 