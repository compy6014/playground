"""
Coverity Historical Workflow Execution Module

This module provides a command-line interface for executing Coverity historical analysis workflows.
It allows users to analyze historical Coverity data by specifying CIDs, date ranges, team information,
and GitHub repository details.

The module integrates with the WorkflowExecutor to process Coverity historical data and generate
appropriate reports or create pull requests based on the analysis results.

Example usage:
    python coverity_historical.py -c "1123,1130-1135,1147" -fd "2025-03-15T00:00:00Z" 
    -td "2025-03-15T23:59:59Z" -t "Security Team" -te "scheduled" -o "myorg" -r "myrepo"
    python coverity_historical.py -fd "2025-03-15T00:00:00Z" -td "2025-03-15T23:59:59Z" 
    -t "Security Team" -te "scheduled" -o "myorg" -r "myrepo" -p "MyProject" -it "Null pointer dereference"
"""

import argparse
from scripts.workflow_executor import WorkflowExecutor


def parse_arguments():
    """
    Parse command-line arguments for the Coverity historical workflow.
    
    Returns:
        argparse.Namespace: Parsed command-line arguments containing:
            - cids: List of CIDs (comma-separated integers and/or ranges)
            - from_date: Start date in ISO format
            - to_date: End date in ISO format  
            - team_name: Team name (required)
            - trigger_event: Trigger event type (required)
            - owner: GitHub repository owner/organization
            - repo: GitHub repository name
            - branch: GitHub branch name for PR creation
            - projects: Coverity projects (comma-separated)
            - issue_type: Optional issue type filter for date-based CID fetching
    
    Raises:
        SystemExit: If required arguments are missing or invalid
    """
    parser = argparse.ArgumentParser(description='Execute Coverity Historical workflow with specified parameters')
    
    parser.add_argument('-c', '--cids', type=str, 
                       help='List of CIDs (comma-separated integers and/or ranges, e.g., 1123, 1130-1135, 1147)')
    parser.add_argument('-fd', '--from-date', type=str, 
                       help='Start date in ISO format (e.g., 2025-03-15T00:00:00Z)')
    parser.add_argument('-td', '--to-date', type=str, 
                       help='End date in ISO format (e.g., 2025-03-15T00:00:00Z)')
    parser.add_argument('-t', '--team-name', type=str, required=True, 
                       help='Team name')
    parser.add_argument('-te', '--trigger-event', type=str, required=True, 
                       help='Trigger event type')
    parser.add_argument('-o', '--owner', type=str, 
                       help='GitHub repository owner/organization')
    parser.add_argument('-r', '--repo', type=str, 
                       help='GitHub repository name')
    parser.add_argument('-b', '--branch', type=str, 
                       help='GitHub branch name (for PR creation)')
    parser.add_argument('-p', '--projects', type=str, 
                       help='Coverity projects (comma-separated)')
    parser.add_argument('-it', '--issue-type', type=str, 
                       help='Optional issue type filter for date-based CID fetching')

    return parser.parse_args()


def main():
    """
    Main function to execute the Coverity historical workflow.
    
    This function:
    1. Parses command-line arguments
    2. Creates a context dictionary with workflow parameters
    3. Initializes the WorkflowExecutor with the specified team and workflow
    4. Executes the workflow with the provided context
    
    The workflow will process Coverity historical data based on the provided parameters
    and may create pull requests or generate reports depending on the workflow configuration.
    
    Raises:
        Exception: If workflow execution fails
    """
    args = parse_arguments()
    
    context = {
        "cid_numbers": args.cids,
        "from_date": args.from_date,
        "to_date": args.to_date,
        "team_name": args.team_name,
        "trigger_event": args.trigger_event,
        "owner": args.owner,
        "repo": args.repo,
        "base_branch": args.branch,
        "projects": args.projects,
        "issue_type": args.issue_type
    }

    executor = WorkflowExecutor(workflow_name="coverity_historical_workflow", team_name=args.team_name)
    executor.execute(context)


if __name__ == "__main__":
    main() 