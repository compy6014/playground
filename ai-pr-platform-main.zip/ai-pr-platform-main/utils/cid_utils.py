"""
Standalone script comprising CID-related helper functions
To be used by PR Platform team
"""

import requests
import os
from datetime import datetime, timedelta


def get_coverity_credentials():
    """Get Coverity credentials from environment variables"""
    username = os.getenv("COVERITY_USERNAME", "a1_code_gen")
    password = os.getenv("COVERITY_PASSWORD", "")
    return username, password


def increment_date(date_str: str, delta: int) -> str:
    """Increment a date in YYYY-MM-DD format by `delta` days."""
    
    date_obj = datetime.strptime(date_str, "%Y-%m-%d")
    next_day = date_obj + timedelta(days=delta)
    return next_day.strftime("%Y-%m-%d")


def convert_date_format(date_str: str) -> str:
    """Convert MM/DD/YY to YYYY-MM-DD format"""

    date_obj = datetime.strptime(date_str, "%m/%d/%y")
    return date_obj.strftime("%Y-%m-%d")


def is_date_in_range(date_str: str, start_date: str, end_date: str) -> bool:
    """Check if date is within the specified range"""
    
    converted_date = convert_date_format(date_str)
    return start_date <= converted_date <= end_date


def get_cids(server: str, project_name: str, start_date: str, end_date: str, number_of_issues: int, issue_type: str = None) -> list[int]:
    """
    Get CIDs from Coverity server based on date range and project
    
    Args:
        server: Coverity server URL
        project_name: Name of the project to search in
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
        number_of_issues: Maximum number of issues to return
        issue_type: Optional issue type filter
    
    Returns:
        List of CID integers
    """
    
    username, password = get_coverity_credentials()
    
    # API endpoint
    url = f"{server}/api/v2/issues/search"
    
    # Query parameters
    to_fetch = number_of_issues * 10 # Fetch more rows to account for filtering after the API call
    params = {
        "includeColumnLabels": "true",
        "locale": "en_us",
        "offset": 0,
        "queryType": "bySnapshot",
        "rowCount": to_fetch,
        "sortOrder": "desc"
    }
    
    # Headers
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    # Request body
    data = {
        "filters": [
            {
                "columnKey": "project",
                "matchMode": "oneOrMoreMatch",
                "matchers": [
                    {
                        "class": "Project",
                        "name": project_name,
                        "type": "nameMatcher"
                    }
                ]
            },
            
            {
                "columnKey": "firstDetected", 
                "matchMode": "oneOrMoreMatch", # dateMatcher uses >= operator. Want to match >= start_date.
                "matchers": [
                    {
                        "date": start_date,
                        "type": "dateMatcher"
                    }
                ]
            },
        ],
        "columns": ["cid", "firstDetected", "displayType"]
    }
    
    try:
        # Make the POST request
        response = requests.post(
            url,
            params=params,
            headers=headers,
            json=data,
            auth=(username, password),
            timeout=30
        )
        response.raise_for_status()
        
    except requests.exceptions.RequestException as e:
        print(f"Error making request to Coverity server: {e}")
        return []
    
    try:
        result = response.json()
    except ValueError as e:
        print(f"Error parsing JSON response: {e}")
        return []

    # Convert the result to a more friendly format
    processed_rows = []
    for row in result.get("rows", []):
        processed_row = {item['key']: item['value'] for item in row}
        processed_rows.append(processed_row)

    # Further filter the results based on end_date and issue_type since the API filters are not working as expected
    filtered_rows = []
    for processed_row in processed_rows:
        # Check date range
        if not is_date_in_range(processed_row['firstDetected'], start_date, end_date):
            continue
            
        # Check issue type if provided
        if issue_type and issue_type.lower().strip() != processed_row['displayType'].lower().strip():
            continue
            
        filtered_rows.append(processed_row)
    
    filtered_rows = filtered_rows[:number_of_issues] # Limit to requested number of issues

    cids = [int(filtered_row['cid']) for filtered_row in filtered_rows]

    return cids


def does_cid_exist_in_project(server: str, project_name: str, cid: int) -> bool:
    """
    Check if a CID exists in a specific project
    
    Args:
        server: Coverity server URL
        project_name: Name of the project to check
        cid: CID to check
    
    Returns:
        True if CID exists in project, False otherwise
    """
    
    username, password = get_coverity_credentials()
    
    # API endpoint
    url = f"{server}/api/v2/issues/search"
    
    # Query parameters
    params = {
        "includeColumnLabels": "true",
        "locale": "en_us",
        "offset": 0,
        "queryType": "bySnapshot",
        "rowCount": 5,
        "sortOrder": "desc"
    }
    
    # Headers
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    # Request body
    data = {
        "filters": [
            {
                "columnKey": "project",
                "matchMode": "oneOrMoreMatch",
                "matchers": [
                    {
                        "class": "Project",
                        "name": project_name,
                        "type": "nameMatcher"
                    }
                ]
            },
            
            {
                "columnKey": "cid", 
                "matchMode": "oneOrMoreMatch",
                "matchers": [
                    {
                        "id": cid,
                        "type": "idMatcher"
                    }
                ]
            },
        ],
        "columns": ["cid", "firstDetected", "displayType"]
    }
    
    try:
        # Make the POST request
        response = requests.post(
            url,
            params=params,
            headers=headers,
            json=data,
            auth=(username, password),
            timeout=30
        )
        response.raise_for_status()
        
    except requests.exceptions.RequestException as e:
        print(f"Error checking CID {cid} in project {project_name}: {e}")
        return False
    
    try:
        result = response.json()
    except ValueError as e:
        print(f"Error parsing JSON response for CID {cid}: {e}")
        return False

    # Convert the result to a more friendly format
    processed_rows = []
    for row in result.get("rows", []):
        processed_row = {item['key']: item['value'] for item in row}
        processed_rows.append(processed_row)

    return len(processed_rows) != 0


def validate_cids_against_project(server: str, project_name: str, cids: list[int]) -> tuple[list[int], list[int]]:
    """
    Validate a list of CIDs against a project
    
    Args:
        server: Coverity server URL
        project_name: Name of the project to validate against
        cids: List of CIDs to validate
    
    Returns:
        Tuple of (valid_cids, invalid_cids)
    """
    valid_cids = []
    invalid_cids = []
    
    for cid in cids:
        if does_cid_exist_in_project(server, project_name, cid):
            valid_cids.append(cid)
        else:
            invalid_cids.append(cid)
            print(f"CID {cid} does not exist in project '{project_name}'")
    
    return valid_cids, invalid_cids


def get_coverity_server_for_project(project_name: str) -> str:
    """
    Get the appropriate Coverity server URL for a project
    
    Args:
        project_name: Name of the project
    
    Returns:
        Coverity server URL
    """
    # This is a simple mapping - could be enhanced with a configuration file
    # or database lookup for more complex scenarios
    
    # Default server
    default_server = "http://coverity.amd.com"
    
    # Project-specific server mappings
    project_servers = {
        "AGESA FW CLIENT BU_CodingStd": "http://mkcvrty03.amd.com",
        # Add more project-server mappings as needed
    }
    
    return project_servers.get(project_name, default_server)