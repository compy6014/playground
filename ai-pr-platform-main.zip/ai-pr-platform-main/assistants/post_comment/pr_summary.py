import logging
from typing import Any, Dict, Optional
import requests
import base64
import os
import json

#from assistants.ai_assistant import AIAssistant
from assistants.post_comment.post_comment_assistant import PostCommentAssistant
from helpers.utils import extract_pr_info
#from helpers.ai_comment_manager import AICommentManager
from helpers.ai_comment_helper import AICommentHelper
from helpers.utils import get_suggestion_line_numbers
from helpers.utils import get_team_name_by_team

class PRSummaryAssistant(PostCommentAssistant):
    """
    AI Assistant for summarizing pull requests and posting comments on them.
    """
    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        super().__init__(ghe_token, json_in_params, use_dev)
        self.comment_helper = AICommentHelper()
        self.pr_url = self.json_in_params.get('pr_url')
        self.pr_info = extract_pr_info(self.pr_url)
        if "error" not in self.pr_info:
            self.owner = self.pr_info['owner']
            self.repo = self.pr_info['repo']
            self.pr_number = self.pr_info['pr_number']
        else:
            raise ValueError(self.pr_info['error'])

    def summarize_pr(self) -> str:
        """
        Summarizes the pull request using the AI model.
        """
        # Placeholder for actual AI model call
        summary = "This is a summary of the PR."
        return summary
    
    def assistant_type(self) -> str:
        """Return the assistant type name."""
        return 'PRSummary'

    def required_parameters(self) -> list:
        """Return the required parameter names."""
        return ['pr_url', 'llm_token']

    def optional_parameters(self) -> list:
        """Return optional parameters, grouped if necessary."""
        return []

    def pre_processing(self):
        """Perform pre-processing steps before making an API call."""
        self.logger.debug("Starting pre_processing...")

    def generate_api_params(self):
        """
        Generate parameters for PR Summary.

        # Step 1: Retrieve the pull request diff
        which are required for performing PR Summary via the API.
        """
        self.logger.debug("Generating API parameters for PR Summary...")

        #1 Get PR diff
        diff = self.github_helper.get_pr_diff(self.owner, self.repo, self.pr_number)

        #2 Get PR data
        pr_metadata = self.github_helper.get_pr_data(self.owner, self.repo, self.pr_number)

        pr_title = pr_metadata.get('title')
        # If title is either None or an empty string, use a default placeholder.
        if not pr_title:
                pr_title = 'No Title Provided'

        pr_body = pr_metadata.get('body')
        # If body is either None or an empty string, use a default placeholder.
        if not pr_body:
            pr_body = 'No PR body Provided'

        # Get team name
        base_branch = pr_metadata.get('base', {}).get('ref')
        self.team_name = get_team_name_by_team(self.owner, self.repo, branch = base_branch)
        self.logger.debug(f"Team Name: {self.team_name}")

        pr_data = {
            "pr_diff": diff,
            "pr_title": pr_title,
            "pr_body": pr_body,
            "pr_url": self.pr_url,
            "llm_token": self.json_in_params.get("llm_token"),
            "username": self.team_name
        }

        self.json_api_params = pr_data


    def api_call(self, api_url: str, api_token: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make an API call to the specified URL with the provided parameters.
    
        Args:
            api_url (str): The API endpoint URL.
            api_token (str): The API token for authentication.
            params (Dict[str, Any]): The parameters to send in the API request.
    
        Returns:
            Dict[str, Any]: The JSON response from the API.
    
        Raises:
            Exception: If the API call fails.
        """
        self.logger.debug("Calling the PR summary API...")
    
        headers = {
            "Ocp-Apim-Subscription-Key": api_token        
            }
    
        self.logger.debug(f"Calling API with URL: {api_url}, headers: {headers}")
    
        try:
            # Add a timeout to the API call
            resp = requests.post(api_url, json=params, verify=False, headers=headers, timeout=600)
            resp.raise_for_status()
            self.logger.debug(f"API call successful. Response: {resp.json()}")
            return resp.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request to API failed: {e}")
            if e.response is not None:
                try:
                    detail = e.response.json().get('detail', 'No detail present')
                    self.logger.error(f"Full error details: {detail}")
                except ValueError:
                    self.logger.error(f"Full error details (raw text): {e.response.text}")
            else:
                self.logger.error("No response received from the API.")
            raise
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred while calling the API: {e}")
            raise

    def post_processing(self, api_result: Dict[str, Any]):
        """
        Process the API result by extracting the PR summary and generating file expansions.
        """
        self.logger.debug("Starting post_processing...")
    
        # Extract the overall summary, or use a default if not present
        pr_summary = api_result.get("overall_summary", "No overall summary provided.")
    
        # Extract the per_file_summary dict, or use an empty dict if not present
        per_file_summary = api_result.get("per_file_summary", {})
        if not per_file_summary:
            self.logger.warning("No file summaries found in the API result.")
            return
    
        # Determine the total number of files
        file_count = len(per_file_summary)
        self.logger.debug(f"Total number of files to summarize: {file_count}")
    
        file_expansions_list = []
        for file_name, statements in per_file_summary.items():
            # Convert each statement into a bullet point
            bullet_points_str = "\n".join(f"* {statement}" for statement in statements)
            header = f"**File:** `{file_name}`"
    
            # Common kwargs for the prepare_suggestion_comment
            expansion_kwargs = {
                "subheader": header,
                "expansion_summary": "Click here to expand the file summary:",
            }
    
            # If total file count is 10 or less, use 'text'; otherwise, use 'explanation_text_2'
            if file_count <= 10:
                expansion_kwargs["text"] = bullet_points_str
            else:
                expansion_kwargs["explanation_text_2"] = bullet_points_str
    
            # Create the per-file expansion
            file_expansion = self.comment_helper.prepare_suggestion_comment(**expansion_kwargs)
            file_expansions_list.append(file_expansion)
    
        # Combine all file expansions into a single top-level expansion
        all_files_expansion = self.comment_helper.prepare_suggestion_comment(
            explanation_text_2="\n\n".join(file_expansions_list),
            expansion_summary="Click to expand summary for all changed files",
        )
    
        self.create_and_post_conversation_comment(
            owner=self.owner,
            repo=self.repo,
            pr_number=self.pr_number,
            header="AI PR Summary",
            description=pr_summary,
            expansions=all_files_expansion,
            disclaimer_text=(
            "Note: This comment was generated by an AI assistant. "
            "\nFor questions or feedback, please react with a '👍' or '👎,' "
            "or contact dl.ai_code_review for assistance."
            ),
        )
        