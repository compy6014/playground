import logging
from typing import Any, Dict, Optional
import requests
import base64
import os
import json

from assistants.post_comment.post_comment_assistant import PostCommentAssistant
from helpers.utils import extract_pr_info
from helpers.ai_comment_helper import AICommentHelper
from helpers.utils import get_team_name

class CodeEvaluationAssistant(PostCommentAssistant):
    """
    AI Assistant for evaluating code in pull requests and posting comments on them.
    """
    CONFLUENCE_LINK = "https://amd.atlassian.net/wiki/x/pxVvPg"

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        super().__init__(ghe_token, json_in_params, use_dev)
        self.comment_helper = AICommentHelper()
        self.pr_url = self.json_in_params.get('pr_url')
        self.pr_info = extract_pr_info(self.pr_url)
        if "error" not in self.pr_info:
            self.owner = self.pr_info['owner']
            self.repo = self.pr_info['repo']
            self.pr_number = self.pr_info['pr_number']
        else:
            raise ValueError(self.pr_info['error'])

    def assistant_type(self) -> str:
        """Return the assistant type name."""
        return 'CodeEvaluation'

    def required_parameters(self) -> list:
        """Return the required parameter names."""
        return ['pr_url', 'email_contact']

    def optional_parameters(self) -> list:
        """Return optional parameters, grouped if necessary."""
        return []

    def pre_processing(self):
        """Perform pre-processing steps before making an API call."""
        self.logger.debug("Starting pre_processing...")

    def generate_api_params(self):
        """
        Generate parameters for Code Evaluation.
        """
        self.logger.debug("Generating API parameters for Code Evaluation...")

        # Get required parameters
        pr_url = self.json_in_params.get('pr_url')
        email_contact = self.json_in_params.get('email_contact')

        # Get optional parameters with defaults
        enable_cppcheck = self.json_in_params.get('enable_cppcheck', True)
        enable_score = self.json_in_params.get('enable_score', True)
        enable_component_build = self.json_in_params.get('enable_component_build', True)

        api_params = {
            "pr_path": pr_url,
            "email_contact": email_contact,
            "enable_cppcheck": enable_cppcheck,
            "enable_score": enable_score,
            "enable_component_build": enable_component_build
        }

        self.json_api_params = api_params

    def api_call(self, api_url: str, api_token: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make an API call to the specified URL with the provided parameters.
        This API requires an x-api-key header and uses query parameters.

        Args:
            api_url (str): The API endpoint URL.
            api_token (str): The API token for x-api-key header authentication.
            params (Dict[str, Any]): The parameters to send as query parameters.

        Returns:
            Dict[str, Any]: The JSON response from the API.

        Raises:
            Exception: If the API call fails.
        """
        self.logger.debug("Calling the Code Evaluation API...")

        headers = {
            "accept": "application/json",
            "x-api-key": api_token
        }

        self.logger.debug(f"Calling API with URL: {api_url}, headers: {headers}, params: {params}")

        try:
            # Send parameters as query parameters (matching curl command format)
            resp = requests.post(api_url, params=params, headers=headers, verify=False, timeout=600)
            resp.raise_for_status()
            self.logger.debug(f"API call successful. Response: {resp.json()}")
            return resp.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request to API failed: {e}")
            if e.response is not None:
                try:
                    detail = e.response.json().get('detail', 'No detail present')
                    self.logger.error(f"Full error details: {detail}")
                except ValueError:
                    self.logger.error(f"Full error details (raw text): {e.response.text}")
            else:
                self.logger.error("No response received from the API.")
            raise
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred while calling the API: {e}")
            raise

    def post_processing(self, api_result: Dict[str, Any]):
        """
        Process the API result by extracting code evaluation results and formatting the comment.
        """
        self.logger.debug("Starting post_processing...")

        # The API returns a list with one object
        if not api_result or not isinstance(api_result, list) or len(api_result) == 0:
            self.logger.error("Invalid API response format")
            return

        result_data = api_result[0]

        # Extract files_checks and component_build_output
        files_checks = result_data.get("files_checks", {})
        component_build_output = result_data.get("component_build_output", {})

        if not files_checks:
            self.logger.warning("No file checks found in the API result.")
            return

        # Process the evaluation results
        syntax_errors = []
        llm_results = []
        llm_reasons = []

        for file_path, file_data in files_checks.items():
            cpp_check = file_data.get("cpp_check_output", "Unknown")
            llm_judge_result = file_data.get("LLM_judge_result", "Unknown")
            llm_judge_reason = file_data.get("LLM_judge_reason", "No reason provided")

            syntax_errors.append(cpp_check)
            llm_results.append(llm_judge_result)
            llm_reasons.append(llm_judge_reason)

        # Format the results
        syntax_result = syntax_errors[0] if syntax_errors else "No syntax check performed"

        # Use LLM result directly from API response
        llm_score = llm_results[0] if llm_results else "Unknown"

        # Format component build status
        build_message = component_build_output.get("message", "Component build status unknown")
        job_id = component_build_output.get("job_id")
        job_url = component_build_output.get("job_url")

        if job_id and job_url:
            component_build_status = f"Job with [ID {job_id}]({job_url}/{job_id}) started"
        else:
            component_build_status = "disabled"

        # Create the comment description
        description = (
            "After reviewing the pull request (PR) and corresponding changed files, "
            "the AI has generated evaluation result, and triggered build and test run based on the need.\n\n"
            "These are the evaluation result, please wait until the full build and test run finish.\n\n"
            f"- **Syntax Error:** {syntax_result}\n\n"
            f"- **LLM Judge:** {llm_score}\n\n"
            f"- **Component Build:** {component_build_status}\n\n"
            "Following is the AI generated reason for the judging result:\n\n"
            f"```{llm_reasons[0] if llm_reasons else 'No reasoning provided'}```\n\n"
            f"For more details about each individual evaluation, please visit this [Confluence page]({self.CONFLUENCE_LINK})."
        )

        # Post the comment
        self.create_and_post_conversation_comment(
            owner=self.owner,
            repo=self.repo,
            pr_number=self.pr_number,
            header="AI Code Evaluation",
            description=description,
            disclaimer_text=(
                "This comment was generated by an AI assistant. "
                "For questions or feedback, please react with a '👍' or '👎,' "
                "or contact dl.ai_code_review for assistance."
            ),
        )