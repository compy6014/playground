import logging
from typing import Any, Dict, Optional
import requests
import os
import re
import json
import pathlib
from requests.exceptions import HTTPError

from assistants.post_comment.post_comment_assistant import PostCommentAssistant
from helpers.utils import (
    extract_pr_info, 
    decode_comment_id, 
    count_coverity_fix_lines, 
    count_coverity_source_code_lines, 
    remove_line_numbers_from_suggestion,
    get_json_files_from_paths
)
from helpers.ai_comment_helper import AICommentHelper

class CoverityAssistant(PostCommentAssistant):
    """
    An AI Assistant that posts Coverity fix suggestions for pull requests.
    """

    # Class-level constants
    DISCLAIMER_SUFFIX = ("For questions or feedback, please react with a '👍' or '👎,' "
                        "or contact dl.ai_code_review for assistance.")

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        """
        Initialize the CoverityAssistant with GitHub Enterprise token and input parameters.

        Args:
            ghe_token (str): GitHub Enterprise token for authentication.
            json_in_params (Optional[Dict[str, Any]]): Input parameters as a JSON dictionary.
            use_dev (bool): Whether to use development environment.
        """
        super().__init__(ghe_token, json_in_params, use_dev)
        self.comment_helper = AICommentHelper()
        
        # Initialize attributes from json_in_params
        self.pr_url = self.json_in_params.get('pr_url')
        self.coverity_json = self.json_in_params.get('coverity_json')
        self.coverity_json_dir = self.json_in_params.get('coverity_json_dir')
        self.remove_previous_comments = self.json_in_params.get('remove_previous_comments', True)
        self.include_explanation = self.json_in_params.get('include_explanation', True)
        self.kernel_mode = self.json_in_params.get('kernel_mode', False)
        self.post_comment = self.json_in_params.get('post_comment', True)
        self.post_conversation_comment = self.json_in_params.get('post_conversation_comment', False)
        
        # Determine github_instance based on host or use default
        self.github_instance = self.json_in_params.get('github_instance', 'EMU')
        if self.pr_url:
            pr_data = extract_pr_info(self.pr_url)
            if "error" not in pr_data:
                host = pr_data.get("host", "")
                if host and "github.amd.com" in host:
                    self.github_instance = "on-prem"
                else:
                    self.github_instance = "EMU"

    def assistant_type(self) -> str:
        """Return the assistant type name."""
        return 'CoverityFix'

    def required_parameters(self) -> list:
        """Return the required parameter names."""
        return ['pr_url']

    def optional_parameters(self) -> list:
        """Return optional parameters, grouped if necessary."""
        return [('coverity_json_dir', 'coverity_json')]

    def pre_processing(self):
        """
        Perform pre-processing steps before making an API call.

        This includes:
            - Extracting the owner, repository, and PR number from the PR URL.
            - Getting the latest commit SHA for the PR.
            - Loading JSON files and removing previous comments if needed.

        Raises:
            ValueError: If the PR URL does not match the expected pattern.
        """
        self.logger.debug("Starting pre_processing...")

        pr_data = extract_pr_info(self.pr_url)
        if "error" not in pr_data:
            self.owner = pr_data["owner"]
            self.repo = pr_data["repo"]
            self.pr_number = pr_data["pr_number"]
            self.logger.debug(f"Owner: {self.owner}, Repo: {self.repo}, PR Number: {self.pr_number}")
        else:
            raise ValueError(pr_data["error"])

        # Get the latest commit SHA for the PR
        pr_metadata = self.github_helper.get_pr_data(self.owner, self.repo, self.pr_number)
        if pr_metadata:
            self.latest_sha = pr_metadata.get('head', {}).get('sha')
            self.logger.debug(f"Latest commit SHA: {self.latest_sha}")
        else:
            raise ValueError("Failed to get PR metadata")

        # Remove previous comments if requested (will be done in generate_api_params after getting the file)
        if self.remove_previous_comments:
            self.logger.debug("Previous comment removal will be handled after file selection")

    def generate_api_params(self):
        """Generate parameters for the API call."""
        self.logger.debug("Generating API parameters for Coverity fix suggestions...")
        
        # Get the JSON file to process
        json_files = self.get_json_files()
        if not json_files:
            self.logger.error('No Coverity JSON file or directory specified.')
            self.json_api_params = []
            return
        
        # Use the first JSON file (we only process one file at a time)
        json_file_path = json_files[0]
        self.logger.debug(f"Using JSON file: {json_file_path}")
        
        # Store the JSON file path for use in api_call
        self.json_file_path = json_file_path
        self.json_api_params = [json_file_path]
        
        # Remove previous comments if requested
        if self.remove_previous_comments:
            self.remove_old_comments(json_file_path)
        
        self.logger.debug("API parameters generated for Coverity fix processing")

    def api_call(self, api_url: str, api_token: str, params: Dict[str, Any]) -> list[Dict[str, Any]]:
        """
        Call the Coverity Fix API using the provided API URL from config.

        Args:
            api_url (str): The URL of the API endpoint from config.
            api_token (str): The API authentication token.
            params (Dict[str, Any]): Additional parameters (not used).

        Returns:
            list[Dict[str, Any]]: List containing the API response.

        Raises:
            RuntimeError: If the API call fails.
            
        Note:
            The API call includes the following parameters:
            - pr_link: The pull request URL
            - include_explanation: Whether to include explanations
            - kernel_mode: Whether to use kernel mode
            - github_instance: The GitHub instance type ('EMU' or 'on-prem')
        """
        self.logger.debug("Calling the Coverity fix suggestion generator...")

        if not hasattr(self, 'json_file_path'):
            raise RuntimeError("No JSON file path available. Run generate_api_params first.")

        json_file_path = self.json_file_path
        self.logger.debug(f"Processing file: {json_file_path}")
        self.logger.debug(f"Using GitHub instance: {self.github_instance}")
        
        # Use the API URL from config and determine headers based on environment
        if self.use_dev_api:
            headers = {"x-api-key": api_token}
        else:
            headers = {"Ocp-Apim-Subscription-Key": api_token}
        
        api_params = {
            "pr_link": self.pr_url, 
            "include_explanation": self.include_explanation, 
            "kernel_mode": self.kernel_mode,
            "github_instance": self.github_instance
        }
        
        try:
            with open(json_file_path, 'rb') as json_file:
                resp = requests.post(
                    url=api_url,
                    files={"json_file": json_file},
                    params=api_params,
                    verify=False,
                    headers=headers
                )
                resp.raise_for_status()
                result = resp.json()
                self.logger.debug(f"Successfully processed file: {json_file_path}")
                return result
        except HTTPError as e:
            self.logger.error(f"HTTP error for file '{json_file_path}': {e}")
            if e.response is not None:
                self.logger.error(f"Response status: {e.response.status_code}, Response text: {e.response.text}")
            raise RuntimeError(f"API call failed for file '{json_file_path}': {e}")
        except Exception as e:
            self.logger.error(f"API call failed for file '{json_file_path}': {e}")
            raise RuntimeError(f"API call failed for file '{json_file_path}': {e}")

    def extract_file_diff_hunk(self, pr_diff: str, filename: str) -> str:
        """
        Extract the diff hunk for a specific file from the full PR diff.
        
        Args:
            pr_diff (str): The full PR diff containing multiple files
            filename (str): The specific file to extract diff for
            
        Returns:
            str: The diff hunk for the specific file, or empty string if not found
        """
        lines = pr_diff.split('\n')
        file_started = False
        file_hunk = []
        
        for line in lines:
            # Check if we're starting a new file
            if line.startswith('diff --git'):
                if file_started:
                    # We were processing a file and now hit a new one, stop
                    break
                # Check if this is our target file
                if filename in line:
                    file_started = True
                    continue
            elif line.startswith('+++') and file_started:
                # Skip the +++ line but check if filename matches
                if filename in line:
                    continue
            elif line.startswith('---') and file_started:
                # Skip the --- line
                continue
            elif line.startswith('@@') and file_started:
                # Start of a hunk for our file
                file_hunk.append(line)
            elif file_started and (line.startswith('+') or line.startswith('-') or line.startswith(' ') or not line.strip()):
                # Content lines of the hunk
                file_hunk.append(line)
            elif file_started and line.startswith('diff --git'):
                # Hit another file, stop processing
                break
                
        return '\n'.join(file_hunk) if file_hunk else ''

    def extract_clean_code_from_suggestion(self, suggestion_text: str) -> str:
        """
        Extract clean code from API suggestion text, removing ```suggestion wrapper and line numbers.
        
        Args:
            suggestion_text (str): The suggestion text from API (may contain ```suggestion blocks)
            
        Returns:
            str: Clean code without suggestion wrapper or line numbers
        """
        # First, try to extract code from ```suggestion blocks
        pattern = r'```suggestion\n(.*?)\n```'
        match = re.search(pattern, suggestion_text, re.DOTALL)
        
        if match:
            # Extract code from within suggestion block
            code_block = match.group(1)
        else:
            # If no suggestion block found, use the entire text
            code_block = suggestion_text
        
        # Remove line numbers from each line
        lines = code_block.split('\n')
        cleaned_lines = [re.sub(r'^\s*\d+\s*', '', line) for line in lines]
        return '\n'.join(cleaned_lines)

    def post_processing(self, api_result: list[Dict[str, Any]]):
        """
        Post Coverity review and conversation comments based on API results.
        """
        self.logger.debug("Starting post_processing...")

        if not api_result:
            self.logger.warning("API result is empty. No violations to process.")
            return

        review_comment_list = []
        conversation_issues_by_file = {}
        processed_issues = set()  # Track processed issues to avoid duplicates

        # Get PR diff hunk for diff scope checking
        pr_diff = self.github_helper.get_pr_diff(self.owner, self.repo, self.pr_number)

        for issue in api_result:
            filename = issue.get('File Path')
            main_event_line_number = issue.get('Main Event Line Number')
            source_code = issue.get('Original Source Code')
            ai_generated_fix = issue.get('AI Generated Fix', '')
            aicg_request_id = issue.get('aicg_request_id', '')
            
            # Create unique identifier to avoid duplicates
            issue_key = f"{filename}:{main_event_line_number}:{aicg_request_id}"
            if issue_key in processed_issues:
                self.logger.debug(f"Skipping duplicate issue: {issue_key}")
                continue
            processed_issues.add(issue_key)
            
            explanation = ""
            # Extract explanation if present in the AI Generated Fix
            if "Explanation:" in ai_generated_fix:
                parts = ai_generated_fix.split("Explanation:", 1)
                ai_generated_fix = parts[0].strip()
                explanation = parts[1].strip()
            else:
                explanation = ""

            # Convert line number to int, fallback to 1 if invalid
            try:
                line_number = int(main_event_line_number) if main_event_line_number else 1
            except (ValueError, TypeError):
                line_number = 1

            # Only post review comment if we have a suggestion and a valid line
            if ai_generated_fix.strip():
                # Extract clean code without suggestion wrapper or line numbers
                clean_code = self.extract_clean_code_from_suggestion(ai_generated_fix)
                
                # For Coverity, use Main Event Line Number for diff scope checking
                # The suggestion line range is only used for GitHub comment line parameters
                from helpers.utils import get_suggestion_line_numbers
                suggestion_line_range = get_suggestion_line_numbers(ai_generated_fix)
                
                if suggestion_line_range:
                    suggestion_start_line, suggestion_end_line = suggestion_line_range
                else:
                    # Fallback to single line suggestion
                    suggestion_start_line = suggestion_end_line = line_number

                # For diff scope checking, use the Main Event Line Number (the specific line with the issue)
                issue_line_start = issue_line_end = line_number

                # Prepare the review comment body (NO original source code for review comments)
                comment_body = self.comment_helper.prepare_suggestion_comment(
                    subheader=f"**Coverity Fix Suggestion**",
                    explanation_text_1=explanation,
                    code_suggestion=clean_code,
                    commitable_suggestion=True
                )

                # Check if the ISSUE LINE belongs to the diff scope (not the entire suggestion)
                in_diff_scope = False
                if hasattr(self.github_helper, 'is_line_range_in_added_lines'):
                    # Extract the specific file's diff hunk from the PR diff
                    file_diff_hunk = self.extract_file_diff_hunk(pr_diff, filename)
                    if file_diff_hunk:
                        # Check if the Main Event Line Number is in diff scope
                        in_diff_scope = self.github_helper.is_line_range_in_added_lines(file_diff_hunk, (issue_line_start, issue_line_end))
                        self.logger.debug(f"Issue line {line_number} in file {filename} is in diff scope: {in_diff_scope}")
                    else:
                        self.logger.debug(f"No diff hunk found for file {filename}, assuming not in scope")
                        in_diff_scope = False
                else:
                    in_diff_scope = True
                    self.logger.debug(f"is_line_range_in_added_lines method not available, assuming in scope: {in_diff_scope}")

                if in_diff_scope:
                    # Use suggestion line range for GitHub comment positioning (entire suggestion block)
                    review_comment = self.comment_helper.prepare_review_comment_data(
                        path=filename,
                        side="RIGHT",
                        body=comment_body,
                        line=suggestion_end_line,
                        start_line=suggestion_start_line if suggestion_start_line < suggestion_end_line else None
                    )
                    self.logger.debug(f"Posting review comment for issue line {line_number}, suggestion lines {suggestion_start_line}-{suggestion_end_line}: {review_comment}")
                    review_comment_list.append(review_comment)
                else:
                    self.logger.debug(f"Issue line {line_number} in file {filename} not in diff scope. Adding to conversation expansions.")
                    if filename not in conversation_issues_by_file:
                        conversation_issues_by_file[filename] = []
                    expansion = self.comment_helper.create_expansion(
                        summary=f"Line {main_event_line_number}",
                        header=f"**Line {main_event_line_number}**",
                        text=explanation,
                        original_source_code={"language": "python", "code": source_code} if source_code and source_code != "Could not extract original code" and source_code != "Could not retrieve original source code" else None,
                        code_suggestion={"language": "python", "code": clean_code} if clean_code else None
                    )
                    conversation_issues_by_file[filename].append(expansion)
            else:
                self.logger.debug(f"No AI-generated fix for file {filename}, line {main_event_line_number}. Adding to conversation expansions.")
                if filename not in conversation_issues_by_file:
                    conversation_issues_by_file[filename] = []
                expansion = self.comment_helper.create_expansion(
                    summary=f"Line {main_event_line_number}",
                    header=f"**Line {main_event_line_number}**",
                    text=explanation if explanation else "No AI-generated fix or explanation available.",
                    original_source_code={"language": "python", "code": source_code} if source_code and source_code != "Could not extract original code" and source_code != "Could not retrieve original source code" else None
                )
                conversation_issues_by_file[filename].append(expansion)

        # Post review comments (inline suggestions)
        if review_comment_list:
            disclaimer_text = self.get_disclaimer_text()
            self.logger.debug(f"Posting {len(review_comment_list)} review comments.")
            self.create_and_post_pr_review(
                self.owner,
                self.repo,
                self.pr_number,
                self.latest_sha,
                header="AI Coverity Fix",
                text="AI Coverity tool has identified issues and provided fix suggestions. Please review the following suggestions.",
                disclaimer_text=disclaimer_text,
                comments=review_comment_list
            )
        else:
            self.logger.debug("No review comments to post.")

        # Post conversation comment (summary of issues without suggestions or out-of-scope suggestions)
        if conversation_issues_by_file:
            disclaimer_text = self.get_disclaimer_text()
            self.logger.debug(f"Posting conversation comments for {len(conversation_issues_by_file)} files.")
            
            # Create expansions using the helper functions
            expansions = []
            for filename, file_issues in conversation_issues_by_file.items():
                # Create nested expansions for each issue in this file
                nested_expansions = []
                for issue in file_issues:
                    line_number = issue.get('header', '**Line Unknown**').replace('**Line ', '').replace('**', '').strip()
                    issue_text = issue.get('text', 'No AI-generated fix or explanation available.')
                    original_code = issue.get('original_source_code')
                    suggested_code = issue.get('code_suggestion')
                    
                    # Create expansion for this specific issue
                    issue_expansion = self.comment_helper.create_expansion(
                        summary=f"Line {line_number}",
                        header=f"**Line {line_number}**",
                        text=issue_text,
                        original_source_code=original_code,
                        code_suggestion=suggested_code
                    )
                    nested_expansions.append(issue_expansion)
                
                # Create file-level expansion containing all issues for this file
                file_expansion = self.comment_helper.create_expansion(
                    summary=f"File: {filename}",
                    header=f"**File:** `{filename}`",
                    nested_expansions=nested_expansions
                )
                expansions.append(file_expansion)
            
            # Create the conversation comment using the helper
            conversation_body = self.comment_helper.create_conversation_comment(
                header="AI Coverity Fix",
                description="Some Coverity issues could not be auto-fixed or are outside the diff scope. Please review the details below.",
                expansions=expansions,
                disclaimer_text=disclaimer_text
            )
            
            self.create_and_post_conversation_comment(
                owner=self.owner,
                repo=self.repo,
                pr_number=self.pr_number,
                header=None,
                description=None,
                expansions=conversation_body,  # Pass as string, not list
                disclaimer_text=None
            )
        else:
            self.logger.debug("No conversation comments to post.")

        return super().post_processing()

    def get_disclaimer_text(self) -> str:
        """
        Returns the full disclaimer text for review and conversation comments.
        """
        return "Please provide feedback via like :+1: or dislike :-1: and [email us](mailto:dl.ai_code_review@amd.com)"

    def get_json_files(self) -> list[str]:
        """
        Get list of JSON files from the specified directory or single file.
        Uses the utility function from helpers.utils.

        Returns:
            List of JSON file paths to process.
        """
        return get_json_files_from_paths(
            coverity_json=self.coverity_json,
            coverity_json_dir=self.coverity_json_dir,
            logger=self.logger
        )

    def remove_old_comments(self, json_file_path: str) -> None:
        """
        Remove previous Coverity comments for the same file.

        Args:
            json_file_path: Path to the JSON file containing Coverity issues.
        """
        review_threads = self.github_helper.get_pr_review_threads(
            self.owner,
            self.repo,
            self.pr_number
        )
        comments = self.github_helper.get_pr_comments(
            self.owner,
            self.repo,
            self.pr_number
        )

        def extract_file_path_and_line_number_from_comment(comment_body: str) -> tuple[Optional[str], Optional[int]]:
            """Extract file path and line number from comment body."""
            line_number_match = re.search(r'Main Event Line Number: (\d+)', comment_body)
            file_path_match = re.search(r'File Path: (.+)', comment_body)
            if line_number_match and file_path_match:
                return file_path_match.group(1), int(line_number_match.group(1))
            return None, None

        def extract_file_path_and_line_number_from_review_thread(review_thread_body: str) -> tuple[Optional[str], Optional[int]]:
            """Extract file path and line number from review thread body."""
            line_number_match = re.search(r'line number (\d+)', review_thread_body)
            file_path_match = re.search(r'file ([\w/\\.-]+) on the line', review_thread_body)
            if line_number_match and file_path_match:
                return file_path_match.group(1), int(line_number_match.group(1))
            return None, None

        filtered_comment_ids = []

        # Process comments
        for comment in comments['data']['repository']['pullRequest']['comments']['nodes']:
            if isinstance(comment, dict) and "body" in comment:
                if "Coverity Fix Suggestion\n" in comment['body'] or "Coverity Fix Chat\n" in comment['body']:
                    file_path, line_number = extract_file_path_and_line_number_from_comment(comment['body'])
                    # Fix logging error by handling None values
                    if file_path is not None and line_number is not None:
                        self.logger.debug('File Path: %s, Line Number: %d', file_path, line_number)
                        filtered_comment_ids.append({
                            'id': decode_comment_id(comment['id']).split("IssueComment")[-1],
                            'url': comment['url'],
                            'file_path': file_path,
                            'line_number': line_number,
                            'body': comment['body']
                        })
                    else:
                        self.logger.debug('File Path or Line Number is None, skipping comment')
            else:
                self.logger.debug("Unexpected comment format: %s", comment)

        # Process review threads
        for thread in review_threads['data']['repository']['pullRequest']['reviewThreads']['nodes']:
            for comment in thread['comments']['nodes']:
                if "Coverity Fix Suggestion\n" in comment['bodyText'] or "Coverity Fix Chat\n" in comment['bodyText']:
                    file_path, line_number = extract_file_path_and_line_number_from_review_thread(comment['bodyText'])
                    # Fix logging error by handling None values
                    if file_path is not None and line_number is not None:
                        self.logger.debug('File Path: %s, Line Number: %d', file_path, line_number)
                        main_comment_id = decode_comment_id(comment['id']).split("PullRequestReviewComment")[-1]
                        reply_urls = []
                        for reply in thread['comments']['nodes']:
                            if reply['id'] != comment['id']:  # Exclude the main comment
                                reply_urls.append(reply['url'])
                        filtered_comment_ids.append({
                            'id': main_comment_id,
                            'url': comment['url'],
                            'file_path': file_path,
                            'line_number': line_number,
                            'reply_comments_urls_list': reply_urls
                        })
                    else:
                        self.logger.debug('File Path or Line Number is None, skipping review thread comment')

        def delete_comments(comment_ids: list) -> None:
            """Helper function to delete comments by their URLs."""
            for comment in comment_ids:
                self.github_helper.delete_comment(comment['url'])
                self.logger.info(f"Deleted main comment: {comment['url']}")
                if 'reply_comments_urls_list' in comment:
                    for reply_url in comment['reply_comments_urls_list']:
                        self.github_helper.delete_comment(reply_url)
                        self.logger.info(f"Deleted reply comment: {reply_url}")
                self.logger.info("Deleted comments for file: %s, line: %d", comment['file_path'], comment['line_number'])

        # Open and extract main line number and file path from Coverity JSON
        try:
            with open(json_file_path, 'r') as file:
                json_data = json.load(file)
                for issue in json_data['issues']:
                    issue_file_path = os.path.normpath(issue['strippedMainEventFilePathname']).replace('\\', '/')
                    issue_line_number = issue['mainEventLineNumber']
                    self.logger.debug('File Path from file: %s, Line Number: %d', issue_file_path, issue_line_number)

                    # Collect comments to delete
                    comments_to_delete = [
                        comment for comment in filtered_comment_ids
                        if issue_file_path == comment['file_path'] and issue_line_number == comment['line_number']
                    ]

                    # Delete old comments
                    delete_comments(comments_to_delete)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            self.logger.error(f"Error reading JSON file {json_file_path}: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error processing JSON file {json_file_path}: {e}")
