import os
from typing import Any, Dict, Optional
from abc import ABC, abstractmethod
import requests

from assistants.ai_assistant import AIAssistant
from helpers.github_helper import GitHubHelper
from helpers.ai_comment_helper import AICommentHelper

class PostCommentAssistant(AIAssistant, ABC):
    """
    An abstract AI Assistant that posts comments on pull requests.
    """

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        super().__init__(ghe_token, json_in_params, use_dev)
        self.comment_helper = AICommentHelper()
        self.pr_url = self.json_in_params.get('pr_url')


    def create_and_post_pr_review(
        self,
        owner: str,
        repo: str,
        pr_number: str,
        commit_id: str,
        header: str = None,
        subheading: str = None,
        text: str = None,
        disclaimer_title: str = None,
        disclaimer_text: str = None,
        comments: list = None,
        event: str = "COMMENT"
    ) -> str:
        """
        Prepares and posts a pull request review.

        :param owner: Repository owner's username.
        :param repo: Repository name.
        :param pr_number: Pull request number.
        :param commit_id: The commit SHA for the review.
        :param header: Optional review header.
        :param subheading: Optional review subheading.
        :param text: Optional body text for the review.
        :param comments: A list of comment dictionaries, each containing path, position, and body.
        :param event: The event type for the review ("COMMENT" by default).
        :return: The URL of the posted review.
        """
        # Collect only supplied arguments (non-None) for the helper
        call_params = {"commit_id": commit_id, "comments": comments, "event": event}
        if header is not None:
            call_params["header"] = header
        if subheading is not None:
            call_params["subheading"] = subheading
        if text is not None:
            call_params["text"] = text
        if disclaimer_title is not None:
            call_params["disclaimer_title"] = disclaimer_title
        if disclaimer_text is not None:
            call_params["disclaimer_text"] = disclaimer_text

        # Step 1: Prepare the review data with only non-None parameters
        review_data = self.comment_helper.prepare_pr_review_data(**call_params)

        # Step 2: Use the prepared data to post the review
        return self.github_helper.create_pull_request_review(owner, repo, pr_number, review_data)
    
    def create_and_post_conversation_comment(
        self,
        owner: str,
        repo: str,
        pr_number: str,
        header: str = None,
        description: str = None,
        subheading: str = None,
        expansions: str = None,
        original_source_code: dict = None,
        code_suggestion: dict = None,
        disclaimer_title: str = "Note",
        disclaimer_text: str = None
    ) -> str:
        """
        Creates a conversation comment using AICommentHelper and then posts
        it to the specified pull request's conversation via GitHub's issue comment API.
    
        Both 'description' and 'expansions' are optional and may be None.
        """
    
        # Build the comment body from description and expansions if present
        body_text = ""
        if description:
            body_text = description
        
        if expansions:
            # Add a blank line if 'body_text' already has content
            if body_text:
                body_text += "\n\n"
            body_text += expansions
    
        # Create the comment body
        comment_body = self.comment_helper.create_markdown_comment(
            header=header,
            body=body_text,
            disclaimer_title=disclaimer_title,
            disclaimer_text=disclaimer_text
        )
    
        # Post it as an issue (conversation) comment on GitHub
        return self.github_helper.post_issue_comment(owner, repo, pr_number, comment_body)