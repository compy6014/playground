# File: assistants/post_comment/human_review_fix.py

import logging
import sys
import os
from typing import Any, Dict, Optional, List
import requests

from assistants.ai_assistant import AIAssistant
from helpers.utils import extract_pr_info
from helpers.utils import get_suggestion_line_numbers
from helpers.utils import get_team_name_by_team

class AIReviewCommentFixAssistant(AIAssistant):
    """
    An AI Assistant that processes human review comments on pull requests and suggests fixes.
    """

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        """
        Initialize the AIReviewCommentFixAssistant with GitHub Enterprise token and input parameters.

        Args:
            ghe_token (str): GitHub Enterprise token for authentication.
            json_in_params (Optional[Dict[str, Any]]): Input parameters as a JSON dictionary.
        """
        super().__init__(ghe_token, json_in_params, use_dev)
        # Initialize attributes from json_in_params
        params = self.json_in_params
        self.pr_url = params.get('pr_url')
        self.comment_id = params.get('comment_id')
        self.post_comments = params.get('post_comments', 1)
        # self.debug = params.get('debug', 1)
        self.llm_token = params.get('llm_token')
        self.log_to_db = params.get('log_to_db', 0)
        self.post_test_comment = params.get('post_test_comment', 0)
        self.include_explanation = params.get('include_explanation', 1)

    def assistant_type(self) -> str:
        """
        Get the assistant type name used for configuration lookup.

        Returns:
            str: The assistant type name.
        """
        return 'AIReviewCommentFix'

    def required_parameters(self) -> list:
        """
        Get the list of required parameter names.

        Returns:
            list: A list of strings representing the names of required parameters.
        """
        return ['pr_url', 'comment_id']

    def optional_parameters(self) -> list:
        """
        Get the list of optional parameter groups where at least one must be provided.

        Returns:
            list: A list of optional parameter group names.
        """
        return []

    def pre_processing(self):
        """
        Perform pre-processing steps before making the API call.

        This includes:
            - Extracting the owner, repository, and PR number from the PR URL.
            - Fetching the pull request review comment data.
            - Extracting and storing relevant details from the review comment.

        Raises:
            ValueError: If the PR URL does not match the expected pattern or if the review comment cannot be fetched.
        """
        self.logger.debug("Starting pre_processing...")

        pr_data = extract_pr_info(self.pr_url)
        if "error" not in pr_data:
            self.owner = pr_data["owner"]
            self.repo = pr_data["repo"]
            self.pr_number = pr_data["pr_number"]
            self.logger.debug(f"Owner: {self.owner}, Repo: {self.repo}, PR Number: {self.pr_number}")
        else:
            raise ValueError(pr_data["error"])

        # Fetch PR data
        pr_data = self.github_helper.get_pr_data(self.owner, self.repo, self.pr_number)
        if pr_data:
            self.base_branch = pr_data.get('base', {}).get('ref')

        # Fetch pull request review comment
        review_comment_data = self.github_helper.get_pr_review_comment(
            self.owner, self.repo, self.pr_number, self.comment_id
        )
        if review_comment_data:
            self.review_comment = self.extract_review_comment_details(review_comment_data)
            #self.logger.debug(f"Extracted review comment details: {self.review_comment}")

            # Get the comment author and check if the comment author is in the exclude list
            comment_author = review_comment_data.get('user', {}).get('login')
            if comment_author:
                self._check_author_exclusion(comment_author)
            else:
                self.logger.warning("Comment author not found.")
        else:
            self.logger.error(f"Failed to fetch review comment with ID {self.comment_id}.")
            raise ValueError(f"Failed to fetch review comment with ID {self.comment_id}.")

    def extract_review_comment_details(self, comment: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract relevant details from the triggered comment.

        Args:
            comment (Dict[str, Any]): The comment data as retrieved from the GitHub API.

        Returns:
            Dict[str, Any]: A dictionary containing extracted comment details, including:
                - comment_url (str): URL of the comment.
                - body (str): The body content of the comment.
                - file_path (str): The file path of the commented file.
                - position (List[int]): The start and end lines of the comment.
                - commit_id (str): The commit SHA the comment is associated with.
                - comment_id (str): The ID of the comment.
                - diff_hunk (str): The diff hunk where the comment is located.
        """
        self.logger.debug("Extracting details from triggered comment.")
        original_start_line = comment.get('original_start_line')
        original_line = comment.get('original_line')
        if original_start_line is None:
            position = [original_line, original_line]
        else:
            position = [original_start_line, original_line]
        comment_details = {
            'comment_url': comment.get('url'),
            'body': comment.get('body'),
            'file_path': comment.get('path'),
            'position': position,
            'commit_id': comment.get('original_commit_id'),
            'comment_id': comment.get('id'),
            'diff_hunk': comment.get('diff_hunk')
        }
        return comment_details

    def generate_api_params(self):
        """
        Generate parameters for the API call based on input parameters.

        This includes:
            - Retrieving the full file content at the specified commit.
            - Preparing and storing the parameters required for the API call.

        Raises:
            ValueError: If the API parameters cannot be generated.
        """
        self.logger.debug("Starting generate_api_params.")
        self.json_api_params = []

        # Get the full file content at the specific commit
        file_content = self.github_helper.get_file_content(
            self.owner, self.repo, self.review_comment['commit_id'], self.review_comment['file_path']
        )
        self.logger.debug(
            f"Retrieved content for file '{self.review_comment['file_path']}' "
            f"at commit '{self.review_comment['commit_id']}'."
        )

        self.username = get_team_name_by_team(self.owner, self.repo, branch=self.base_branch)
        self.logger.debug(f"Retrieved team name: {self.username}")

        # Prepare parameters for the API call
        api_params = {
            "file_diff": self.review_comment['diff_hunk'],
            "full_file": file_content,
            "review_comment": self.review_comment['body'],
            "line_number": self.review_comment['position'],
            "llm_token": f"{self.llm_token}",
            "commented_file": self.review_comment['file_path'],
            "comment_id": f"{self.review_comment['comment_id']}",
            "pr_url": self.pr_url,
            "include_explanation": self.include_explanation,
            "username": self.username,
            "repo_name": f"{self.owner}/{self.repo}",
            "pr_url": self.pr_url
        }
        #self.logger.debug(f"Generated API parameters: {api_params}")
        self.json_api_params = api_params

        if not self.json_api_params:
            self.logger.error("No API parameters generated.")
            raise ValueError("Failed to generate API parameters.")

    def api_call(self, api_url: str, api_token: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform the API call and return the result.

        Args:
            api_url (str): The URL of the API endpoint.
            api_token (str): The API authentication token.
            params (Dict[str, Any]): The parameters to be sent in the API request.

        Returns:
            Dict[str, Any]: The JSON response from the API as a dictionary.

        Raises:
            requests.exceptions.RequestException: If the API call fails.
            Exception: For any other unexpected error.
        """
        headers = {
            "Ocp-Apim-Subscription-Key": api_token
        }
        self.logger.debug(f"Calling API with URL: {api_url}")

        try:
            resp = requests.post(api_url, json=params, verify=False, headers=headers)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request to API failed: {e}")
            if e.response is not None:
                try:
                    detail = e.response.json().get('detail', 'No detail present')
                    self.logger.error(f"Full error details: {detail}")
                except ValueError:
                    self.logger.error(f"Full error details (raw text): {e.response.text}")
            raise
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred while calling the API: {e}")
            raise

    def post_processing(self, api_result: Dict[str, Any]):
        """
        Perform post-processing steps after receiving the API result.

        This includes:
            - Preparing the reply comment data based on the API result.
            - Posting comments to GitHub according to the API result.

        Args:
            api_result (Dict[str, Any]): The result returned from the API call.

        Raises:
            ValueError: If no api_result is provided or if required data is missing from the api_result.
            Exception: If an error occurs during posting comments.
        """
        self.logger.debug("Starting post_processing.")

        if not api_result:
            self.logger.error("No api_result received from API.")
            raise ValueError("No api_result received from API.")

        label = api_result.get('label')
        if label == 'ACTIONABLE':
            try:
                self.reply_comment_data = self.prepare_reply_comment_data(api_result)
                # Extract lines where to post the comment
                lines_to_post = get_suggestion_line_numbers(api_result.get('replacement', ''))
                if not lines_to_post:
                    self.logger.error("Failed to extract line numbers from the suggestion.")
                    raise ValueError("Invalid code suggestion format.")

                # Get positions and diff hunk safely
                comment_position = self.review_comment.get('position', [])
                diff_hunk = self.review_comment.get('diff_hunk', '')

                self.logger.debug(f"DEBUG: lines to post: {lines_to_post}")
                if self.comment_manager.is_within_scope(lines_to_post, comment_position):
                    self.logger.debug("Posting reply comment within scope.")
                    response = self.github_helper.post_reply_comment(
                        self.owner,
                        self.repo,
                        self.pr_number,
                        self.comment_id,
                        self.reply_comment_data['review_suggestion_comment']
                    )
                    self.logger.debug(f"Posted reply comment: {response}")
                elif self.github_helper.is_line_range_in_added_lines(diff_hunk, lines_to_post):
                    self.logger.debug("Posting review comment on diff.")
                    response = self.github_helper.post_pr_review_comment(
                        self.owner,
                        self.repo,
                        self.pr_number,
                        self.reply_comment_data['position_review_comment']
                    )
                    self.logger.debug(f"Posted review comment: {response}")

                    additional_message = (
                        f"**NOTE:** The AI review fix suggestion has been posted as a separate comment because it is outside "
                        f"the original review comment scope. Please refer to the [posted comment]({response}) "
                        f"for the suggested change and explanation."
                    )
                    comment_body = self.reply_comment_data['general_suggestion_comment'] + "\n\n" + additional_message

                    response = self.github_helper.post_reply_comment(
                        self.owner,
                        self.repo,
                        self.pr_number,
                        self.comment_id,
                        comment_body
                    )
                    self.logger.debug(f"Posted general reply comment: {response}")
                else:
                    self.logger.debug("Posting general suggestion comment.")
                    response = self.github_helper.post_reply_comment(
                        self.owner,
                        self.repo,
                        self.pr_number,
                        self.comment_id,
                        self.reply_comment_data['general_suggestion_comment']
                    )
                    self.logger.debug(f"Posted general suggestion comment: {response}")
            except Exception as e:
                self.logger.exception(f"An error occurred during post-processing: {e}")
                raise
        else:
            self.logger.warning(f"Received non-actionable label: {label}")

    def prepare_reply_comment_data(self, api_result: Dict[str, Any]) -> Dict[str, str]:
        """
        Prepare the reply comment data based on the API result.

        Args:
            api_result (Dict[str, Any]): The result returned from the API call.

        Returns:
            Dict[str, str]: A dictionary containing prepared comment data with keys:
                - 'review_suggestion_comment'
                - 'general_suggestion_comment'
                - 'position_review_comment'

        Raises:
            ValueError: If required data is missing from the api_result.
        """
        self.logger.debug("Preparing reply comment data.")
        # Prepare the comment data
        header = "AI Review Comment Fix"
        try:
            code_suggestion = api_result['code_suggestion']
            explanation = api_result['explanation']
            replacement = api_result['replacement']
        except KeyError as e:
            self.logger.error(f"Missing key in api_result: {e}")
            raise ValueError(f"Missing key in api_result: {e}")

        review_suggestion_comment = self.comment_manager.prepare_suggestion_comment(
            header, code_suggestion, explanation
        )
        general_suggestion_comment = self.comment_manager.prepare_general_suggestion_comment(
            header, replacement, code_suggestion, explanation
        )
        lines_to_post = get_suggestion_line_numbers(replacement)
        side = 'RIGHT'
        position_review_comment = self.comment_manager.create_comment_body_for_position(
            review_suggestion_comment, self.review_comment['commit_id'], self.review_comment['file_path'], lines_to_post, side
        )

        return {
            "review_suggestion_comment": review_suggestion_comment,
            "general_suggestion_comment": general_suggestion_comment,
            "position_review_comment": position_review_comment
        }