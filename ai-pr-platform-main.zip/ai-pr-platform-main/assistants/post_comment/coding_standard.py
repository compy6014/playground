import logging
from typing import Any, Dict, Optional
import requests
import base64
import os
import json
import pathlib
from requests.exceptions import HTTPError

#from assistants.ai_assistant import AIAssistant
from assistants.post_comment.post_comment_assistant import PostCommentAssistant
from helpers.utils import extract_pr_info
#from helpers.ai_comment_manager import AICommentManager
from helpers.ai_comment_helper import AICommentHelper
from helpers.utils import get_suggestion_line_numbers
from helpers.utils import get_team_name_by_team

class CodingStandardAssistant(PostCommentAssistant):
    """
    An AI Assistant that checks coding standards in pull requests.
    """

    # Class-level constants for links and disclaimer
    CONFLUENCE_LINK = "https://amd.atlassian.net/wiki/spaces/~subharoy/database/503971967"
    DEFAULT_CODING_STANDARD_URL = "https://github.com/SW-Infra-EMU/ai-pr-platform/blob/main/config/default_coding_stadard.json"
    DISCLAIMER_SUFFIX = ("For questions or feedback, please react with a '👍' or '👎,' "
                        "or contact dl.ai_code_review for assistance.")

    def __init__(self, ghe_token: str, json_in_params: Optional[Dict[str, Any]] = None, use_dev: bool = False):
        super().__init__(ghe_token, json_in_params, use_dev)
        # Initialize your attributes here
        #self.comment_manager = AICommentManager()
        self.comment_helper = AICommentHelper()
        self.pr_url = self.json_in_params.get('pr_url')
        self.llm_token = self.json_in_params.get('llm_token')

    def assistant_type(self) -> str:
        """Return the assistant type name."""
        return 'CodingStandard'

    def required_parameters(self) -> list:
        """Return the required parameter names."""
        return ['pr_url']

    def optional_parameters(self) -> list:
        """Return optional parameters, grouped if necessary."""
        return []

    def pre_processing(self):
        """Perform pre-processing steps before making an API call."""
        self.logger.debug("Starting pre_processing...")

        pr_data = extract_pr_info(self.pr_url)
        if "error" not in pr_data:
            self.owner = pr_data["owner"]
            self.repo = pr_data["repo"]
            self.pr_number = pr_data["pr_number"]
            self.logger.debug(f"Owner: {self.owner}, Repo: {self.repo}, PR Number: {self.pr_number}")
        else:
            raise ValueError(pr_data["error"])

        pr_metadata = self.github_helper.get_pr_data(self.owner, self.repo, self.pr_number)
        self.base_branch = pr_metadata.get('base', {}).get('ref', 'main')
        self.logger.debug(f"Getting team name for owner: {self.owner}, repo: {self.repo}, branch: {self.base_branch}")
        self.team_name = get_team_name_by_team(self.owner, self.repo, branch = self.base_branch)
        self.logger.debug(f"Retrieved Team Name: {self.team_name}")

    def skip_file_with_invalid_additions(self, file_item, min_threshold=1, max_threshold=1000):
        """
        Returns True if the file's 'additions' property is either zero (below min_threshold)
        or exceeds the max_threshold.
        """
        additions = file_item.get("additions", 0)
        return additions < min_threshold or additions > max_threshold

    def get_top_files_by_priority(self, files, max_count=10):
        """
        Takes a list of files (as found in commit_details["files"]) and returns
        the first 'max_count' files sorted by extension priority:
        1) .cpp
        2) .c
        3) .h
        4) .hpp
        5) .cs
        6) .py
        0) Excluded files (all other extensions)
        """

        def extension_priority(filename: str) -> int:
            fname_lower = filename.lower()
            if fname_lower.endswith(".cpp"):
                return 1
            elif fname_lower.endswith(".c"):
                return 2
            elif fname_lower.endswith(".h"):
                return 3
            elif fname_lower.endswith(".hpp"):
                return 4
            elif fname_lower.endswith(".cs"):
                return 5
            elif fname_lower.endswith(".py"):
                return 6
            else:
                return 0  # Assign priority 0 to excluded files

        # Assign priorities and filter out files with priority 0
        filtered_files = [
            file for file in files
            if extension_priority(file.get("filename", "")) > 0
        ]

        # Sort the filtered files by extension priority
        sorted_files = sorted(
            filtered_files,
            key=lambda f: extension_priority(f.get("filename", ""))
        )

        # Return the top 'max_count' files
        return sorted_files[:max_count]

    def sort_and_filter_violations(self, violations, num_l1, num_l2):
        """
        Sort violations based on priority order and return the specified number of L1 and L2 violations.

        :param violations: List of violation dictionaries.
        :param num_l1: Number of L1 violations to return.
        :param num_l2: Number of L2 violations to return.
        :return: List of filtered and sorted violations in the same format as the input.
        """
        # Define the priority order for code_violation_heading
        priority_order = [
            "Naming Convention",
            "Types and Declarations",
            "Documentation and Comments",
            "General Functions",
            "Ifs Loops and Switch statements",
            "Preprocessor",
            "General Language Restrictions",
            "Error Checking"
        ]

        # Helper function to get the priority index
        def get_priority_index(violation):
            heading = " ".join(violation.get("code_violation_heading", []))
            if heading in priority_order:
                return priority_order.index(heading)
            return len(priority_order)  # Assign lowest priority if not found

        # Separate violations into L1 and L2 categories
        l1_violations = []
        l2_violations = []

        for violation in violations:
            if "L2" in violation.get("priority", []):
                l2_violations.append(violation)
            elif "L1" in violation.get("priority", []):
                l1_violations.append(violation)

        # Sort each category by priority order
        l1_violations = sorted(l1_violations, key=get_priority_index)
        l2_violations = sorted(l2_violations, key=get_priority_index)

        # Limit the number of L1 and L2 violations
        filtered_l1 = l1_violations[:num_l1]
        filtered_l2 = l2_violations[:num_l2]

        # Combine the filtered violations and return in the same format
        return filtered_l1 + filtered_l2

    def generate_api_params(self):
        """Generate parameters for the API or standard checking process."""
        self.logger.debug("Generating API parameters for coding standards...")

        # Get the latest commit SHA from the PR (for file content)
        self.latest_sha = self.github_helper.get_latest_commit_sha_from_pr(
            self.owner, self.repo, self.pr_number
        )
        self.logger.debug(f"Latest commit SHA: {self.latest_sha}")

        # Fetch coding standard file for the team (if available)
        self.fetch_coding_standard()

        files_info = []

        # Get PR diff and changed files
        diff = self.github_helper.get_pr_diff(self.owner, self.repo, self.pr_number)
        changed_files = self.github_helper.get_pr_files(self.owner, self.repo, self.pr_number)

        # Sort files by priority
        sorted_files = self.get_top_files_by_priority(changed_files)
        self.logger.debug(f"Sorted filenames: {[file.get('filename') for file in sorted_files]}")

        # Exit if no files to process
        if not sorted_files:
            self.logger.info("No files to process. Skipping generation of API params.")
            self.json_api_params = []
            return

        # Process each file
        for file_item in sorted_files:
            filename = file_item.get("filename")

            # Skip files with too many additions
            if self.skip_file_with_invalid_additions(file_item, max_threshold=1000):
                self.logger.warning(f"Skipping file {filename} as it has more than 1000 additions.")
                continue

            if not filename:
                self.logger.warning("Filename not found in commit file item.")
                continue

            # Get full file content
            try:
                file_content_decoded = self.github_helper.get_file_content(
                    self.owner, self.repo, self.latest_sha, filename
                )
            except Exception as e:
                self.logger.error(f"Error fetching content for file {filename}: {e}")
                file_content_decoded = ""

            files_info.append({
                "filename": filename,
                "diff": diff,
                "full_file": file_content_decoded,
                "custom_coding_standard": self.coding_standard_json
            })

            self.logger.debug(f"Processed file: {filename}")

        self.json_api_params = files_info

    def api_call(self, api_url: str, api_token: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Call an API or process to evaluate coding standards.
        If 'params' is a list of file-parameter dicts, loop and call the API once per file.
        Otherwise, handle a single param dict as before.
        """
        self.logger.debug("Calling the code review comment generator...")

        headers = {
            "Ocp-Apim-Subscription-Key": api_token
        }
        if isinstance(params, list):
            self.logger.debug("Multiple files to process...")
            all_results = []
            failed_calls = 0

            for file_param in params:
                self.logger.debug(f"Calling API for file: {file_param.get('filename')}")
                json_payload = {
                    "file_diff": file_param.get("diff"),
                    "full_file": file_param.get("full_file"),
                    "llm_token": self.llm_token,
                    "file_name": file_param.get("filename"),
                    "username": self.team_name,
                    "repo_name": f"{self.owner}/{self.repo}",
                    "pr_url": self.pr_url,
                    "custom_coding_standard": file_param.get("custom_coding_standard")
                }
                # Save JSON payload to file
                full_file_path = file_param.get("filename", "")
                short_name = os.path.splitext(os.path.basename(full_file_path))[0]
                json_filename = f"API_json_data_{short_name}.json"
                with open(json_filename, "w", encoding="utf-8") as f:
                    try:
                        json.dump(json_payload, f, indent=2)
                    except Exception as e:
                        self.logger.error(f"Failed to write JSON payload to file '{json_filename}': {e}")

                try:
                    resp = requests.post(
                        url=api_url,
                        json=json_payload,
                        verify=False,
                        headers=headers
                    )
                    resp.raise_for_status()
                    all_results.append(resp.json())
                    self.logger.debug(f"API call succeeded for file: {file_param.get('filename')}")
                except Exception as e:
                    failed_calls += 1
                    self.logger.error(
                        f"API call failed for file '{file_param.get('filename')}': {e}"
                    )
                    if hasattr(e, 'response') and e.response is not None:
                        self.logger.error(f"Full error details (raw text): {e.response.text}")

            # If all calls failed, raise an exception
            if failed_calls == len(params):
                raise RuntimeError("API call failed for all files.")
            return all_results

        # Single-dict params
        try:
            resp = requests.post(
                url=api_url,
                json={
                    "file_diff": params.get("diff"),
                    "full_file": params.get("full_file"),
                    "llm_token": params.get("llm_token"),
                    "file_name": params.get("filename")
                },
                verify=False,
                headers=headers
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            self.logger.error(f"API call failed for single file: {e}")
            raise

    def fetch_coding_standard(self) -> None:
        """
        Fetch the coding standard JSON file for the team from the repository.
        Search order:
        1. .github/.ai_pr_platform/ folder (new location)
        2. .github/ folder (legacy location)
        3. Default coding standard in config directory

        For drivers repository: ai_coding_standard<team_name>.json
        For other repositories: ai_coding_standard.json
        Sets self.coding_standard_json if found, else sets to None.
        """

        # Determine filename based on repository type
        is_drivers_repo = "drivers" in self.repo.lower()
        if is_drivers_repo:
            filename = f"ai_coding_standard_{self.team_name}.json"
        else:
            filename = "ai_coding_standard.json"

        base_branch = getattr(self, 'base_branch', None)
        if not base_branch:
            pr_metadata = self.github_helper.get_pr_data(self.owner, self.repo, self.pr_number)
            base_branch = pr_metadata.get('base', {}).get('ref', 'main')

        # Search paths in order of preference
        search_paths = [
            f".github/.ai_pr_platform/{filename}",
            f".github/{filename}"
        ]

        # Try to fetch team-specific coding standard from search paths
        team_standard_loaded = False
        for github_path in search_paths:
            try:
                file_content = self.github_helper.get_file_content(
                    self.owner, self.repo, base_branch, github_path
                )
                self.coding_standard_json = json.loads(file_content)
                self.logger.info(f"Loaded coding standard from {github_path} on branch {base_branch}")
                # Build coding standard link using the host from self.github_host
                host = getattr(self, 'github_host', None) or "github.com"
                self.coding_standard_url = f"https://{host}/{self.owner}/{self.repo}/blob/{base_branch}/{github_path}"
                team_standard_loaded = True
                break  # Found the file, no need to search further
            except HTTPError as http_err:
                # Handle 404 errors gracefully (file not found)
                if hasattr(http_err, 'response') and http_err.response.status_code == 404:
                    self.logger.info(f"Team coding standard file '{github_path}' not found in repository.")
                else:
                    # Log other HTTP errors as warnings
                    self.logger.warning(f"HTTP error while loading coding standard file '{github_path}': {http_err}")
            except json.JSONDecodeError as json_err:
                self.logger.warning(f"Invalid JSON in coding standard file '{github_path}': {json_err}")
            except Exception as e:
                self.logger.warning(f"Unexpected error loading coding standard file '{github_path}': {e}")

        # Fall back to default coding standard if team standard was not loaded
        if not team_standard_loaded:
            try:
                config_path = pathlib.Path(__file__).parent.parent.parent / 'config' / 'default_coding_stadard.json'
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.coding_standard_json = json.load(f)
                self.logger.info(f"Loaded default coding standard from {config_path}")
                self.coding_standard_url = self.DEFAULT_CODING_STANDARD_URL
            except FileNotFoundError:
                self.logger.warning(f"Default coding standard file not found at {config_path}")
                self.coding_standard_json = None
                self.coding_standard_url = None
            except json.JSONDecodeError as json_err:
                self.logger.warning(f"Invalid JSON in default coding standard file: {json_err}")
                self.coding_standard_json = None
                self.coding_standard_url = None
            except Exception as e:
                self.logger.warning(f"Unexpected error loading default coding standard file: {e}")
                self.coding_standard_json = None
                self.coding_standard_url = None

    def get_coding_standard_link(self) -> str:
        """
        Returns the appropriate coding standard link for use in disclaimers.
        """
        if getattr(self, 'coding_standard_url', None):
            if self.coding_standard_url == self.DEFAULT_CODING_STANDARD_URL:
                return f"[Default Coding Standard]({self.coding_standard_url})"
            return f"[Team Coding Standard]({self.coding_standard_url})"
        return f"[Coding Standard Document]({self.CONFLUENCE_LINK})"

    def get_disclaimer_text(self) -> str:
        """
        Returns the full disclaimer text for review and conversation comments.
        """
        return f"For additional details of violations, please refer to {self.get_coding_standard_link()}\n{self.DISCLAIMER_SUFFIX}"

    def post_processing(self, api_result: list[Dict[str, Any]]):
        self.logger.debug("Starting post_processing...")

        review_comment_list = []
        conversation_expansions = []

        if not api_result:
            self.logger.warning("API result is empty. No violations to process.")
            return

        for item in api_result:
            violations = item.get('violations', [])
            file_name = item.get('file_name')

            if not file_name:
                self.logger.warning("Missing 'file_name' in api_result item. Skipping.")
                continue

            if not violations:
                self.logger.debug(f"No violations found for file '{file_name}' in API response.")
                continue

            file_expansions = []

            #sorted_violations = self.sort_and_filter_violations(violations, num_l1=5, num_l2=10)
            sorted_violations = violations
            #self.logger.debug(f"Sorted violations for file {file_name}: {sorted_violations}")

            for violation in sorted_violations:
                label = violation.get('label')
                priority = violation.get('priority', [])
                heading = ", ".join(violation.get('code_violation_heading', []))
                subheading = ", ".join(violation.get('code_violation_sub_heading', []))

                code_fix = violation.get('code_fix', '')
                replacement_block = violation.get('replacement_block', '')
                if not replacement_block.strip():
                    self.logger.debug(f"Skipping violation '{heading}' for file '{file_name}' because replacement_block is empty.")
                    continue

                if 'L1' in priority:
                    # Existing logic for L1 priorities
                    if label in ['ACTIONABLE', 'FIX']:
                        self.logger.debug(f"Adding violation {heading} of file: {file_name} to review comment with suggestion")
                        comment_body = self.comment_helper.prepare_suggestion_comment(
                            subheader=f"**{heading}**: {subheading}",
                            explanation_text_1=violation.get('llm_comment'),
                            code_suggestion=violation.get('code_fix')
                        )
                    else:
                        self.logger.debug(f"Adding review comment without suggestion")
                        comment_body = self.comment_helper.prepare_suggestion_comment(
                            subheader=f"**{heading}**: {subheading}",
                            #explanation_text_1=violation.get('llm_comment')
                            explanation_text_1=f"{violation.get('llm_comment')}\n\nCurrently, we are unable to provide a solution for this request because it requires additional context. We plan to enable these scenarios in the near future."
                        )

                    comment = self.comment_helper.prepare_review_comment_data(
                        path=file_name,
                        side="RIGHT",
                        body=comment_body,
                        line=violation.get('ending_line_number'),
                        start_line=violation.get('starting_line_number')
                    )
                    review_comment_list.append(comment)

                else:
                    # Handling for non-L1 priorities (conversation comments)
                    self.logger.debug(f"Adding conversation comment for violation: {heading}")

                    if not code_fix:
                        explanation_text = f"{violation.get('llm_comment')}\n\nCurrently, we are unable to provide a solution for this request because it requires additional context. We plan to enable these scenarios in the near future."
                    else:
                        explanation_text = violation.get('llm_comment')

                    # Create nested expansion for the violation
                    violation_expansion = self.comment_helper.prepare_suggestion_comment(
                        subheader=f"**{heading}**: {subheading}",
                        explanation_text_1=explanation_text,
                        code_suggestion=violation.get('code_fix'),
                        original_source_code=violation.get('replacement_block'),
                        commitable_suggestion=False
                    )
                    file_expansions.append(violation_expansion)

            if file_expansions:
                # Create an expansion for the file containing all its violations
                header = f"**File:** `{file_name}`"
                file_summary = f""
                file_expansions = self.comment_helper.prepare_suggestion_comment(
                    subheader=header,
                    #explanation_text_2=file_expansions,
                    explanation_text_2="\n\n".join(file_expansions),
                    expansion_summary = 'Click to expand the violations'
                )
                conversation_expansions.append(file_expansions)

        # posting review comments
        disclaimer_text = self.get_disclaimer_text()
        if review_comment_list:
            self.logger.debug(f"Posting review comments: {review_comment_list}")
            self.create_and_post_pr_review(
                self.owner,
                self.repo,
                self.pr_number,
                self.latest_sha,
                header="AI Code Review [L1 Major coding violations]",
                text="AI Code Review tool has identified several L1 coding standard violations in your submission. Please review the following issues and make the necessary adjustments to ensure compliance with our coding standards.",
                disclaimer_text=disclaimer_text,
                comments=review_comment_list
            )

        # posting conversation comments
        if conversation_expansions:
            self.create_and_post_conversation_comment(
                owner=self.owner,
                repo=self.repo,
                pr_number=self.pr_number,
                header="AI Code Review [L2 Good-to-fix coding violations]",
                description=(
                    "AI Code Review tool has identified several **L2 coding standard violations** "
                    "in your submission. Please review the following issues and make the necessary "
                    "adjustments to ensure compliance with our coding standards."
                ),
                expansions="\n\n".join(conversation_expansions),
                disclaimer_text=disclaimer_text
            )

        return super().post_processing()
