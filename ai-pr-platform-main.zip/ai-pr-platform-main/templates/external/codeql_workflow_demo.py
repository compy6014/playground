#[PHASE: pre_process]    
print("PRE_PROCESS PHASE START")    
formatter_context = {}      
formatter = Formatter("codeql_templates", team_name, formatter_context)  
  
git_environment = formatter.format("git_environment")  
codeql_environment = formatter.format("codeql_environment")  
owner = formatter.format("owner")    
repo = formatter.format("repo")  
rule_override = globals().get('rule_override', None)  
if rule_override:  
    print(f"Using override rules: {rule_override}")  
    rules = rule_override  
else:  
    print("Using template rules")  
    rules = formatter.format("rules")  
branches_str = formatter.format("base_branch")    
detect_fp = formatter.format("detect_fp")    
ticket_ids_str = formatter.format("ticket_id")    
git_blame = formatter.format("git_blame")    
service_accounts = formatter.format("service_accounts")    
send_no_alert_email = formatter.format("send_no_alert_email")    
email_server = formatter.format("email_server")    
email_port = formatter.format("email_port")    
email_sender = formatter.format("email_sender")    
draft_pr = formatter.format("draft_pr")  
include_explanation = formatter.format("include_explanation")  
pr_platform = formatter.format("pr_platform")  
branch_delete = formatter.format("branch_delete")  
state = formatter.format("state")  
alert_process_limit = formatter.format("alert_process_limit")  
trigger_event = globals().get('trigger_event')  
if trigger_event == "workflow_dispatch":  
    trigger_source = "On-demand"  
else:  
    trigger_source = "Scheduled"  
  
if git_environment == "enterprise":    
    github_instance = "on-prem"    
else:    
    github_instance = "EMU"    
  
github_api = SpecificAPI("github", environment=git_environment)    
codeql_api = SpecificAPI("codeql", environment=codeql_environment)    
graphql_api = SpecificAPI("graphql", environment=git_environment)      
  
branches = [b.strip() for b in branches_str.split(',')]  
ticket_ids = [t.strip() for t in ticket_ids_str.split(',')]  
rules = [rule.strip() for rule in rules.split(',')]    
  
alert_numbers = globals().get('alert_numbers', None)    
if alert_numbers and isinstance(alert_numbers, str):    
    alert_numbers = FunctionLibrary.expand_alert_numbers(alert_numbers)  
else:  
    skipped_alert_numbers = []  
is_alert_number_mode = bool(alert_numbers)  
  
if len(ticket_ids) == 1:  
    ticket_ids = ticket_ids * len(branches)  
    
print("PRE_PROCESS PHASE END")    
#[END_PHASE]    
    
#[PHASE: get_alerts]    
print("GET_ALERTS PHASE START")    
notification_message = ""  
all_skipped_alert_numbers = []  # Global tracker for all skipped alerts  
  
# Collect results for all branches    
all_branch_results = []  
for idx, branch in enumerate(branches):    
    ticket_id = ticket_ids[idx] if idx < len(ticket_ids) else ticket_ids[-1]    
    formatter.update_context({"branch": branch, "ticket_id": ticket_id})  
    print(f"=== Processing branch: {branch} ===")  
    results = []    
    filtered_alerts = []    
    if alert_numbers:    
        branch_alert_numbers = alert_numbers.copy()  # Copy the full list for each branch  
        if len(branch_alert_numbers) > alert_process_limit:  
            branch_skipped_alert_numbers = branch_alert_numbers[alert_process_limit:]  
            branch_alert_numbers = branch_alert_numbers[:alert_process_limit]  
            all_skipped_alert_numbers.extend(branch_skipped_alert_numbers)  # Add to global tracker  
        else:  
            branch_skipped_alert_numbers = []  
              
        not_found_alerts = []  
        for alert_number in branch_alert_numbers:    
            print(f"Fetching alert {alert_number} from {owner}/{repo}")    
            try:  
                alert_json = github_api.make_request(    
                    "get_code_scanning_alert",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    alert_number=alert_number    
                )    
                # Extract branch name from ref    
                alert_branch = alert_json.get('most_recent_instance', {}).get('ref', '')    
                if alert_branch.startswith('refs/heads/'):    
                    alert_branch = alert_branch[len('refs/heads/'):]    
                # Only add if alert belongs to the current branch    
                if alert_branch == branch:    
                    filtered_alerts.append(alert_json)    
                    date_sentence = f"<p>The following summarizes the result of CodeQL FP Detection and Fix Generation for alerts {branch_alert_numbers}:</p>"    
                else:    
                    print(f"Alert {alert_number} is on branch '{alert_branch}', skipping for branch '{branch}'")    
            except RuntimeError as e:  
                if "404" in str(e):  
                    print(f"Alert {alert_number} does not exist.")  
                    not_found_alerts.append(alert_number)  
                    continue  
                else:  
                    raise  
        if len(branch_alert_numbers) == 1 and len(not_found_alerts) == 1:  
            notification_message = (f"<br><p>Alert ID {branch_alert_numbers[0]} does not exist in {owner}/{repo}.</p>")  
        else:  
            notification_message = ""  
        branch_total_detected = len(filtered_alerts)  
    else:    
        from_date = globals().get('from_date', None)    
        to_date = globals().get('to_date', None)    
        if from_date and to_date:    
            print(f"Fetching alerts from {owner}/{repo}, from {from_date} to {to_date}")    
            from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))    
            readable_from_date = from_date_dt.strftime("%B %d, %Y")    
            to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))    
            readable_to_date = to_date_dt.strftime("%B %d, %Y")    
            date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created from {readable_from_date} to {readable_to_date}:</p>"    
        elif from_date:    
            print(f"Fetching alerts from {from_date} to now {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")    
            from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))    
            readable_from_date = from_date_dt.strftime("%B %d, %Y")    
            readable_to_date = datetime.now(timezone.utc).strftime("%B %d, %Y")    
            date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created from {readable_from_date} to {readable_to_date}:</p>"    
        elif to_date:    
            print(f"Fetching alerts up to {to_date}")    
            to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))    
            readable_to_date = to_date_dt.strftime("%B %d, %Y")    
            date_sentence = f"<p>The following summarizes the results of CodeQL FP Detection and Fix Generation for alerts created up to {readable_to_date}:</p>"    
        else:    
            print("No date range specified, filtering not applied")    
            date_sentence = "<p></p>"    
          
        all_alerts_json = github_api.make_request(    
            "get_code_scanning_results",    
            repo_name=repo,    
            repo_owner=owner,    
            branch=branch,    
            state=state,    
            rules=rules,    
            from_date=from_date,    
            to_date=to_date    
        )  
  
        if all_alerts_json:    
            print(f"Found {len(all_alerts_json)} alerts")    
            branch_total_detected = len(all_alerts_json)  
            if len(all_alerts_json) > alert_process_limit:  
                branch_skipped_alert_numbers = [a['number'] for a in all_alerts_json[alert_process_limit:]]  
                all_skipped_alert_numbers.extend(branch_skipped_alert_numbers)  # Add to global tracker  
                all_alerts_json = all_alerts_json[:alert_process_limit]  
            else:  
                branch_skipped_alert_numbers = []  
            filtered_alerts.append(all_alerts_json)  
        else:  
            branch_total_detected = 0  
            branch_skipped_alert_numbers = []  
      
    if len(filtered_alerts) == 1 and isinstance(filtered_alerts[0], list):    
        flat_data = filtered_alerts[0]    
    else:    
        flat_data = filtered_alerts    
      
    for alert in flat_data:    
        print(f"Processing alert {alert['number']}")  
          
        #[PHASE: process_alerts]    
        print("PROCESS_ALERTS SUB-PHASE STARTED")    
        result = {    
            'alert_number': alert['number'],    
            'url': alert['html_url'],    
            'predicted_as_fp': False,    
            'pr_url': None,    
            'branch_name': None,    
            'explanation': None    
        }    
      
        print(f"Calling CodeQL Fix API for alert {result['alert_number']}")    
        fix = codeql_api.make_request(    
            "codeql_fix",    
            alert_num=result['alert_number'],    
            include_explanation=include_explanation,    
            github_instance=github_instance,    
            owner=owner,    
            repo_name=repo,    
            detect_fp=detect_fp,    
            pr_platform=pr_platform    
        )    
        print(f"Fix: {fix}")    
        result['predicted_as_fp'] = fix['predicted_as_fp']    
      
        if result['predicted_as_fp'] and detect_fp:    
            print(f"Predicted as FP; \n{fix['explanation']}")    
            result['explanation'] = fix['explanation']    
            results.append(result)    
            continue    
      
        base_sha = alert['most_recent_instance']['commit_sha']    
        file_path = alert['most_recent_instance']['location']['path']    
        start_line = alert['most_recent_instance']['location']['start_line']    
        end_line = alert['most_recent_instance']['location']['end_line']    
      
        if git_blame is True:    
            fallback_list = formatter.format("fallback_team_slug")    
            response = graphql_api.make_request(    
                "blame",    
                repo_name=repo,    
                repo_owner=owner,    
                branch_name=branch,    
                file_path=file_path    
            )    
            blame_data = response['data']['repository']['ref']['target']['blame']['ranges']    
            blame_list = FunctionLibrary.blame_for_lines(blame_data, start_line, end_line)    
            blame_list = [r.strip() for r in blame_list.split(", ") if r.strip()]    
            filtered_list = [r for r in blame_list if r not in service_accounts]    
              
            if filtered_list:    
                final_list = filtered_list    
            else:    
                last_file_mod = github_api.make_request(    
                    "get_last_committer",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    branch=branch,    
                    file_path=file_path    
                )[0]    
                if last_file_mod and last_file_mod not in service_accounts:    
                    final_list = last_file_mod    
                else:    
                    final_list = fallback_list    
                    team_reviewers = True    
      
        original_file = FunctionLibrary.base64_decode(    
            github_api.make_request(    
                "get_file_content",    
                repo_name=repo,    
                repo_owner=owner,    
                branch_sha=base_sha,    
                file_path=file_path    
            )    
        )    
        corrected_file = FunctionLibrary.apply_diff_to_file(    
            original_file=original_file,    
            file_name=file_path,    
            code_diff=fix['diff']    
        )    
      
        # Encode updated file    
        encoded_content = FunctionLibrary.base64_encode(corrected_file)    
      
        print("PROCESS_ALERTS SUB-PHASE END")    
        #[END_PHASE]    
        #[PHASE: formatting]    
        print("FORMATTING SUB-PHASE START")    
          
        formatter.update_context({    
            "owner": owner,    
            "repo": repo,    
            "branch": branch,    
            "alert_number": result['alert_number'],    
            "rule_header": FunctionLibrary.get_rule_based_commit_text(    
                alert['rule']['id'],    
                alert['rule']['description'],    
                alert['rule']['description']    
            )[0],    
            "root_folder": (os.path.normpath(file_path)).split(os.path.sep)[0],    
            "rule_description": FunctionLibrary.get_rule_based_commit_text(    
                alert['rule']['id'],    
                alert['rule']['description'],    
                alert['rule']['description']    
            )[1],    
            "alert_severity": alert['rule'].get('security_severity_level', "N/A"),    
            "alert_description": alert['rule']['description'],    
            "alert_url": alert['html_url'],    
            "fix_explanation": fix['explanation'],    
            "signoff_user": github_api.make_request("get_user_details")[0],    
            "signoff_email": github_api.make_request("get_user_details")[1],    
            "ticket_id": ticket_id,    
            "date_sentence": date_sentence    
        })    
      
        generated_branch_name = formatter.format("generate_branch_name")    
        generated_commit_header = formatter.format("generate_commit_header")    
        generated_commit_description = formatter.format("generate_commit_description")    
        generated_commit_message = generated_commit_header + "\n\n" + generated_commit_description    
        generated_pr_title = formatter.format("generate_pr_title")    
        generated_pr_description = formatter.format("generate_pr_description")    
        sign_off_message = formatter.format("sign_off_message")    
          
        if sign_off_message:    
            generated_commit_message += f"\n\n{sign_off_message}"    
      
        result['branch_name'] = generated_branch_name    
      
        print("FORMATTING SUB-PHASE END")    
        #[END_PHASE]    
      
        #[PHASE: create_branch_and_pr]    
        print("CREATE_BRANCH_AND_PR SUB-PHASE START")    
      
        try:    
            branch_exists = github_api.make_request(    
                "check_existing_branch",    
                repo_name=repo,    
                repo_owner=owner,    
                branch_name=generated_branch_name    
            )    
            print(branch_exists)    
            print(f"Branch '{generated_branch_name}' already exists")    
              
            if branch_delete:    
                print(f"Deleting existing branch with name '{generated_branch_name}'")    
                try:    
                    delete_branch = github_api.make_request(    
                        "delete_existing_branch",    
                        repo_name=repo,    
                        repo_owner=owner,    
                        branch_name=generated_branch_name    
                    )    
                    print("Deleting existing branch")    
                except RuntimeError as e:    
                    if "422" in str(e):    
                        print(f"Existing branch '{generated_branch_name}' deleted")    
                        print(f"Branch '{generated_branch_name}' does not exist, creating branch")    
                        create_branch_response = github_api.make_request(    
                            "create_branch",    
                            repo_name=repo,    
                            repo_owner=owner,    
                            ref=f"refs/heads/{generated_branch_name}",    
                            sha=base_sha    
                        )    
                        print(create_branch_response)  
                    else:    
                        raise    
            else:    
                generated_branch_name = generated_branch_name + '_2'    
                create_branch_response = github_api.make_request(    
                    "create_branch",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    ref=f"refs/heads/{generated_branch_name}",    
                    sha=base_sha    
                )    
                print(f"Creating branch with modified name: {generated_branch_name}")    
          
        except RuntimeError as e:    
            if "404" in str(e):    
                print(f"Branch '{generated_branch_name}' does not exist, creating branch")    
                create_branch_response = github_api.make_request(    
                    "create_branch",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    ref=f"refs/heads/{generated_branch_name}",    
                    sha=base_sha    
                )    
                print(create_branch_response)    
            else:    
                raise    
      
        try:    
            file_sha = github_api.make_request(    
                "check_file_sha",    
                repo_name=repo,    
                repo_owner=owner,    
                new_branch=generated_branch_name,    
                file_path=file_path    
            )    
        except RuntimeError as e:    
            if "404" in str(e):    
                print(f"File '{file_path}' does not exist")    
                file_sha = None    
      
        if file_sha:    
            response = github_api.make_request(    
                "update_existing_file",    
                repo_name=repo,    
                repo_owner=owner,    
                file_path=file_path,    
                message=generated_commit_message,    
                content=encoded_content,    
                branch=generated_branch_name,    
                sha=file_sha    
            )    
            print(f"Updating existing file '{file_path}'")    
        else:    
            response = github_api.make_request(    
                "create_new_file",    
                repo_name=repo,    
                repo_owner=owner,    
                file_path=file_path,    
                message=generated_commit_message,    
                content=encoded_content,    
                branch=generated_branch_name    
            )    
            print(f"Creating file '{file_path}'")    
          
        result['branch_name'] = generated_branch_name    
          
        pr_url = github_api.make_request(    
            "create_pull_request",    
            repo_name=repo,    
            repo_owner=owner,    
            title=generated_pr_title,    
            body=generated_pr_description,    
            head=generated_branch_name,    
            base=branch,    
            draft=draft_pr    
        )    
        print(f"PR title: {generated_pr_title}")    
        result['pr_url'] = pr_url    
        pr_number = re.search(r'/pull/(\d+)', pr_url).group(1)    
      
        label_list = formatter.format("label_list")    
        reviewer_list = formatter.format("reviewer_list")    
        label_list = [label.strip() for label in label_list.split(',')]    
        reviewer_list = [reviewer.strip() for reviewer in reviewer_list.split(',')]    
        print(reviewer_list)    
          
        if pr_url is not None and label_list:    
            print(f"Adding labels to PR: {pr_url}")    
            add_labels = github_api.make_request(    
                "add_labels_to_pr",    
                repo_name=repo,    
                repo_owner=owner,    
                pr_number=pr_number,    
                labels=label_list    
            )    
            print("Labels added")    
              
        if pr_url is not None and reviewer_list:    
            if '#last_committer' in reviewer_list:    
                last_committer = github_api.make_request(    
                    "get_last_committer",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    branch=generated_branch_name,    
                    file_path=file_path    
                )    
                if last_committer:    
                    reviewer_list = reviewer_list.replace('#last_committer', last_committer)    
                    print(f"Replaced '#last_committer' in reviewers list with {last_committer}.")    
                else:    
                    reviewer_list = reviewer_list.replace('#last_committer', '')    
              
            add_reviewer = github_api.make_request(    
                "add_reviewers_to_pr",    
                repo_name=repo,    
                repo_owner=owner,    
                pr_number=pr_number,    
                reviewers=reviewer_list    
            )    
            print(f"Adding reviewers {reviewer_list} to PR: {pr_url}")    
      
        final_list = ["imirosav"]  # OVERRIDE FINAL_LIST FOR DEMO    
        if git_blame is True:    
            team_reviewers = globals().get('team_reviewers', None)    
            if team_reviewers is True:    
                response = github_api.make_request(    
                    "add_team_reviewers_to_pr",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    pr_number=pr_number,    
                    team_reviewers=final_list    
                )    
                print(f"Assign team {final_list} to reviewers")    
            else:    
                response = github_api.make_request(    
                    "add_reviewers_to_pr",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    pr_number=pr_number,    
                    reviewers=final_list    
                )    
                print(f"Assign {final_list} to reviewers")    
          
        results.append(result)    
      
    print("CREATE_BRANCH_AND_PR SUB-PHASE END")    
    #[END_PHASE]    
      
    print("GET_ALERTS PHASE END")    
    #[END_PHASE]   
  
    branch_has_results = len(results) > 0    
    
    if (not is_alert_number_mode) or (is_alert_number_mode and branch_has_results):    
        all_branch_results.append({    
            "branch": branch,    
            "results": results,    
            "date_sentence": date_sentence,  
            "not_found_alerts" : not_found_alerts if alert_numbers else [],  
            "total_detected": branch_total_detected  
        })  
      
#[PHASE: send_email]    
print("SEND_EMAIL PHASE START")    
  
branches_sections = []  
all_detected_fp = []  
all_created_prs = []  
attachments = None  
  
for branch_result in all_branch_results:  
    branch = branch_result["branch"]  
    results = branch_result["results"]  
    date_sentence = branch_result.get("date_sentence", "")  
    not_found_alerts = branch_result.get("not_found_alerts", [])   
    detected_fp = [result for result in results if result.get('predicted_as_fp') is True]    
    created_prs = [result for result in results if result['pr_url']]      
    all_detected_fp.extend(detected_fp)  
    all_created_prs.extend(created_prs)  
  
    # Format detected FP section  
    if detected_fp:  
        detected_fp_section = "<ul>" + "".join([    
            f"<li>For alert <a href='{fp['url']}'>{fp['alert_number']}</a>: {fp['explanation']}</li>"    
            for fp in detected_fp    
        ]) + "</ul>"  
    else:  
        detected_fp_section = "<ul><li>None</li></ul>"    
  
    # Format created PRs section  
    if created_prs:  
        created_prs_section = "<ul>" + "".join([    
            f"<li>For alert <a href='{pr['url']}'>{pr['alert_number']}</a>: <a href='{pr['pr_url']}'>{pr['pr_url']}</a></li>"    
            for pr in created_prs    
        ]) + "</ul>"  
    else:  
        created_prs_section = "<ul><li>None</li></ul>"    
  
    section = f"""  
    <br><p><b>Branch: {branch}</b></p>  
    <p>Detected False Positives:</p>  
    <p>{detected_fp_section}</p>  
    <p>Created PRs:</p>  
    <p>{created_prs_section}</p>  
    """  
    if not_found_alerts:    
        section += f"""    
        <p>Not found IDs:</p><ul>    
        <li>{not_found_alerts}</li></ul>    
        """  
    branches_sections.append(section)  
  
branches_section = "\n".join(branches_sections)  
  
total_alerts_detected = 0  
for branch_result in all_branch_results:    
    total_alerts_detected += branch_result.get("total_detected", len(branch_result["results"]))    
  
total_alerts_processed = len(all_detected_fp) + len(all_created_prs)  
if is_alert_number_mode:    
    total_alerts_skipped = len(all_skipped_alert_numbers)    
else:    
    total_alerts_skipped = len(all_skipped_alert_numbers) if all_skipped_alert_numbers else 0    
  
  
summary_section = f"<p><b>Summary:</b></p><ul>"  
if not is_alert_number_mode:  
    summary_section += f"<li>Total alerts detected: {total_alerts_detected}</li>"  
summary_section += f"<li>Total alerts processed: {total_alerts_processed}</li>"  
if total_alerts_skipped > 0:  
    summary_section += f"<li>Total alerts skipped: {total_alerts_skipped}</li>"  
summary_section += "</ul>"  
if total_alerts_skipped > 0:  
    summary_section += "<p>For skipped alert details check attached file.</p>"  
branches_section += summary_section  
  
formatter.update_context({    
    "branches_section": branches_section,  
    "notification_message": notification_message  
})    
   
has_fp = len(all_detected_fp) > 0    
has_prs = len(all_created_prs) > 0    
    
if has_fp or has_prs:    
    send_email = True    
else:    
    send_email = send_no_alert_email   
  
if total_alerts_skipped > 0:    
    FunctionLibrary.write_skipped_alerts_to_file(all_skipped_alert_numbers, alert_process_limit)    
    attachments = ['skipped_alerts.txt']    
  
if send_email is True:    
    email_context = {    
        "owner": owner,    
        "repo": repo,    
        "date_sentence": all_branch_results[0].get("date_sentence", "") if all_branch_results else "",    
        "branch": branches_str,  
        "notification_message": notification_message  
    }    
    formatter.update_context(email_context)  
    email_body = formatter.format("email_body")      
    email_subject = formatter.format("email_subject")   
    email_subject += f" - {trigger_source}"   
    email_recipients = formatter.format("email_recipients")      
    email = FunctionLibrary.send_email(      
        email_server,      
        email_port,      
        email_sender,      
        email_subject,      
        email_body,      
        email_recipients,  
        attachments=attachments  
    )    
    print("Email sent")  
  
print("SEND_EMAIL PHASE END")    
#[END_PHASE]    
    
#[PHASE: override_test]    
print("This should be overrided")    
#[END_PHASE]  
