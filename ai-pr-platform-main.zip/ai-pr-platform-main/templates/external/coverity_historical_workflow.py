import os
import re
from datetime import datetime, timezone
from utils.cid_utils import get_cids, validate_cids_against_project, get_coverity_server_for_project

#[PHASE: pre_process]
formatter_context = {}
formatter = Formatter("coverity_historical_templates", team_name, formatter_context)

git_environment = formatter.format("git_environment")
coverity_historical_environment = formatter.format("coverity_historical_environment")

# Use input parameters if provided, otherwise fall back to template values
owner = globals().get('owner', formatter.format("owner"))
repo = globals().get('repo', formatter.format("repo"))
projects_str = globals().get('projects', formatter.format("projects"))
branches_str = globals().get('base_branch', formatter.format("base_branch"))

ticket_ids_str = formatter.format("ticket_id")
git_blame = formatter.format("git_blame")
service_accounts = formatter.format("service_accounts")
email_server = formatter.format("email_server")
email_port = formatter.format("email_port")
email_sender = formatter.format("email_sender")
send_no_alert_email = formatter.format("send_no_alert_email")
draft_pr = formatter.format("draft_pr")
include_explanation = formatter.format("include_explanation")
pr_platform = formatter.format("pr_platform")
branch_delete = formatter.format("branch_delete")
cid_process_limit = formatter.format("cid_process_limit")
is_aecg = formatter.format("is_aecg")
is_xhd = formatter.format("is_xhd")
return_diff = formatter.format("return_diff")
get_file_information = formatter.format("get_file_information")
issue_type = globals().get('issue_type', None)
trigger_event = globals().get('trigger_event')
if trigger_event == "workflow_dispatch":
    trigger_source = "On-demand"
else:
    trigger_source = "Scheduled"

if git_environment == "enterprise":
    github_instance = "on-prem"
else:
    github_instance = "EMU"

github_api = SpecificAPI("github", environment=git_environment)
coverity_historical_api = SpecificAPI("coverity_historical", environment=coverity_historical_environment)
graphql_api = SpecificAPI("graphql", environment=git_environment)

projects = [p.strip() for p in projects_str.split(',')]
branches = [b.strip() for b in branches_str.split(',')]
ticket_ids = [t.strip() for t in ticket_ids_str.split(',')]

cid_numbers = globals().get('cid_numbers', None)
if cid_numbers and isinstance(cid_numbers, str):
    cid_numbers = FunctionLibrary.expand_alert_numbers(cid_numbers)
else:
    skipped_cid_numbers = []
is_cid_number_mode = bool(cid_numbers)

if len(ticket_ids) == 1:
    ticket_ids = ticket_ids * len(projects)

#[END_PHASE]

#[PHASE: get_CIDs]
notification_message = ""
all_skipped_cid_numbers = []  # Global tracker for all skipped CIDs
all_invalid_cid_numbers = []  # Global tracker for all invalid CIDs

# Collect results for all projects
all_project_results = []
for idx, project in enumerate(projects):
    ticket_id = ticket_ids[idx] if idx < len(ticket_ids) else ticket_ids[-1]
    formatter.update_context({"project": project, "ticket_id": ticket_id})
    print(f"=== Processing project: {project} ===")
    results = []

    if cid_numbers:
        # If CIDs are provided, validate them against the project first
        project_cid_numbers = cid_numbers.copy()

        # Get the appropriate Coverity server for this project
        coverity_server = get_coverity_server_for_project(project)
        print(f"Using Coverity server: {coverity_server} for project: {project}")

        # Validate CIDs against the project
        print(f"Validating {len(project_cid_numbers)} CIDs against project '{project}'...")
        valid_cids, invalid_cids = validate_cids_against_project(coverity_server, project, project_cid_numbers)

        if invalid_cids:
            print(f"Warning: The following CIDs do not exist in project '{project}': {invalid_cids}")
            all_invalid_cid_numbers.extend(invalid_cids)  # Add to global tracker

        print(f"Valid CIDs for project '{project}': {valid_cids}")

        # Use only valid CIDs
        project_cid_numbers = valid_cids

        if len(project_cid_numbers) > cid_process_limit:
            branch_skipped_cid_numbers = project_cid_numbers[cid_process_limit:]
            project_cid_numbers = project_cid_numbers[:cid_process_limit]
            all_skipped_cid_numbers.extend(branch_skipped_cid_numbers)  # Add to global tracker
        else:
            branch_skipped_cid_numbers = []

        date_sentence = f"<p>The following summarizes the result of Coverity Historical Fix Generation for CIDs {project_cid_numbers}:</p>"
        project_total_detected = len(project_cid_numbers)
    else:
        from_date = globals().get('from_date', None)
        to_date = globals().get('to_date', None)

        if from_date and to_date:
            print(f"Fetching CIDs from Coverity Server for project {project}, from {from_date} to {to_date}")
            from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
            readable_from_date = from_date_dt.strftime("%B %d, %Y")
            to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
            readable_to_date = to_date_dt.strftime("%B %d, %Y")
            date_sentence = f"<p>The following summarizes the results of Coverity Historical Fix Generation for CIDs in project {project} created from {readable_from_date} to {readable_to_date}:</p>"
        elif from_date:
            print(f"Fetching CIDs from Coverity Server for project {project} from {from_date} to now {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
            from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
            readable_from_date = from_date_dt.strftime("%B %d, %Y")
            readable_to_date = datetime.now(timezone.utc).strftime("%B %d, %Y")
            date_sentence = f"<p>The following summarizes the results of Coverity Historical Fix Generation for CIDs in project {project} created from {readable_from_date} to {readable_to_date}:</p>"
        elif to_date:
            print(f"Fetching CIDs from Coverity Server for project {project} up to {to_date}")
            to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
            readable_to_date = to_date_dt.strftime("%B %d, %Y")
            date_sentence = f"<p>The following summarizes the results of Coverity Historical Fix Generation for CIDs in project {project} created up to {readable_to_date}:</p>"
        else:
            print("No date range specified, filtering not applied")
            date_sentence = "<p></p>"

        # Get the appropriate Coverity server for this project
        coverity_server = get_coverity_server_for_project(project)

        # Convert ISO dates to YYYY-MM-DD format for Coverity API
        if from_date:
            from_date_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
            start_date = from_date_dt.strftime("%Y-%m-%d")
        else:
            start_date = "2020-01-01"  # Default start date if not provided

        if to_date:
            to_date_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
            end_date = to_date_dt.strftime("%Y-%m-%d")
        else:
            end_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        # Fetch CIDs from Coverity server
        print(f"Fetching CIDs from Coverity server {coverity_server} for project {project}")
        if issue_type:
            print(f"Filtering by issue type: {issue_type}")
        project_cid_numbers = get_cids(
            server=coverity_server,
            project_name=project,
            start_date=start_date,
            end_date=end_date,
            number_of_issues=cid_process_limit,
            issue_type=issue_type
        )

        print(f"Project CIDs: {project_cid_numbers}")
        project_total_detected = len(project_cid_numbers)

        if len(project_cid_numbers) > cid_process_limit:
            project_skipped_cid_numbers = project_cid_numbers[cid_process_limit:]
            project_cid_numbers = project_cid_numbers[:cid_process_limit]
            all_skipped_cid_numbers.extend(project_skipped_cid_numbers)
        else:
            project_skipped_cid_numbers = []

        print(f"Project CIDs after filtering: {project_cid_numbers}")

    for cid in project_cid_numbers:
        print(f"Processing CID {cid}")

        #[PHASE: process_CIDs]
        result = {
            'cid_number': cid,
            'url': f"Coverity CID: {cid}",  # Placeholder URL
            'pr_url': None,
            'branch_name': None
        }

        print(f"Calling Coverity Historical API for CID {result['cid_number']}")

        fix = coverity_historical_api.make_request(
            "coverity_historical",
            cid=result['cid_number'],
            is_aecg=is_aecg,
            is_xhd=is_xhd,
            return_diff=return_diff,
            get_file_information=get_file_information,
            include_explanation=include_explanation
        )

        print(f"Fix: {fix}")

        # Get the file path from the API response
        file_path = fix.get('file_path', '')
        print(f"Original file path from API: {file_path}")
        if not file_path:
            print(f"No file path provided for CID {cid}, skipping")
            continue

        # Extract the correct file path using team-specific pattern
        # This handles cases where Coverity returns full Jenkins workspace paths
        # but we need only the relative path for GitHub operations
        path_extraction_pattern = formatter.format("path_extraction_pattern")
        original_file_path = file_path
        if path_extraction_pattern:
            import re
            match = re.search(path_extraction_pattern, file_path)
            if match:
                file_path = match.group(0)
                print(f"Extracted file path using pattern '{path_extraction_pattern}': {file_path}")
            else:
                print(f"Warning: Could not extract file path using pattern '{path_extraction_pattern}' from '{original_file_path}'")
                print(f"Using original file path: {file_path}")
        else:
            print(f"No path extraction pattern configured, using original file path: {file_path}")

        # Get the current file content from the specified branch
        base_branch = branches[0] if branches else "main"
        try:
            original_file = FunctionLibrary.base64_decode(
                github_api.make_request(
                    "get_file_content",
                    repo_name=repo,
                    repo_owner=owner,
                    branch_sha=base_branch,
                    file_path=file_path
                )
            )
        except RuntimeError as e:
            print(f"Could not get file content for {file_path} on branch {base_branch}: {e}")
            continue

        # Extract explanation and fix content from the API response
        fix_content = fix.get('fix', '')
        explanation = fix.get('explanation', '')

        print(f"Extracted explanation: {explanation}")
        print(f"Fix content: {fix_content[:200]}...")

        # Clean up the diff content - remove the ```diff wrapper
        if fix_content.startswith("```diff"):
            fix_content = fix_content[7:]
        if fix_content.endswith("```"):
            fix_content = fix_content[:-3]

        print(f"Cleaned diff content: {fix_content[:200]}...")  # Show first 200 chars

        # Check if the diff paths match our extracted file path
        if "diff --git" in fix_content:
            diff_lines = fix_content.split('\n')
            for line in diff_lines:
                if line.startswith("diff --git") or line.startswith("---") or line.startswith("+++"):
                    print(f"Diff path line: {line}")
                    # Check if the diff path contains our extracted file path
                    if file_path in line:
                        print(f"✓ Diff path matches extracted file path: {file_path}")
                    else:
                        print(f"⚠ Diff path may not match extracted file path: {file_path}")
                    break

        # Test diff application using the same pattern as codeporting workflow
        try:
            #corrected_file = FunctionLibrary.apply_diff_to_file(
            corrected_file = FunctionLibrary.apply_unified_diff_to_content(
                original_file=original_file,
                file_name=file_path,
                code_diff=fix_content
            )
            print(f"✓ Diff applied successfully")
        except Exception as e:
            print(f"✗ Error applying diff: {e}")
            # Try alternative diff application method from codeporting workflow
            try:
                diff_applied, corrected_file = FunctionLibrary.apply_unified_diff_to_content(original_file, fix_content)
                if diff_applied:
                    print(f"✓ Diff applied successfully using alternative method")
                else:
                    print(f"✗ Alternative diff application failed")
                    continue
            except Exception as e2:
                print(f"✗ Both diff application methods failed: {e2}")
                continue

        # Encode updated file
        encoded_content = FunctionLibrary.base64_encode(corrected_file)

        # Check if the file content actually changed
        if corrected_file == original_file:
            print(f"WARNING: File content unchanged after applying diff for CID {cid}. Skipping PR creation.")
            continue

        print(f"File content changed successfully for CID {cid}")
        print(f"Original file length: {len(original_file)}")
        print(f"Corrected file length: {len(corrected_file)}")

        # Show a sample of the differences
        original_lines = original_file.split('\n')
        corrected_lines = corrected_file.split('\n')
        print(f"Original file has {len(original_lines)} lines")
        print(f"Corrected file has {len(corrected_lines)} lines")

        #[END_PHASE]
        #[PHASE: formatting]

        formatter.update_context({
            "owner": owner,
            "repo": repo,
            "project": project,
            "branch": branches[0] if branches else "main",  # Use first branch for PR creation
            "CID": result['cid_number'],  # Use CID instead of alert_number
            "rule_header": f"Coverity Historical Fix for CID {result['cid_number']}",
            "root_folder": (os.path.normpath(file_path)).split(os.path.sep)[0] if file_path else "",
            "rule_description": f"Coverity Historical fix for CID {result['cid_number']}",
            "alert_severity": "N/A",  # Coverity doesn't provide severity in this context
            "alert_description": f"Coverity Historical issue for CID {result['cid_number']}",
            "alert_url": result['url'],
            "fix_explanation": explanation,
            "signoff_user": github_api.make_request("get_user_details")[0],
            "signoff_email": github_api.make_request("get_user_details")[1],
            "ticket_id": ticket_id,
            "date_sentence": date_sentence
        })

        generated_branch_name = formatter.format("generate_branch_name")
        generated_branch_name = generated_branch_name.lower()
        generated_commit_header = formatter.format("generate_commit_header")
        generated_commit_description = formatter.format("generate_commit_description")
        generated_commit_message = generated_commit_header + "\n\n" + generated_commit_description
        generated_pr_title = formatter.format("generate_pr_title")
        generated_pr_description = formatter.format("generate_pr_description")
        sign_off_message = formatter.format("sign_off_message")

        if sign_off_message:
            generated_commit_message += f"\n\n{sign_off_message}"

        result['branch_name'] = generated_branch_name

        #[END_PHASE]

        #[PHASE: create_branch_and_pr]

        # Get the base commit SHA for branch creation
        print(f"Getting base commit SHA for branch: {base_branch}")
        try:
            base_commit_sha = github_api.make_request(
                "get_latest_commit_sha",
                repo_owner=owner,
                repo_name=repo,
                base_branch=base_branch
            )
            if not base_commit_sha:
                print(f"WARNING: Could not get base commit SHA for {base_branch}. Skipping PR creation.")
                continue
            print(f"Base commit SHA for {base_branch}: {base_commit_sha}")
        except Exception as e:
            print(f"WARNING: Error getting base commit SHA: {str(e)}. Skipping PR creation.")
            continue

        try:
            branch_exists = github_api.make_request(
                "check_existing_branch",
                repo_name=repo,
                repo_owner=owner,
                branch_name=generated_branch_name
            )
            print(branch_exists)
            print(f"Branch '{generated_branch_name}' already exists")

            if branch_delete:
                print(f"Deleting existing branch with name '{generated_branch_name}'")
                try:
                    delete_branch = github_api.make_request(
                        "delete_existing_branch",
                        repo_name=repo,
                        repo_owner=owner,
                        branch_name=generated_branch_name
                    )
                    print("Deleting existing branch")
                except RuntimeError as e:
                    if "422" in str(e):
                        print(f"Existing branch '{generated_branch_name}' deleted")
                        print(f"Branch '{generated_branch_name}' does not exist, creating branch")
                        create_branch_response = github_api.make_request(
                            "create_branch",
                            repo_name=repo,
                            repo_owner=owner,
                            ref=f"refs/heads/{generated_branch_name}",
                            sha=base_commit_sha
                        )
                        print(create_branch_response)
                    else:
                        raise
            else:
                generated_branch_name = generated_branch_name + '_2'
                create_branch_response = github_api.make_request(
                    "create_branch",
                    repo_name=repo,
                    repo_owner=owner,
                    ref=f"refs/heads/{generated_branch_name}",
                    sha=base_commit_sha
                )
                print(f"Creating branch with modified name: {generated_branch_name}")

        except RuntimeError as e:
            if "404" in str(e):
                print(f"Branch '{generated_branch_name}' does not exist, creating branch")
                create_branch_response = github_api.make_request(
                    "create_branch",
                    repo_name=repo,
                    repo_owner=owner,
                    ref=f"refs/heads/{generated_branch_name}",
                    sha=base_commit_sha
                )
                print(create_branch_response)
            else:
                raise

        try:
            file_sha = github_api.make_request(
                "check_file_sha",
                repo_name=repo,
                repo_owner=owner,
                new_branch=generated_branch_name,
                file_path=file_path
            )
        except RuntimeError as e:
            if "404" in str(e):
                print(f"File '{file_path}' does not exist")
                file_sha = None

        if file_sha:
            try:
                response = github_api.make_request(
                    "update_existing_file",
                    repo_name=repo,
                    repo_owner=owner,
                    file_path=file_path,
                    message=generated_commit_message,
                    content=encoded_content,
                    branch=generated_branch_name,
                    sha=file_sha
                )
                print(f"Updating existing file '{file_path}'")
            except RuntimeError as e:
                if "409" in str(e):
                    print(f"WARNING: 409 Conflict - file content unchanged for '{file_path}'. Skipping PR creation.")
                    continue
                else:
                    raise
        else:
            response = github_api.make_request(
                "create_new_file",
                repo_name=repo,
                repo_owner=owner,
                file_path=file_path,
                message=generated_commit_message,
                content=encoded_content,
                branch=generated_branch_name
            )
            print(f"Creating file '{file_path}'")

        result['branch_name'] = generated_branch_name

        pr_url = github_api.make_request(
            "create_pull_request",
            repo_name=repo,
            repo_owner=owner,
            title=generated_pr_title,
            body=generated_pr_description,
            head=generated_branch_name,
            base=branches[0] if branches else "main",  # Use first branch for PR creation
            draft=draft_pr
        )
        print(f"PR title: {generated_pr_title}")
        result['pr_url'] = pr_url
        pr_number = re.search(r'/pull/(\d+)', pr_url).group(1)

        label_list = formatter.format("label_list")
        reviewer_list = formatter.format("reviewer_list")
        label_list = [label.strip() for label in label_list.split(',') if label.strip()]
        reviewer_list = [reviewer.strip() for reviewer in reviewer_list.split(',') if reviewer.strip()]
        print(f"Labels: {label_list}")
        print(f"Reviewers: {reviewer_list}")

        if pr_url is not None and label_list:
            print(f"Adding labels to PR: {pr_url}")
            add_labels = github_api.make_request(
                "add_labels_to_pr",
                repo_name=repo,
                repo_owner=owner,
                pr_number=pr_number,
                labels=label_list
            )
            print("Labels added")

        if pr_url is not None and reviewer_list and len(reviewer_list) > 0:
            if '#last_committer' in reviewer_list:
                last_committer = github_api.make_request(
                    "get_last_committer",
                    repo_name=repo,
                    repo_owner=owner,
                    branch=branches[0] if branches else "main",  # Use first branch for PR creation
                    file_path=file_path
                )
                if last_committer:
                    # Find the index of the element containing '#last_committer'
                    for i, reviewer in enumerate(reviewer_list):
                        if '#last_committer' in reviewer:
                          # If last_committer is a list, use its first element
                          last_committer_str = last_committer[0] if isinstance(last_committer, list) else last_committer
                          # Replace the placeholder with the actual value
                          reviewer_list[i] = reviewer.replace('#last_committer', last_committer_str)
                    print(f"Replaced '#last_committer' in reviewers list with {last_committer}.")
                else:
                    # Remove '#last_committer' from the elements
                    for i, reviewer in enumerate(reviewer_list):
                        if '#last_committer' in reviewer:
                            reviewer_list[i] = reviewer.replace('#last_committer', '')

            # Final validation to ensure no empty reviewers
            final_reviewers = [r for r in reviewer_list if r and r.strip()]
            if final_reviewers:
                add_reviewer = github_api.make_request(
                    "add_reviewers_to_pr",
                    repo_name=repo,
                    repo_owner=owner,
                    pr_number=pr_number,
                    reviewers=final_reviewers
                )
                print(f"Adding reviewers {final_reviewers} to PR: {pr_url}")
            else:
                print("No valid reviewers to add")

        results.append(result)

    #[END_PHASE]

    #[END_PHASE]

    project_has_results = len(results) > 0

    if (not is_cid_number_mode) or (is_cid_number_mode and project_has_results):
        all_project_results.append({
            "project": project,
            "results": results,
            "date_sentence": date_sentence,
            "not_found_cids": invalid_cids if cid_numbers else [],  # Invalid CIDs for this project
            "total_detected": project_total_detected
        })

#[PHASE: send_email]

all_created_prs = []
attachments = None

# Collect all data for better organization
all_project_data = []
all_created_prs = []
all_invalid_cids = []

for project_result in all_project_results:
    project = project_result["project"]
    results = project_result["results"]
    date_sentence = project_result.get("date_sentence", "")
    not_found_cids = project_result.get("not_found_cids", [])
    created_prs = [result for result in results if result['pr_url']]

    all_created_prs.extend(created_prs)
    all_invalid_cids.extend(not_found_cids)

    project_data = {
        "project": project,
        "created_prs": created_prs,
        "not_found_cids": not_found_cids
    }
    all_project_data.append(project_data)

# Build the main content section
main_content = ""

# 1. Created PRs section (if any)
if all_created_prs:
    main_content += "<h3>Created Pull Requests:</h3>"
    for project_data in all_project_data:
        if project_data["created_prs"]:
            main_content += f"<p><b>Project: {project_data['project']}</b></p>"
            pr_list = "<ul>" + "".join([
                f"<li>For CID {pr['cid_number']}: <a href='{pr['pr_url']}'>{pr['pr_url']}</a></li>"
                for pr in project_data["created_prs"]
            ]) + "</ul>"
            main_content += pr_list
else:
    main_content += "<h3>Created Pull Requests:</h3><p>None</p>"

# 2. Invalid CIDs section (if any) - only show once
if all_invalid_cids:
    main_content += "<h3>Invalid CIDs (not found in specified projects):</h3>"
    invalid_cids_list = "<ul>" + "".join([
        f"<li>{cid}</li>" for cid in all_invalid_cids
    ]) + "</ul>"
    main_content += invalid_cids_list

# Calculate summary statistics
total_cids_detected = 0
for project_result in all_project_results:
    total_cids_detected += project_result.get("total_detected", len(project_result["results"]))

total_cids_processed = len(all_created_prs)
if is_cid_number_mode:
    total_cids_skipped = len(all_skipped_cid_numbers)
else:
    total_cids_skipped = len(all_skipped_cid_numbers) if all_skipped_cid_numbers else 0

total_cids_invalid = len(all_invalid_cid_numbers)

# Build summary section
summary_section = "<h3>Summary:</h3><ul>"
if not is_cid_number_mode:
    summary_section += f"<li>Total CIDs detected: {total_cids_detected}</li>"
summary_section += f"<li>Total CIDs processed: {total_cids_processed}</li>"
if total_cids_skipped > 0:
    summary_section += f"<li>Total CIDs skipped: {total_cids_skipped}</li>"
if total_cids_invalid > 0:
    summary_section += f"<li>Total CIDs invalid: {total_cids_invalid}</li>"
summary_section += "</ul>"

if total_cids_skipped > 0:
    summary_section += "<p><i>For skipped CID details check attached file.</i></p>"

# Combine main content with summary
projects_section = main_content + "<br>" + summary_section

formatter.update_context({
    "projects_section": projects_section,
    "notification_message": ""  # Clear notification message since we handle invalid CIDs in main content
})

has_prs = len(all_created_prs) > 0

if has_prs:
    send_email = True
else:
    send_email = send_no_alert_email

if total_cids_skipped > 0:
    FunctionLibrary.write_skipped_alerts_to_file(all_skipped_cid_numbers, cid_process_limit)
    attachments = ['skipped_cids.txt']

if send_email is True:
    email_context = {
        "owner": owner,
        "repo": repo,
        "date_sentence": all_project_results[0].get("date_sentence", "") if all_project_results else "",
        "projects": projects_str,
        "notification_message": notification_message
    }
    formatter.update_context(email_context)
    email_body = formatter.format("email_body")
    email_subject = formatter.format("email_subject")
    email_subject += f" - {trigger_source}"
    email_recipients = formatter.format("email_recipients")
    email = FunctionLibrary.send_email(
        email_server,
        email_port,
        email_sender,
        email_subject,
        email_body,
        email_recipients,
        attachments=attachments
    )
    print("Email sent")

#[END_PHASE]
