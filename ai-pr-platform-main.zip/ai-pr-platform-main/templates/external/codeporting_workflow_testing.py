#[PHASE: pre_process]
formatter_context = {}      
formatter = Formatter("code_porting_templates", team_name, formatter_context)

git_environment = formatter.format("git_environment")  
code_porting_environment = formatter.format("code_porting_environment")  
owner = formatter.format("owner")    
repo = formatter.format("repo")
check_components = formatter.format("check_components") 
#fallback_ticket_id = formatter.format("fallback_ticket_id")
draft_pr = formatter.format("draft_pr") 

github_api = SpecificAPI("github", environment=git_environment)    
code_porting_api = SpecificAPI("code_porting", environment=code_porting_environment)   
commit_id = globals().get('commit_id', None) 
source_branch_override = globals().get('source_branch', None)
if source_branch_override:
    source_branch = source_branch_override
else:
    source_branch = formatter.format('source_branch')
target_branch_override = globals().get('target_branch', None)
if target_branch_override:
    target_branch = target_branch_override
else:
    target_branch = formatter.format('target_branch')
source_branches = [branch.strip() for branch in source_branch.split(',')] 
target_branches = [branch.strip() for branch in target_branch.split(',')]
from_date = globals().get('from_date', None)
reviewer_list = formatter.format("reviewer_list")
reviewer_list = [reviewer.strip() for reviewer in reviewer_list.split(',')]
label_list = formatter.format("label_list")     
label_list = [label.strip() for label in label_list.split(',')]    

print("DEBUG:pre-process phase end")##################
#[END_PHASE]    
    
#[PHASE: get_commits] 
print("DEBUG:get_commits phase start")###################
results = []
if commit_id:
    try:
        print(f"Fetching commit {commit_id} from {owner}/{repo}/commits/{commit_id}")
        commit = github_api.make_request(
            "get_commit_by_id",
            repo_name=repo,    
            repo_owner=owner,
            commit_id=commit_id
            )
        print("DEBUG:get_commit_by_id response")####################
        print(commit)###############
        if not commit:
            print(f"WARNING: Commit {commit_id} found but returned empty data.")
            commit_list = []
        else:
            commit_list = [commit]
    except Exception as e:
        print(f"Error occured while fetching commit {commit_id}: {str(e)}")

    #commit_list = [commit] if commit else []
else:
    commit_list = []
    for source_branch_name in source_branches:
        try:
            print(f"Fetching commits for owner: {owner}, repo: {repo}, branch: {source_branch_name}, from date: {from_date}")
            branch_commits = github_api.make_request(
                "get_new_commits",
                repo_name=repo,
                repo_owner=owner,
                branch_name=source_branch_name, 
                from_date=from_date
            )
            if branch_commits:
                commit_list.extend(branch_commits)
                print(f"Found {len(branch_commits)} commits for branch {source_branch_name}")
            else:
                print(f"WARNING: No commits_found for branch {source_branch_name}")
            print("DEBUG:get_new_commits response")######################
            print(commit_list)###################
        except Exception as e:
            print(f"Error occured while fetching commits for branch {source_branch_name}: {str(e)}")

if not commit_list:
    print(f"WARNING: No commits found after {from_date} for {owner}/{repo} in branch {source_branch}")
    print(f"Exiting script")
    sys.exit(0)
print("DEBUG:get_commits phase end")#####################
#[END_PHASE] 

#[PHASE: process_commits]
print("DEBUG:process_commit phase start")##########################

print("DEBUG:commit_list loop started")#####################
for commit in commit_list:
    commit_id_sha = commit['sha']
    if not commit_id_sha:
        print(f"WARNING: Commit missing SHA. Skipping commit.")
    commit_id = commit['sha'][:7]
    result = {
        'commit_id': commit_id, 
        'commit_url': commit['html_url'],
        'prs': [],
        'status': None,
        'reason': None,
        'files': []
    }
    print(f"DEBUG: result for {commit} from commit_list")#######################
    print(result)######################

    commit_author_login = commit['author']['login'] if commit.get('author') else 'Unknown'
    print("DEBUG:commit_author_login")#################
    print(commit_author_login)#####################
    ###OVERRIDE FOR TESTING
    commit_author_login = "imirosav_amdeng" ################
    
    if commit_author_login not in reviewer_list:
        if reviewer_list:
            reviewer_list.append(commit_author_login)
        else:
            reviewer_list = commit_author_login
    print("DEBUG:reviewer_list")##################
    print(reviewer_list)######################
    
    for target_branch_name in target_branches:
        result = {
            'commit_id': commit_id_sha,
            'commit_url': f"https://github.com/{owner}/{repo}/commit/{commit_id_sha}",
            'prs': [],
            'status': None,
            'reason': None,
            'files': []
        }
        try:
            # 1. Call the CodePorting API
            try:
                print("DEBUG:code_porting request - target_branch")############################
                code_porting_result = code_porting_api.make_request(
                    "code_porting",
                    commit_id=commit_id_sha,
                    target_branch=target_branch_name,
                    repo_name=f"{owner}/{repo}",
                    check_components=check_components
                    )
                print("DEBUG:code_porting response - code_porting_result")####################
                print(code_porting_result)##########################
                if not code_porting_result:
                    print(f"WARNING: Empty response from code_porting API for commit {commit_id}. Skipping.")
                    continue
            except requests.exceptions.Timeout:
                print(f"Timeout occured for commit {commit_id}. Skipping to next commit.")
                result['status'] = 'Error'
                result['reason'] = 'Timeout occured while calling the CodePorting API'
                results.append(result)
                continue
            
            if not source_branch:
                source_branch = code_porting_result.get('source_branch', 'Unknown')
                if source_branch == "Unknown":
                    print(f"WARNING: Could not determine source branch from API response.")

            ticket_id = code_porting_result.get('ticket', 'Unknown')
            if ticket_id == "Unknown":
                print(f"WARNING: Could not extract ticket ID from API response.")
            print("DEBUG:ticket_id - extracted from code_porting_result")#################
            print(ticket_id)######################
            
            # 2. If commit wasn't processed at all
            print("DEBUG: not processed commits check")#####################
            if code_porting_result.get('commit_processed') == "No":
                print(f"Code porting fix not applied for commit: {commit_id}, reason: {code_porting_result['processing_reason']}")
                result['status'] = 'Not Applied'
                result['reason'] = code_porting_result.get('processing_reason', 'Unknown reason')
                results.append(result)
                continue
            
            # 3. Group files by destination branch first
            print("DEBUG:files grouping by destination")#####################
            grouped_files = defaultdict(list)
            for file in code_porting_result['files']:
                destination = file['destination_branch']
                grouped_files[destination].append(file)
            
            # For each desitnation branch, check for any files require porting
            pr_list = []
            print("DEBUG:check if files need porting, by destination")###########################
            for destination_branch, files_group in grouped_files.items():
                # Stop at first file that doesn't require porting and skip the rest
                print(f"DEBUG: {destination_branch} - {files_group} in grouped_files")######################
                first_non_portable_file = None
                changes_to_apply = []

                for f in files_group:
                    print(f"DEBUG: {f} from file_group")########################
                    if f['decision'].lower() == "porting is required":
                        changes_to_apply.append(f)
                    else:
                        first_non_portable_file = f
                        break
                
                # If non portable file is found, skip PR creation for branch
                if first_non_portable_file:
                    print(f"No changes to apply for branch {destination_branch} on commit {commit_id} "
                        f"- Skipping porting because file '{first_non_portable_file['file_name']}' cannot be ported.")
                    reason_text = f"File {first_non_portable_file['file_name']}: {first_non_portable_file['reason']}"
                    branch_no_change_result = {
                        'destination_branch': destination_branch, 
                        'branch_name': "No Branch",
                        'pr_url': None, 
                        'status': 'No Changes',
                        'reason': reason_text
                    }
                    pr_list.append(branch_no_change_result)
                    print("DEBUG:non portable files check")######################
                    print(branch_no_change_result)#########################
                    continue
                
                # If no changes apply for branch, record it and skip PR creation
                if not changes_to_apply:
                    print(f"No changes to apply for branch {destination_branch} on commit {commit_id}")
                    reason_text = "No changes required."
                    branch_no_change_result = {
                        'destination_branch': destination_branch,
                        'branch_name': 'No Branch',
                        'pr_url': None, 
                        'status': 'No Changes',
                        'reason': reason_text
                    }
                    pr_list.append(branch_no_change_result)
                    continue
                
                #[PHASE: create_branch_and_pr]
                print("DEBUG:create_branch_and_pr_phase start")##############
                
                # Create and commit changes for branch
                print(f"Processing files for destination branch: {destination_branch}")
                try:
                    base_commit_sha = github_api.make_request(
                        "get_latest_commit_sha",
                        repo_owner=owner, 
                        repo_name=repo, 
                        base_branch=destination_branch
                        )
                    if not base_commit_sha:
                        print(f"WARNING: Could not get base commit SHA for {destination_branch}. Skipping PR creation.")
                        continue
                    print(f"Base commit SHA for {destination_branch}: {base_commit_sha}")
                except Exception as e:
                    print(f"WARNING: Error getting base commit SHA: {str(e)}. Skipping PR creation.")

                # New branch creation
                sanitized_dest = destination_branch.replace('/', '-')
                print(f"DEBUG:sanitized_dest - {sanitized_dest}")####################
                print(f"DEBUG:ticket_id - {ticket_id}")####################
                print(f"DEBUG:commit_id - {commit_id}")####################
                print(f"DEBUG:destination_branch - {destination_branch}")####################
                print(f"DEBUG:commit - {commit}")####################
                formatter.update_context({"sanitized_dest": sanitized_dest, "ticket_id": ticket_id, "commit_id": commit_id, "destination_branch": destination_branch, "commit": commit})
                generated_branch_name = formatter.format("generate_branch_name")
                print(f"Creating branch: {generated_branch_name} from commit: {base_commit_sha}")
                try:
                    create_branch_response = github_api.make_request(    
                        "create_branch",    
                        repo_name=repo,    
                        repo_owner=owner,    
                        ref=f"refs/heads/{generated_branch_name}",    
                        sha=base_commit_sha    
                        ) 
                    if not create_branch_response:
                        print(f"WARNING: Failed to create branch {generated_branch_name}. Skipping PR creation.")
                except requests.exceptions.HTTPError as http_err:
                    print(f"WARNING: HTTP error occured while creating branch: {http_err}")
                    raise
                except Exception as e:
                    print(f"WARNING: An error occured while creating branch: {e}")
                    raise
                
                corrected_files = {}
                failed_files = []

                # Apply porting changes
                for file in changes_to_apply:
                    print(f"Applying code porting fix for file: {file['file_name']} -> {destination_branch}")
                    try:
                        original_file = FunctionLibrary.base64_decode(    
                            github_api.make_request(    
                                "get_file_content",    
                                repo_name=repo,    
                                repo_owner=owner,    
                                branch_sha=base_commit_sha,    
                                file_path=file['file_name']  
                            )    
                        )
                    except Exception as e:
                        error_message = f"Failed to get original file: {e}"
                        failed_files.append({'file_name': file['file_name'], 'error': error_message})
                        continue

                    try:
                        diff_applied, corrected_file = FunctionLibrary.apply_unified_diff_to_content(original_file, file['code_change'])
                    except Exception as e:
                        error_message = f"Failed to apply diff: {e}"
                        failed_files.append({'file_name': file['file_name'], 'error': error_message})
                        continue

                    file_result = {
                        'file_name': file['file_name'],
                        'decision': file['decision'],
                        'reason': file['reason'],
                        'confidence_level': file.get('confidence_level', 'N/A'),
                        'change_applied': diff_applied,
                        'error': None if diff_applied else "Failed to apply diff."
                    }
                    result['files'].append(file_result)

                    if diff_applied:
                        corrected_files[file['file_name']] = corrected_file
                    else:
                        failed_files.append({'file_name': file['file_name'], 'error': "Failed to apply diff."})
                    
                # If any failures, skip PR creation
                if failed_files:
                    print(f"errors occured for branch: {generated_branch_name}, skipping PR creation.")
                    reason_details = "; ".join([f"{f['file_name']}: {f['error']}" for f in failed_files])
                    pr_entry = {
                        'destination_branch': destination_branch,
                        'branch_name': generated_branch_name,
                        'pr_url': None,
                        'status': 'Failed to create PR',
                        'reason': reason_details
                    }
                    pr_list.append(pr_entry)
                    continue
                
                #Commit successfully updated files
                for file_name, content in corrected_files.items():
                    original_message = commit['commit']['message']
                    lines = original_message.split('\n\n', 1)
                    header = lines[0].strip()
                    body = lines[1].strip() if len(lines) > 1 else ''
                    file = os.path.basename(file_name)
                    formatter.update_context({"commit_header": header, "commit_body": body, "file": file})
                    generated_commit_header = formatter.format("generate_commit_header")
                    generated_commit_description = formatter.format("generate_commit_description")
                    generated_commit_message = generated_commit_header + generated_commit_description

                    encoded_content = FunctionLibrary.base64_encode(content)
                    # If file exist update, if not create file
                    try:    
                        file_sha = github_api.make_request(    
                            "check_file_sha",    
                            repo_name=repo,    
                            repo_owner=owner,    
                            new_branch=generated_branch_name,    
                            file_path=file_name    
                        )    
                    except RuntimeError as e:    
                        if "404" in str(e):    
                            print(f"File '{file_name}' does not exist")    
                            file_sha = None    
        
                    if file_sha:    
                        response = github_api.make_request(    
                            "update_existing_file",    
                            repo_name=repo,    
                            repo_owner=owner,    
                            file_path=file_name,    
                            message=generated_commit_message,    
                            content=encoded_content,    
                            branch=generated_branch_name,    
                            sha=file_sha    
                        )    
                        print(f"Updating existing file '{file_name}'")    
                    else:    
                        response = github_api.make_request(    
                            "create_new_file",    
                            repo_name=repo,    
                            repo_owner=owner,    
                            file_path=file_name,    
                            message=generated_commit_message,    
                            content=encoded_content,    
                            branch=generated_branch_name    
                        )    
                        print(f"Creating file '{file_name}'")    
                
                #Create PR
                commit_date = datetime.strptime(commit['commit']['author']['date'], "%Y-%m-%dT%H:%M:%SZ")
                formatted_commit_date = commit_date.strftime("%B %d, %Y at %H:%M:%S UTC")
                file_descriptions = []
                for file in files_group:
                    file_desc = (
                        f"**File:** {file['file_name']}\n"
                        f"Decision: {file['decision']}\n"
                        f"Reason: {file['reason']}\n"
                        f"Confidence Level: {file.get('confidence_level', 'N/A')}\n"
                    )
                    file_descriptions.append(file_desc)
                generated_pr_description = (
                    f"This pull request ports changes for the commit {code_porting_result['commit']} made on **{code_porting_result['source_branch']}** "
                    f"created at **{formatted_commit_date}** to **{destination_branch}**\n\n"
                    f"### Commit Description\n {commit['commit']['message']}\n\n"
                    f"### Details of Porting\n" + "\n".join(file_descriptions) + "\n\n"
                    f"> **Disclaimer:** Code provided by the AI tool is to be used for internal reference purposes only and ...."
                )
                generated_pr_title = formatter.format("generate_pr_title")
                pr_url = github_api.make_request(
                    "create_pull_request",    
                    repo_name=repo,    
                    repo_owner=owner,    
                    title=generated_pr_title,    
                    body=generated_pr_description, 
                    base=destination_branch,   
                    head=generated_branch_name,        
                    draft=draft_pr    
                )
                pr_number = re.search(r'/pull/(\d+)', pr_url).group(1)
                if pr_url and label_list:
                    add_labels = github_api.make_request(
                        "add_labels_to_pr",    
                        repo_name=repo,    
                        repo_owner=owner,    
                        pr_number=pr_number,    
                        labels=label_list    
                    )    
                    print("Labels added")
                if pr_url and reviewer_list:
                    add_reviewer = github_api.make_request(
                        "add_reviewers_to_pr",    
                        repo_name=repo,    
                        repo_owner=owner,    
                        pr_number=pr_number,    
                        reviewers=reviewer_list    
                    )    
                    print(f"Adding reviewers {reviewer_list} to PR: {pr_url}")
                
                if pr_url:
                    pr_entry = {
                        'destination_branch': destination_branch,
                        'branch_name': generated_branch_name,
                        'pr_url': pr_url,
                        'status': 'PR created',
                        'reason': None
                    }
                else:
                    pr_entry = {
                        'destination_branch': destination_branch,
                        'branch_name': generated_branch_name,
                        'pr_url': None,
                        'status': 'Failed to create PR',
                        'reason': 'Failed during PR creation.'
                    }
                pr_list.append(pr_entry)
            
                #[END_PHASE] 

            # Determine overall commit status
            if pr_list and all(pr['status'] == 'PR created' or pr['status'] == 'No Changes' for pr in pr_list):
                result['status'] = 'PRs created or No Changes'
            elif any(pr['status'] == 'PR created' for pr in pr_list):
                result['status'] = 'Partial success'
            else:
                # If no PR was created or all failed
                result['status'] = 'Failed or No Changes'
                result['reason'] = 'No successful PR creation for this commit.'
            
            result['prs'] = pr_list
            #results.append(result)
            import copy
            result_copy = copy.deepcopy(result)
            results.append(result_copy)
            print(f"DEBUG:current destination branch '{destination_branch}' result")##############
            print(result)#####################
            print(f"DEBUG:RESULTS after '{destination_branch}' append")#############
            print(results)################
        
        except Exception as e:
            print(f"An error occured while processing commit {commit_id} for target branch {target_branch_name}: {e}")
            result['status'] = 'Error'
            result['reason'] = str(e)
            #results.append(result)
            import copy
            result_copy = copy.deepcopy(result)
            results.append(result_copy)

#[END_PHASE]
print("DEBUG:check results")######################
print(results)
print("DEBUG:check commit_list")#################
print(commit_list)
#[PHASE: prepare_and_send_email]
# After processing all commits, prepare and send email
if commit_list:
    successful_prs = []
    failed_prs = []
    no_changes_grouped = defaultdict(list)
    not_applied = []
    errors = []
    for result in results:
        # Check PR statuses
        for pr in result.get('prs', []):
            if pr['status'] == 'PR created':
                successful_prs.append({
                    'commit_id': result['commit_id'],
                    'commit_url': result['commit_url'],
                    'pr_url': pr['pr_url'],
                    'branch_name': pr['branch_name']
                })
            elif pr['status'] == 'Failed to create PR':
                failed_prs.append({
                    'commit_id': result['commit_id'],
                    'commit_url': result['commit_url'],
                    'branch_name': pr['branch_name'],
                    'reason': pr['reason']
                })
            elif pr['status'] == 'No Changes':
                # Group by branch name in the PR
                destination_branch_info = pr.get('destination_branch', 'No Branch')
                no_changes_grouped[destination_branch_info].append({
                    'commit_id': result['commit_id'],
                    'commit_url': result['commit_url'],
                    'reason': pr['reason']
                })
        # Check commit statuses
        if result['status'] == 'Not Applied':
            not_applied.append({
                'commit_id': result['commit_id'],
                'commit_url': result['commit_url'],
                'reason': result['reason']
            })
        elif result['status'] == 'Error':
            errors.append({
                'commit_id': result['commit_id'],
                'commit_url': result['commit_url'],
                'reason': result['reason']
            })

    # Add succesfull PRs
    if successful_prs:
        seen_branches = set()
        successful_prs_section = ""
        for pr in successful_prs:
            if pr['branch_name'] not in seen_branches:
                successful_prs_section += (
                    f"<ul><li>Destination Branch: {pr['branch_name']}</li></ul>"
                    f"<ul><ul><li>Commit <a href='{pr['commit_url']}'>{pr['commit_id']}</a> &#8680; PR <a href='{pr['pr_url']}'>{pr['pr_url']}</a></li></ul></ul>"
                )
                seen_branches.add(pr['branch_name'])
    else:
        successful_prs_section = "<ul><li>None</li></ul>"
    
    # Add failed PRs
    if failed_prs:
        failed_prs_section = ""
        for pr in failed_prs:
            failed_prs_section += (
                f"<ul><li>Destination Branch: {pr['branch_name']}</li></ul>"
                f"<ul><ul><li>Commit <a href='{pr['commit_url']}'>{pr['commit_id']}</a> &#8680; Reason: {pr['reason']}</li></ul></ul>"
            )
    else:
        failed_prs_section = "<ul><li>None</li></ul>"
    
    # Add no change commits groupeed by desitination branch
    if no_changes_grouped:
        no_changes_grouped_section = ""
        for destination_branch, commits in no_changes_grouped.items():
            no_changes_grouped_section += f"<ul><li>Destination Branch: {destination_branch}</li></ul>"
            for commit in commits:
                no_changes_grouped_section += (
                    f"<ul><ul><li>Commit <a href='{commit['commit_url']}'>{commit['commit_id']}</a> &#8680; Reason: {commit['reason']}</li></ul></ul>"
                )
    else:
        no_changes_grouped_section = "<ul><li>None</li></ul>"
    
    # Add not processed commits
    if not_applied:
        not_applied_section = ""
        for na in not_applied:
            not_applied_section += (
                f"<ul><li>Commit <a href='{na['commit_url']}'>{na['commit_id']}</a> &#8680; Reason: {na['reason']}</li></ul>"
            )
    else:
        not_applied_section = "<ul><li>None</li></ul>"
    
    # Add commits with errors
    if errors:
        errors_section = ""
        for err in errors:
            errors_section += (
                f"<ul><li>Commit <a href='{err['commit_url']}'>{err['commit_id']}</a> &#8680; Error: {err['reason']}</li></ul>"
            )
    else:
        errors_section = "<ul><li>None</li></ul>"

    email_context = {    
        "successful_prs_section": successful_prs_section,    
        "failed_prs_section": failed_prs_section,    
        "no_changes_grouped_section": no_changes_grouped_section,    
        "not_applied_section": not_applied_section,  
        "errors_section": errors_section,
        "owner": owner,    
        "repo": repo,  
        "source_branch": source_branch
    }
    formatter.update_context(email_context)
    email_server = formatter.format("email_server")    
    email_port = formatter.format("email_port")    
    email_sender = formatter.format("email_sender") 
    email_body = formatter.format("email_body")
    email_subject = formatter.format("email_subject")   
    email_recipients = formatter.format("email_recipients")
    try:
        print("Sending email...")
        email = FunctionLibrary.send_email(      
            email_server,      
            email_port,      
            email_sender,      
            email_subject,      
            email_body,      
            email_recipients 
        )    
        print("Email sent")
    except Exception as e:
        print(f"WARNING: Failed to send email: {str(e)}")
        print(f"Workflow completed succesfully despite email sending failure.")
        sys.exit(0)
else: 
    print("No commits were processed, no email will be sent.")
print("Workflow completed succesfully.")
sys.exit(0)
#[END_PHASE]
