"""
AI Code Review Self-Enablement Package

This package provides tools for automatically enabling AI Code Review workflows
in GitHub repositories based on configuration.
"""

__version__ = "1.0.0"
__author__ = "AI Code Review Team"

from .self_enablement import SelfEnablementScript

__all__ = ["SelfEnablementScript"] 