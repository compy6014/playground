# Self-Enablement Script for AI Code Review

This script automates the process of enabling AI Code Review workflows in GitHub repositories. It fetches configuration from a GitHub repository, generates the appropriate workflow file, and creates a pull request to enable AI Code Review capabilities.

## Features

- **GitHub Configuration Fetching**: Mandatory fetching of configuration from GitHub repositories
- **Workflow Generation**: Creates GitHub Actions workflow files based on configuration
- **Branch-specific Configuration**: Supports different branch configurations per AI assistant
- **Complex Branch Logic**: Handles exclusion/inclusion logic for optimal workflow conditions
- **PR Creation**: Automatically creates pull requests with configurable metadata
- **Secret Management**: Optionally manages GitHub secrets required for AI Code Review

## Prerequisites

1. **Python 3.7+** with required dependencies
2. **GitHub Token** with appropriate permissions:
   - Repository access (read/write)
   - Actions secrets management (if using secret management)
   - Organization secrets management (if managing org-level secrets)
3. **Configuration File** hosted on GitHub

## Installation

```bash
pip install -r requirements.txt
```

## Dependencies

- `PyYAML>=6.0` - YAML configuration parsing
- `Jinja2>=3.0.0` - Workflow template rendering
- `requests>=2.25.0` - GitHub API interactions
- `PyNaCl>=1.5.0` - Secret encryption for GitHub secrets management

## Files Structure

- `self_enablement.py` - Main script for enabling AI Code Review
- `self_enablement_config.yaml` - Configuration template
- `email_system_config.yaml` - Email system configuration
- `workflow_templates/` - Jinja2 templates for workflow generation
  - `ai_code_review_workflow.yml.j2` - AI Code Review workflow template
  - `self_enablement_trigger.yml` - Advanced workflow template
- `WORKFLOW_USAGE.md` - Complete guide for using GitHub Actions workflows
- `README.md` - This documentation file

### Repository Level Files

- `.github/workflows/ai-code-review-self-enablement.yml` - Main centralized workflow file

## Usage

### Option 1: GitHub Actions Workflow (Recommended)

The easiest way to enable AI Code Review is through the **centralized GitHub Actions workflow**. This runs from the AI Code Review repository and creates a PR in your target repository.

**Quick Start:**
1. Create a configuration file in your repository
2. Navigate to the [AI Code Review repository](https://github.com/AMD-SW-Infra/AICodeReview)
3. Run the "AI Code Review Self-Enablement" workflow with your config file URL

📖 **See [WORKFLOW_USAGE.md](WORKFLOW_USAGE.md) for complete workflow setup instructions.**

### Option 2: Command Line

For advanced users or automation scenarios, you can run the script directly:

```bash
python self_enablement.py \
  --ghe_token YOUR_GITHUB_TOKEN \
  --config_file_url https://github.com/org/repo/blob/main/.github/self_enablement_config.yaml
```

### With Custom Workflow Filename

```bash
python self_enablement.py \
  --ghe_token YOUR_GITHUB_TOKEN \
  --config_file_url https://github.com/org/repo/blob/main/.github/self_enablement_config.yaml \
  --workflow_filename custom-ai-review.yml
```

### With Secret Management

```bash
python self_enablement.py \
  --ghe_token YOUR_GITHUB_TOKEN \
  --config_file_url https://github.com/org/repo/blob/main/.github/self_enablement_config.yaml \
  --gh_token_secret "ghp_your_github_token" \
  --api_token_secret "your_api_token" \
  --llm_token_secret "your_llm_token"
```

### Skip Secret Management

```bash
python self_enablement.py \
  --ghe_token YOUR_GITHUB_TOKEN \
  --config_file_url https://github.com/org/repo/blob/main/.github/self_enablement_config.yaml \
  --skip_secrets
```

## Command Line Parameters

### Required Parameters

- `--ghe_token`: GitHub token for API authentication
- `--config_file_url`: GitHub URL to the configuration file

### Optional Parameters

- `--workflow_filename`: Name of the workflow file to create (default: `ai-code-review-trigger.yml`)
- `--gh_token_secret`: GitHub token value for `AI_GH_TOKEN` secret
- `--api_token_secret`: API token value for AI Code Review services
- `--llm_token_secret`: LLM token value for AI model access
- `--skip_secrets`: Skip secret management entirely

### Email Notification Parameters

- `--disable_email`: Disable email notifications (overrides config file setting)
- `--email_recipient`: Additional email addresses for notifications (can be used multiple times)

## Configuration File Format

The configuration file must be hosted on GitHub and follow this format:

```yaml
ai_assistants:
  PRSummary:
    enable: true
    branches:
      - main
      - develop
  AICodeReview:
    enable: false
    branches:
      - main
      - release
  AIReviewCommentFix:
    enable: false
    branches:
      - main

github_secret_token_name: AI_REVIEW_COMMENT_FIX_APIKEY

# Optional: PR metadata configuration
pr_metadata:
  pr_title: "Enable AI Code Review"
  pr_description: |
    This PR adds the AI Code Review workflow.
    
    ## Changes
    - Added workflow file: `.github/workflows/{workflow_filename}`
    - Configured AI assistants: {enabled_assistants}
  branch_name: "ai-code-review-enable"
  commit_title: "Add AI Code Review workflow"
  commit_description: "Automated commit to enable AI Code Review"
  labels: []
  reviewers: []
  base_branch: "main"

# Optional: Email notification settings
email_notifications:
  enabled: true
  recipients:
    - "team-lead@company.com"
    - "developer@company.com" 
    - "admin@company.com"
```

## Secret Management

The script supports automated GitHub secrets management with the following approach:

### Secret Hierarchy

1. **Organization Level**: Attempts to create secrets at organization level first
2. **Repository Level**: Falls back to repository level if organization access fails

### Managed Secrets

- `AI_GH_TOKEN`: GitHub token for API access
- `AI_REVIEW_COMMENT_FIX_APIKEY`: API token for AI services (configurable name)
- `AI_LLM_TOKEN`: LLM token for AI model access

### Secret Management Behavior

- **Existence Check**: Verifies if secrets already exist before attempting creation
- **Encryption**: Uses GitHub's public key encryption for secure secret storage
- **Fallback Strategy**: Tries organization level first, then repository level
- **Optional**: Secret management can be skipped entirely with `--skip_secrets`

## Email Notifications

The script supports automatic email notifications for both successful enablement and error conditions.

### Email Configuration

Email notifications are configured in the user configuration file:

```yaml
email_notifications:
  enabled: true
  recipients:
    - "team-lead@company.com"
    - "developer@company.com" 
    - "admin@company.com"
  team_name: "AI Code Review Team"
  contact_info: "ai-support@company.com"
```

### Email Types

- **Success Notifications**: Sent when PR is created successfully with workflow details
- **Error Notifications**: Sent when enablement fails with error details and solutions  
- **Permission Notifications**: Sent when additional permissions are required

### Command Line Email Options

```bash
# Disable email notifications
python self_enablement.py --disable_email --ghe_token TOKEN --config_file_url URL

# Add additional recipients
python self_enablement.py --email_recipient "extra@company.com" --ghe_token TOKEN --config_file_url URL

# Multiple additional recipients  
python self_enablement.py \
  --email_recipient "user1@company.com" \
  --email_recipient "user2@company.com" \
  --ghe_token TOKEN \
  --config_file_url URL
```

### Email Features

- **HTML Templates**: Professional HTML email templates with company branding
- **Error Classification**: Different templates for different error types
- **Retry Logic**: Automatic retry for failed email delivery
- **Duplicate Removal**: Automatic deduplication of recipient lists
- **Admin Notifications**: Critical errors also notify admin team

## Workflow Generation

The script generates GitHub Actions workflows with the following features:

### Supported AI Assistants

- **PRSummary**: Generates pull request summaries
- **AICodeReview**: Performs automated code review
- **CodingStandard**: Checks coding standards
- **AIReviewCommentFix**: Responds to review comments

### Branch Configuration

- **Per-Assistant Branches**: Different branch sets per assistant
- **Smart Conditions**: Generates optimal inclusion/exclusion logic
- **Complex Logic**: Handles multiple branch configurations efficiently

### Workflow Features

- **Conditional Execution**: Jobs run only when appropriate conditions are met
- **Secret Integration**: Automatically uses configured secrets
- **Template-based**: Uses Jinja2 templates for flexible workflow generation

## GitHub Integration

### Repository Parsing

The script automatically parses GitHub URLs to extract:
- Repository host (github.com, github.amd.com, etc.)
- Organization/owner
- Repository name
- Branch name
- File path

### API Interactions

- **Configuration Fetching**: Retrieves config files from GitHub
- **Branch Management**: Creates new branches for PR workflow
- **File Operations**: Commits workflow files
- **PR Management**: Creates pull requests with metadata
- **Secret Management**: Manages organization and repository secrets

## Error Handling

The script includes comprehensive error handling for:
- GitHub API failures
- Configuration parsing errors
- Network connectivity issues
- Permission-related errors
- Secret management failures
- PR creation failures with automatic cleanup

### Automatic Cleanup

If PR creation fails after a branch has been created, the script will automatically:
1. **Delete the created branch** to avoid conflicts with future attempts
2. **Log detailed error information** to help diagnose the issue
3. **Provide clear guidance** on how to resolve the problem

This ensures that failed attempts don't leave behind orphaned branches that could interfere with subsequent runs.

### Directory Structure Handling

The script automatically handles repositories that don't have a `.github/workflows/` directory by:
1. **Creating the directory structure** if it doesn't exist
2. **Committing the workflow file** to the new directory
3. **Cleaning up temporary files** used for directory creation

### Non-Critical Operations

Some operations are treated as non-critical and won't cause the script to fail:
- **Adding labels to PR**: If this fails, the PR is still created successfully
- **Adding reviewers to PR**: If this fails, the PR is still created successfully
- **Cleanup operations**: If branch deletion fails, a warning is logged but the error is reported

This ensures that the core functionality (creating the workflow and PR) succeeds even if auxiliary features encounter issues.

## Examples

### Enterprise GitHub

```bash
python self_enablement.py \
  --ghe_token YOUR_ENTERPRISE_TOKEN \
  --config_file_url https://github.enterprise.com/org/repo/blob/main/.github/config.yaml
```

### Complex Branch Configuration

Configuration file with different branches per assistant:

```yaml
ai_assistants:
  PRSummary:
    enable: true
    branches:
      - main
      - develop
      - feature
  AICodeReview:
    enable: true
    branches:
      - main
      - develop
  AIReviewCommentFix:
    enable: true
    branches:
      - main
```

This generates optimized workflow conditions automatically.

### Corporate Environment with Secret Management

```bash
python self_enablement.py \
  --ghe_token ghp_your_github_token \
  --config_file_url https://github.enterprise.com/corp/project/blob/main/.github/ai_config.yaml \
  --workflow_filename corporate-ai-review.yml \
  --gh_token_secret "ghp_github_token_for_actions" \
  --api_token_secret "corp_api_token_12345" \
  --llm_token_secret "llm_access_token_67890"
```

### Team-Specific PR Metadata

Configuration with custom PR standards:

```yaml
ai_assistants:
  PRSummary:
    enable: true
    branches: [main, develop]

github_secret_token_name: TEAM_AI_TOKEN

pr_metadata:
  pr_title: "JIRA-123 - Enable AI Code Review Platform"
  pr_description: |
    ## Business Justification
    Implementing AI Code Review to improve code quality.
    
    ## Changes
    - Workflow file: `.github/workflows/{workflow_filename}`
    - Enabled assistants: {enabled_assistants}
    
    **JIRA**: JIRA-123
  branch_name: "feature/jira-123-ai-review"
  commit_title: "feat(JIRA-123): add AI Code Review workflow"
  labels: ["ai-tools", "jira-123"]
  reviewers: ["tech-lead"]
  base_branch: "develop"
```

## Troubleshooting

### Common Issues

1. **Permission Errors**: Ensure GitHub token has required permissions
2. **Secret Management Failures**: Check organization/repository access rights
3. **Configuration Not Found**: Verify GitHub URL and file existence
4. **Network Issues**: Check connectivity to GitHub API endpoints

### Secret Management Issues

1. **PyNaCl Import Error**: Install with `pip install PyNaCl>=1.5.0`
2. **Organization Permission Denied**: Script will fall back to repository level
3. **Encryption Failures**: Check GitHub API connectivity and token permissions

### Debug Information

The script provides detailed logging for:
- Configuration fetching progress
- Secret management operations
- GitHub API interactions
- PR creation status

## Security Considerations

### Token Security

- Use tokens with minimal required permissions
- Consider using organization-level secrets for better security
- Rotate tokens regularly according to security policies

### Secret Management

- Secrets are encrypted using GitHub's public key encryption
- Organization-level secrets provide better access control
- Repository-level secrets are used as fallback option

## Support

For issues and questions:
1. Check the error messages and logs
2. Verify GitHub token permissions
3. Confirm configuration file accessibility
4. Review GitHub API rate limits
5. Ensure PyNaCl is installed for secret management 