import os
import sys
import yaml
import json
import logging
import time
from pathlib import Path

# Add the project root to the path so we can import helpers
project_root = os.path.join(os.path.dirname(__file__), '..', '..')
sys.path.insert(0, project_root)

from helpers.github_helper import GitHubHelper
from helpers.utils import extract_pr_info, send_email
from jinja2 import Environment, FileSystemLoader, select_autoescape

# Update config and template paths
CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'self_enablement_config.yaml')
EMAIL_SYSTEM_CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'email_system_config.yaml')
WORKFLOW_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), 'ai-code-review-trigger-template.yml')
WORKFLOW_TEMPLATE_J2 = os.path.join(os.path.dirname(__file__), 'workflow_templates', 'ai_code_review_workflow.yml.j2')

class SelfEnablementScript:
    def __init__(self, ghe_token: str, config_file_url: str, workflow_filename: str = "ai-code-review-trigger.yml"):
        self.ghe_token = ghe_token
        self.config_file_url = config_file_url
        self.workflow_filename = workflow_filename
        
        # Initialize logger
        self.logger = self._initialize_logger()
        
        # Parse repo details from config file URL
        self.repo_details = self._parse_repo_from_config_url(config_file_url)
        self.workflow_file_path = f".github/workflows/{workflow_filename}"
        
        # Initialize GitHub helper
        self._init_github_helper()
        
        # Load configurations
        self.config = self._load_config()
        self.email_system_config = self._load_email_system_config()
        
        # Jinja2 env for workflow template rendering
        self.workflow_template_env = Environment(
            loader=FileSystemLoader(os.path.join(os.path.dirname(__file__), 'workflow_templates')),
            autoescape=select_autoescape(['j2'])
        )

    def _initialize_logger(self):
        """Initialize the Logger following the same pattern as AI assistants."""
        logger = logging.getLogger(self.__class__.__name__)
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
        handler.setFormatter(formatter)
        if not logger.handlers:
            logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        return logger

    def _load_config(self):
        """Load configuration from GitHub URL (mandatory)"""
        self.logger.info(f"Fetching configuration from GitHub: {self.config_file_url}")
        
        config_content = self._fetch_config_from_github()
        if not config_content:
            raise ValueError(f"Failed to fetch configuration from GitHub: {self.config_file_url}")
        
        self.logger.info("✅ Successfully loaded configuration from GitHub")
        return yaml.safe_load(config_content)

    def _fetch_config_from_github(self):
        """Fetch configuration file from GitHub using GitHubHelper (mandatory)"""
        # Parse the GitHub URL to extract branch and file path
        config_url_parts = self._parse_github_file_url(self.config_file_url)
        
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        branch = config_url_parts['branch'] 
        file_path = config_url_parts['file_path']
        
        self.logger.info(f"Fetching file: {file_path} from {owner}/{repo} (branch: {branch})")
        
        try:
            # Get the latest commit SHA for the branch to use as ref
            branch_sha = self.github_helper.get_latest_commit_sha(owner, repo, branch)
            self.logger.debug(f"Latest commit SHA for {branch}: {branch_sha}")
            
            # Fetch the file content
            config_content = self.github_helper.get_file_content(owner, repo, branch_sha, file_path)
            self.logger.debug(f"Successfully fetched config file ({len(config_content)} characters)")
            return config_content
            
        except Exception as e:
            self.logger.error(f"Failed to fetch file {file_path} from {owner}/{repo}:{branch}")
            self.logger.error(f"Error details: {e}")
            raise

    def _parse_github_file_url(self, github_url):
        """Parse GitHub web URL to extract branch and file path"""
        import re
        
        # Handle GitHub web URLs like: https://github.com/owner/repo/blob/branch/path/to/file
        web_pattern = r'https://([^/]+)/([^/]+)/([^/]+)/blob/([^/]+)/(.+)'
        match = re.match(web_pattern, github_url)
        
        if match:
            host, org, repo, branch, file_path = match.groups()
            return {
                'host': host,
                'org': org, 
                'repo': repo,
                'branch': branch,
                'file_path': file_path
            }
        
        raise ValueError(f'Invalid GitHub file URL format: {github_url}. Expected: https://github.com/org/repo/blob/branch/path/to/file')

    def _parse_repo_from_config_url(self, config_file_url):
        """
        Parse repository details from GitHub config file URL.
        Examples:
        - https://github.com/org/repo/blob/main/.github/config.yaml
        - https://github.amd.com/org/repo/blob/branch/config/settings.yml
        
        Returns:
        - repo_details: dict with org, repo, host, url
        """
        url_parts = self._parse_github_file_url(config_file_url)
        
        repo_details = {
            'org': url_parts['org'],
            'repo': url_parts['repo'],
            'host': url_parts['host'],
            'url': f"https://{url_parts['host']}/{url_parts['org']}/{url_parts['repo']}"
        }
        
        self.logger.info(f"Parsed repository: {repo_details['org']}/{repo_details['repo']} on {repo_details['host']}")
        return repo_details

    def _init_github_helper(self):
        # Use the correct API base for the host
        host = self.repo_details['host']
        if host == 'github.com':
            api_base = 'https://api.github.com'
        elif host == 'github.amd.com':
            api_base = 'https://github.amd.com/api/v3'
        else:
            # Default fallback for enterprise GitHub instances
            api_base = f'https://{host}/api/v3'
        
        self.github_helper = GitHubHelper(self.ghe_token, api_base_url=api_base)

    def _check_missing_secrets(self, secret_values: dict = None) -> list:
        """
        Check which required secrets are missing from organization/repository.
        Returns a list of missing secret names. Empty list means all secrets are available.
        """
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        
        # Define required secrets
        required_secrets = {
            'gh_token': self.config.get('github_secret_token_name', 'AI_GH_TOKEN'),
            'api_token': 'AI_REVIEW_COMMENT_FIX_APIKEY',
            'llm_token': 'AI_LLM_TOKEN'
        }
        
        self.logger.info(f"Checking required secrets for {owner}/{repo}")
        
        missing_secrets = []
        
        for secret_key, secret_name in required_secrets.items():
            # Check if secret is provided via command line
            if secret_values and secret_key in secret_values and secret_values[secret_key]:
                self.logger.debug(f"Secret {secret_name} provided via command line")
                continue
            
            # Check if secret exists in organization or repository
            if self.github_helper.secret_exists_in_org(owner, secret_name):
                self.logger.debug(f"Secret {secret_name} exists in organization {owner}")
                continue
            
            if self.github_helper.secret_exists_in_repo(owner, repo, secret_name):
                self.logger.debug(f"Secret {secret_name} exists in repository {owner}/{repo}")
                continue
            
            # Secret is missing
            missing_secrets.append(secret_name)
            self.logger.warning(f"Secret {secret_name} not found in organization or repository")
        
        if missing_secrets:
            self.logger.error("❌ Required secrets are missing for AI Code Review workflow:")
            for secret in missing_secrets:
                self.logger.error(f"  - {secret}")
            self.logger.error("")
            self.logger.error("To fix this issue, you can:")
            self.logger.error("1. Provide secret values via command line parameters:")
            self.logger.error("   --gh_token_secret 'your_github_token'")
            self.logger.error("   --api_token_secret 'your_api_token'")
            self.logger.error("   --llm_token_secret 'your_llm_token'")
            self.logger.error("2. Or manually add these secrets to your GitHub organization/repository")
            self.logger.error("3. Or use --skip_secrets if secrets are managed externally")
            
            # Send error email notification
            error_message = f"Missing required secrets: {', '.join(missing_secrets)}"
            context = self._prepare_email_context(error_message=error_message, error_type='secrets_missing')
            self._send_notification_email('error', context, 'secrets_missing')
        else:
            self.logger.info("✅ All required secrets are available")
        
        return missing_secrets

    def _validate_required_secrets(self, secret_values: dict = None) -> bool:
        """
        Validate that all required secrets exist or are provided.
        Returns True if all required secrets are available, False otherwise.
        This method is kept for backward compatibility.
        """
        missing_secrets = self._check_missing_secrets(secret_values)
        return len(missing_secrets) == 0

    def _get_default_branch(self):
        """
        Get the default branch for the repository using multiple fallback strategies:
        1. Check config file for base_branch in pr_metadata
        2. Extract from the config file URL if available
        3. Fetch from repository using GitHub API
        4. Fall back to 'main' as default
        
        Returns the determined default branch.
        """
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        
        # Strategy 1: Check config file for base_branch in pr_metadata
        default_pr_metadata = {'base_branch': 'main'}
        user_pr_metadata = self.config.get('pr_metadata', {})
        pr_metadata = {**default_pr_metadata, **user_pr_metadata}
        config_branch = pr_metadata.get('base_branch')
        
        if config_branch and config_branch != 'main':
            self.logger.info(f"Using default branch from config: {config_branch}")
            return config_branch
        
        # Strategy 2: Fetch from repository using GitHub API
        try:
            repo_default_branch = self.github_helper.get_repository_default_branch(owner, repo)
            if repo_default_branch:
                self.logger.info(f"Using repository default branch: {repo_default_branch}")
                return repo_default_branch
        except Exception as e:
            self.logger.warning(f"Could not fetch repository default branch: {e}")
            self.logger.info("Falling back to default branch 'main'")
        
        # Strategy 3: Fall back to 'main' as default
        self.logger.info("Using fallback default branch: main")
        return 'main'

    def generate_workflow_yaml(self):
        """
        Generate the workflow YAML using Jinja2 template and self_enablement_config.yaml.
        Only enabled assistants are included, branches are set per assistant, and the secret token name is replaced if provided.
        Supports complex branch configurations with exclusions and different branches per assistant.
        Only includes branches in pull_request trigger that are used by PR-based assistants.
        If no branches are specified for an assistant, uses the default repository branch.
        """
        assistants = self.config.get('ai_assistants', {})
        secret_token_name = self.config.get('github_secret_token_name', 'AI_GH_TOKEN')
        
        # Get default branch to use when no branches are specified
        default_branch = self._get_default_branch()
        self.logger.info(f"Using default branch: {default_branch}")
        
        # Collect enabled jobs and branches for PR-based assistants only
        selected_jobs = set()
        pr_based_branches = set()  # Only branches used by PR-based assistants
        all_branches = set()  # All branches (including comment-based)
        assistant_branches = {}  # Store branches per assistant
        
        for name, info in assistants.items():
            if info.get('enable', False):
                branches = info.get('branches', [])
                # If no branches specified, use the default branch
                if not branches:
                    branches = [default_branch]
                    self.logger.info(f"No branches specified for {name}, using default branch: {default_branch}")
                all_branches.update(branches)
                
                if name == 'PRSummary':
                    selected_jobs.add('ai_pr_summary')
                    assistant_branches['ai_pr_summary'] = branches
                    pr_based_branches.update(branches)  # Add to PR trigger branches
                elif name == 'AICodeReview':
                    selected_jobs.add('ai_code_review')
                    assistant_branches['ai_code_review'] = branches
                    pr_based_branches.update(branches)  # Add to PR trigger branches
                elif name == 'CodingStandard':  # Support both naming conventions
                    selected_jobs.add('ai_code_review')
                    assistant_branches['ai_code_review'] = branches
                    pr_based_branches.update(branches)  # Add to PR trigger branches
                elif name == 'AIReviewCommentFix':
                    selected_jobs.add('ai_comment_fix')
                    assistant_branches['ai_comment_fix'] = branches
                    # Don't add to pr_based_branches - this is comment-based only
        
        # Use PR-based branches for the main trigger, all branches for job conditions
        trigger_branches = sorted(pr_based_branches)
        all_branches = sorted(all_branches)
        
        # Generate branch conditions for each job
        job_branch_conditions = {}
        assistant_types = {}
        
        # Check if we need different branch conditions per job
        need_branch_conditions = False
        if len(selected_jobs) > 1:
            # Check if different assistants have different branches
            branch_sets = [set(assistant_branches.get(job, [])) for job in selected_jobs]
            if len(set(frozenset(bs) for bs in branch_sets)) > 1:
                need_branch_conditions = True
        
        if need_branch_conditions:
            for job in selected_jobs:
                job_branches = assistant_branches.get(job, [])
                if job_branches:
                    if job == 'ai_comment_fix':
                        # For comment review, always use contains() format for cleaner look
                        if len(job_branches) == 1:
                            job_branch_conditions[job] = f" &&\n      github.event.pull_request.base.ref == '{job_branches[0]}'"
                        else:
                            branches_json = ',\n        '.join([f'"{b}"' for b in sorted(job_branches)])
                            job_branch_conditions[job] = f" &&\n      contains(fromJson('[\n        {branches_json}\n      ]'), github.event.pull_request.base.ref)"
                    else:
                        # For PR-based jobs, check if we need exclusion or inclusion logic
                        job_branch_set = set(job_branches)
                        pr_branch_set = set(trigger_branches)  # Compare against PR trigger branches
                        
                        if job_branch_set == pr_branch_set:
                            # This job uses all PR trigger branches, no condition needed
                            continue
                        elif len(pr_branch_set - job_branch_set) < len(job_branch_set):
                            # More efficient to use exclusion (!contains)
                            excluded_branches = sorted(pr_branch_set - job_branch_set)
                            if len(excluded_branches) == 1:
                                job_branch_conditions[job] = f" &&\n      github.event.pull_request.base.ref != '{excluded_branches[0]}'"
                            else:
                                branches_json = '","'.join(excluded_branches)
                                job_branch_conditions[job] = f' &&\n      !contains(fromJson(\'["{branches_json}"]\'), github.event.pull_request.base.ref)'
                        else:
                            # More efficient to use inclusion (contains)
                            if len(job_branches) == 1:
                                job_branch_conditions[job] = f" &&\n      github.event.pull_request.base.ref == '{job_branches[0]}'"
                            else:
                                branches_json = '","'.join(sorted(job_branches))
                                job_branch_conditions[job] = f' &&\n      contains(fromJson(\'["{branches_json}"]\'), github.event.pull_request.base.ref)'
        
        # Set assistant types (support different naming)
        for name, info in assistants.items():
            if info.get('enable', False):
                if name == 'CodingStandard':
                    assistant_types['ai_code_review'] = 'CodingStandard'
                elif name == 'AICodeReview':
                    assistant_types['ai_code_review'] = 'AICodeReview'
        
        # Prepare workflow_parameters dict
        workflow_parameters = {
            'api_token': {'value': '${{ secrets.AI_REVIEW_COMMENT_FIX_APIKEY }}', 'type': 'secret'},
            'gh_token': {'value': f'${{{{ secrets.{secret_token_name} }}}}', 'type': 'secret'},
            'llm_token': {'value': '${{ secrets.AI_LLM_TOKEN }}', 'type': 'secret'},
            'branch_name': {'value': ','.join(trigger_branches), 'type': 'text'}
        }
        
        # Collect per-assistant parameters
        assistant_parameters = {}
        global_exclude_comment_authors = None
        
        for name, info in assistants.items():
            if info.get('enable', False):
                # Map assistant names to job keys
                job_key = None
                if name == 'PRSummary':
                    job_key = 'ai_pr_summary'
                elif name in ['AICodeReview', 'CodingStandard']:
                    job_key = 'ai_code_review'
                elif name == 'AIReviewCommentFix':
                    job_key = 'ai_comment_fix'
                
                if job_key:
                    assistant_parameters[job_key] = {}
                    
                    # Add filtered_ticket_ids if specified for this assistant
                    if 'filtered_ticket_ids' in info and info['filtered_ticket_ids'] is not None and info['filtered_ticket_ids'].strip():
                        assistant_parameters[job_key]['filtered_ticket_ids'] = info['filtered_ticket_ids']
                
                # Handle exclude_comment_authors specifically for AIReviewCommentFix
                if name == 'AIReviewCommentFix' and 'exclude_comment_authors' in info and info['exclude_comment_authors'] is not None:
                    exclude_comment_authors = info['exclude_comment_authors'].replace('\n', ' ').strip()
                    if exclude_comment_authors:
                        global_exclude_comment_authors = exclude_comment_authors
        
        # Add global exclude_comment_authors to workflow_parameters if it exists
        if global_exclude_comment_authors:
            workflow_parameters['exclude_comment_authors'] = {
                'value': global_exclude_comment_authors,
                'type': 'text'
            }
        
        # Render the Jinja2 template
        workflow_template = self.workflow_template_env.get_template('ai_code_review_workflow.yml.j2')
        workflow_yaml = workflow_template.render(
            branch_name=trigger_branches,  # Use only PR-based branches for trigger
            workflow_parameters=workflow_parameters,
            selected_jobs=selected_jobs,
            job_defs={},  # Not used in this template
            job_branch_conditions=job_branch_conditions,
            assistant_types=assistant_types,
            assistant_parameters=assistant_parameters,  # Per-assistant parameters
        )
        return workflow_yaml

    def add_github_secrets(self, secret_values: dict):
        """
        Add required GitHub secrets to the repository.
        Tries organization level first, falls back to repository level.
        Only adds secrets that are provided in secret_values.
        """
        if not secret_values:
            self.logger.info("No secret values provided, skipping secret management")
            return
        
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        
        # Define default secret names and their purposes
        default_secrets = {
            'gh_token': self.config.get('github_secret_token_name', 'AI_GH_TOKEN'),
            'api_token': 'AI_REVIEW_COMMENT_FIX_APIKEY',
            'llm_token': 'AI_LLM_TOKEN'
        }
        
        self.logger.info(f"Adding secrets to {owner}/{repo}")
        
        added_secrets = []
        failed_secrets = []
        
        for secret_key, secret_name in default_secrets.items():
            if secret_key in secret_values:
                secret_value = secret_values[secret_key]
                if secret_value:  # Only process if value is provided
                    self.logger.info(f"Adding secret: {secret_name}")
                    try:
                        success = self.github_helper.ensure_secret_exists(
                            owner, repo, secret_name, secret_value, try_org_first=True
                        )
                        if success:
                            self.logger.info(f"✅ Successfully added secret {secret_name}")
                            added_secrets.append(secret_name)
                        else:
                            self.logger.error(f"❌ Failed to add secret {secret_name}")
                            failed_secrets.append(secret_name)
                    except Exception as e:
                        self.logger.error(f"❌ Error adding secret {secret_name}: {e}")
                        failed_secrets.append(secret_name)
                else:
                    self.logger.info(f"No value provided for {secret_name}, skipping")
            else:
                self.logger.info(f"Secret {secret_name} not provided via command line, skipping")
        
        # Summary
        if added_secrets:
            self.logger.info(f"✅ Successfully added {len(added_secrets)} secrets: {', '.join(added_secrets)}")
        
        if failed_secrets:
            self.logger.error(f"❌ Failed to add {len(failed_secrets)} secrets: {', '.join(failed_secrets)}")
            self.logger.error("You may need to manually add these secrets or check your permissions")
        
        return len(failed_secrets) == 0  # Return True if all secrets were added successfully

    def create_pr_for_workflow(self, workflow_content: str):
        """
        Create a PR for the workflow file using GitHubHelper methods.
        Uses PR metadata from configuration with comprehensive defaults.
        1. Get latest commit SHA from base branch
        2. Create a new branch
        3. Commit the workflow file to the new branch
        4. Create a pull request with configured metadata
        
        If any step fails after branch creation, the branch will be cleaned up.
        """
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        new_branch = None  # Track branch for cleanup
        
        # Define comprehensive defaults for PR metadata
        default_pr_metadata = {
            'pr_title': 'Enable AI Code Review',
            'pr_description': '''This PR adds the AI Code Review workflow to enable automated code review capabilities.

## Changes
- Added workflow file: `.github/workflows/{workflow_filename}`
- Configured AI assistants: {enabled_assistants}

## Workflow Configuration
- **File**: `.github/workflows/{workflow_filename}`
- **Triggers**: Pull request events on configured branches
- **AI Assistants**: {enabled_assistants}

## Testing
- [ ] Verify workflow triggers correctly on pull requests
- [ ] Test AI assistant functionality
- [ ] Confirm secrets are properly configured

Please review and merge to enable AI Code Review for this repository.''',
            'branch_name': 'ai-code-review-enable',
            'commit_title': 'Add AI Code Review workflow',
            'commit_description': 'Automated commit to enable AI Code Review workflow\n\nThis commit adds the GitHub Actions workflow file to enable AI-powered code review capabilities including PR summaries, coding standard checks, and review comment assistance.',
            'labels': [],
            'reviewers': [],
            'base_branch': None  # Will be set to actual default branch
        }
        
        # Get PR metadata from config, falling back to defaults
        user_pr_metadata = self.config.get('pr_metadata', {})
        pr_metadata = {**default_pr_metadata, **user_pr_metadata}  # User config overrides defaults
        
        # Get the actual default branch and update base_branch if not explicitly set in config
        actual_default_branch = self._get_default_branch()
        if 'base_branch' not in user_pr_metadata:
            # Only override if user didn't explicitly set base_branch in config
            pr_metadata['base_branch'] = actual_default_branch
            self.logger.info(f"Updated base_branch to match repository default: {actual_default_branch}")
        
        # Extract values with defaults
        base_branch = pr_metadata.get('base_branch', actual_default_branch)
        new_branch = pr_metadata.get('branch_name', 'ai-code-review-enable')
        pr_title = pr_metadata.get('pr_title', 'Enable AI Code Review')
        commit_title = pr_metadata.get('commit_title', 'Add AI Code Review workflow')
        commit_description = pr_metadata.get('commit_description', 'Automated commit to enable AI Code Review')
        
        # Prepare PR description with template substitution
        pr_description_template = pr_metadata.get('pr_description', default_pr_metadata['pr_description'])
        
        # Get enabled assistants for description
        enabled_assistants = []
        assistants = self.config.get('ai_assistants', {})
        for name, info in assistants.items():
            if info.get('enable', False):
                enabled_assistants.append(name)
        
        # Format PR description
        pr_description = pr_description_template.format(
            workflow_filename=self.workflow_filename,
            enabled_assistants=', '.join(enabled_assistants) if enabled_assistants else 'None'
        )
        
        self.logger.info(f"Creating PR for {owner}/{repo}")
        self.logger.info(f"Repository URL: {self.repo_details['url']}")
        self.logger.info(f"Workflow file: {self.workflow_file_path}")
        self.logger.info(f"Base branch: {base_branch}")
        self.logger.info(f"New branch: {new_branch}")
        self.logger.info(f"PR Title: {pr_title}")
        if user_pr_metadata:
            self.logger.info("Using custom PR metadata from config")
        else:
            self.logger.info("Using default PR metadata")
        
        branch_created = False
        
        try:
            # Get latest commit SHA from base branch
            self.logger.info(f"Getting latest commit SHA from branch '{base_branch}'...")
            base_sha = self.github_helper.get_latest_commit_sha(owner, repo, base_branch)
            self.logger.debug(f"Base SHA: {base_sha}")
            
            # Create a new branch
            self.logger.info(f"Creating new branch '{new_branch}'...")
            self.github_helper.create_branch(owner, repo, base_sha, new_branch)
            branch_created = True
            self.logger.info(f"✅ Successfully created branch '{new_branch}'")
            
            # Commit the workflow file
            self.logger.info(f"Committing workflow file to branch '{new_branch}'...")
            commit_message = f"{commit_title}\n\n{commit_description}" if commit_description else commit_title
            
            try:
                self.github_helper.commit_file(owner, repo, new_branch, self.workflow_file_path, workflow_content, commit_message)
                self.logger.info(f"✅ Successfully committed workflow file")
            except Exception as commit_error:
                self.logger.error(f"Failed to commit workflow file: {commit_error}")
                # Check if it's a directory creation issue
                if "404" in str(commit_error) and ".github/workflows" in str(commit_error):
                    self.logger.info("Attempting to create .github/workflows directory structure...")
                    try:
                        # Create a placeholder file to ensure directory exists
                        placeholder_content = "# Placeholder file to create directory structure\n# This file will be removed after workflow creation\n"
                        self.github_helper.commit_file(owner, repo, new_branch, ".github/workflows/.gitkeep", placeholder_content, "Create .github/workflows directory")
                        self.logger.info("Created .github/workflows directory structure")
                        
                        # Now try to commit the actual workflow file
                        self.github_helper.commit_file(owner, repo, new_branch, self.workflow_file_path, workflow_content, commit_message)
                        self.logger.info(f"✅ Successfully committed workflow file after creating directory structure")
                        
                        # Remove the placeholder file
                        try:
                            placeholder_sha = self.github_helper.get_file_sha(owner, repo, new_branch, ".github/workflows/.gitkeep")
                            if placeholder_sha:
                                import requests
                                url = f"{self.github_helper.api_base_url}/repos/{owner}/{repo}/contents/.github/workflows/.gitkeep"
                                delete_data = {"message": "Remove placeholder file", "sha": placeholder_sha, "branch": new_branch}
                                response = requests.delete(url, json=delete_data, headers=self.github_helper._get_headers())
                                if response.status_code == 200:
                                    self.logger.debug("Removed placeholder file")
                        except:
                            self.logger.debug("Could not remove placeholder file (non-critical)")
                    except Exception as dir_error:
                        self.logger.error(f"Failed to create directory structure: {dir_error}")
                        raise commit_error
                else:
                    raise commit_error
            
            # Create PR
            self.logger.info("Creating pull request...")
            pr_url = self.github_helper.create_pull_request(owner, repo, base_branch, new_branch, pr_title, pr_description, isDraft=False)
            self.logger.info(f"✅ Successfully created PR: {pr_url}")
            
            # Add labels if configured (non-critical operation)
            labels = pr_metadata.get('labels', [])
            if labels:
                try:
                    self.logger.info(f"Adding labels: {labels}")
                    self.github_helper.add_labels_to_pr(pr_url, labels)
                    self.logger.info("✅ Successfully added labels to PR")
                except Exception as e:
                    self.logger.warning(f"Failed to add labels to PR: {e}")
                    self.logger.info("PR creation was successful, but labels could not be added")
            
            # Add reviewers if configured (non-critical operation)
            reviewers = pr_metadata.get('reviewers', [])
            if reviewers:
                try:
                    self.logger.info(f"Adding reviewers: {reviewers}")
                    self.github_helper.add_reviewers_to_pr(pr_url, reviewers)
                    self.logger.info("✅ Successfully added reviewers to PR")
                except Exception as e:
                    self.logger.warning(f"Failed to add reviewers to PR: {e}")
                    self.logger.info("PR creation was successful, but reviewers could not be added")
                    self.logger.info("You can manually add reviewers to the PR if needed")
            
            # Send success email notification
            context = self._prepare_email_context(pr_url=pr_url)
            self._send_notification_email('success', context)
            
            return pr_url
            
        except Exception as e:
            self.logger.error(f"Failed to create PR: {e}")
            
            # Determine error type for appropriate email template
            error_type = 'unknown_error'
            if '403' in str(e) or 'permission' in str(e).lower():
                error_type = 'permission_denied'
            elif '429' in str(e) or 'rate limit' in str(e).lower():
                error_type = 'api_rate_limit'
            elif 'network' in str(e).lower() or 'connection' in str(e).lower():
                error_type = 'network_error'
            
            # Send error email notification
            context = self._prepare_email_context(error_message=str(e), error_type=error_type)
            self._send_notification_email('error', context, error_type)
            
            # Cleanup: Delete the branch if it was created
            if branch_created and new_branch:
                try:
                    self.logger.info(f"Cleaning up: Deleting branch '{new_branch}'...")
                    self.github_helper.delete_branch(owner, repo, new_branch)
                    self.logger.info(f"✅ Successfully deleted branch '{new_branch}'")
                except Exception as cleanup_error:
                    self.logger.warning(f"Failed to cleanup branch '{new_branch}': {cleanup_error}")
                    self.logger.warning("You may need to manually delete this branch before trying again")
            
            raise

    def run(self, secret_values: dict = None):
        # 1. Check for missing secrets and attempt to add them
        missing_secrets = self._check_missing_secrets(secret_values)
        
        if missing_secrets:
            # 2. Attempt to add missing secrets if values are provided
            if secret_values:
                self.logger.info("Attempting to add missing secrets to organization/repository...")
                self.add_github_secrets(secret_values)
                
                # 3. Re-validate after attempting to add secrets
                still_missing = self._check_missing_secrets(secret_values)
                if still_missing:
                    self.logger.error("❌ Cannot proceed with PR creation due to missing secrets")
                    self.logger.error("Some secrets could not be added to the organization/repository")
                    self.logger.error("Please resolve the secret issues above and try again")
                    raise ValueError("Required secrets are missing. Cannot proceed with workflow creation.")
                else:
                    self.logger.info("✅ All required secrets are now available")
            else:
                # No secret values provided, cannot proceed
                self.logger.error("❌ Cannot proceed with PR creation due to missing secrets")
                self.logger.error("No secret values provided via command line parameters")
                self.logger.error("Please provide secret values or add them manually to the organization/repository")
                raise ValueError("Required secrets are missing. Cannot proceed with workflow creation.")
        
        # 4. Generate workflow YAML based on config
        self.logger.info("Generating workflow YAML...")
        workflow_content = self.generate_workflow_yaml()
        
        # 5. Create PR for workflow file
        self.logger.info("Creating pull request for workflow...")
        self.create_pr_for_workflow(workflow_content)

    def _load_email_system_config(self):
        """Load email system configuration for templates and settings."""
        try:
            with open(EMAIL_SYSTEM_CONFIG_PATH, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            self.logger.warning("Email system config file not found, email notifications will be disabled")
            return {}
        except Exception as e:
            self.logger.error(f"Failed to load email system config: {e}")
            return {}

    def _send_notification_email(self, notification_type: str, context: dict, error_type: str = None):
        """
        Send notification email based on type and context.
        
        Args:
            notification_type: 'success' or 'error'
            context: Dictionary with email template variables
            error_type: Specific error type for error notifications
        """
        # Check if email notifications are enabled
        email_config = self.config.get('email_notifications', {})
        email_server_config = self.email_system_config.get('email_server', {})
        notifications_config = self.email_system_config.get('notification_settings', {})
        
        if not email_config.get('enabled', False):
            self.logger.info("Email notifications are disabled in user configuration")
            return
        
        if not email_server_config:
            self.logger.warning("Email server configuration not found, skipping email notification")
            return
        
        # Determine recipients
        if notification_type == 'success':
            if not notifications_config.get('send_on_success', True):
                return
        else:  # error
            if not notifications_config.get('send_on_error', True):
                return
        
        # Get recipients from user config
        recipients = email_config.get('recipients', [])
        
        # Add default recipients for all notifications
        default_recipients = email_server_config.get('default_recipients', [])
        recipients.extend(default_recipients)
        
        # Add admin recipients for critical errors
        if notification_type == 'error' and error_type:
            error_handling = self.email_system_config.get('error_handling', {})
            error_info = error_handling.get('error_types', {}).get(error_type, {})
            if error_info.get('notify_admin', False) and notifications_config.get('send_admin_on_critical', True):
                admin_recipients = email_server_config.get('admin_recipients', [])
                recipients.extend(admin_recipients)
        
        # Remove duplicates while preserving order
        recipients = list(dict.fromkeys(recipients))
        
        if not recipients:
            self.logger.info(f"No recipients configured for {notification_type} notifications")
            return
        
        # Get email template
        template_name = 'success' if notification_type == 'success' else 'error'
        if error_type:
            error_handling = self.email_system_config.get('error_handling', {})
            error_info = error_handling.get('error_types', {}).get(error_type, {})
            template_name = error_info.get('template', 'error')
        
        email_templates = self.email_system_config.get('email_templates', {})
        template = email_templates.get(template_name, {})
        
        if not template:
            self.logger.error(f"Email template '{template_name}' not found")
            return
        
        # Prepare email content
        subject = template.get('subject', '').format(**context)
        body = template.get('body', '').format(**context)
        
        # Send email with retry logic
        smtp_server = email_server_config.get('smtp_server')
        smtp_port = email_server_config.get('smtp_port')
        from_email = email_server_config.get('from_email')
        
        retry_attempts = notifications_config.get('email_retry_attempts', 3)
        retry_delay = notifications_config.get('email_retry_delay', 5)
        
        for attempt in range(retry_attempts):
            try:
                success = send_email(
                    smtp_server=smtp_server,
                    smtp_port=smtp_port,
                    from_email=from_email,
                    subject=subject,
                    body=body,
                    to_email=recipients
                )
                
                if success:
                    self.logger.info(f"✅ {notification_type.title()} notification email sent to {len(recipients)} recipients")
                    return
                else:
                    raise Exception("Email sending failed")
                    
            except Exception as e:
                self.logger.warning(f"Email attempt {attempt + 1}/{retry_attempts} failed: {e}")
                if attempt < retry_attempts - 1:
                    time.sleep(retry_delay)
        
        self.logger.error(f"❌ Failed to send {notification_type} notification email after {retry_attempts} attempts")

    def _prepare_email_context(self, pr_url: str = None, error_message: str = None, error_type: str = None):
        """Prepare context variables for email templates."""
        owner = self.repo_details['org']
        repo = self.repo_details['repo']
        repo_name = f"{owner}/{repo}"
        repo_url = self.repo_details['url']
        
        # Get enabled assistants
        enabled_assistants = []
        assistants = self.config.get('ai_assistants', {})
        for name, info in assistants.items():
            if info.get('enable', False):
                enabled_assistants.append(name)
        
        # Prepare enabled assistants list for HTML
        enabled_assistants_list = '\n'.join([f'<li>{assistant}</li>' for assistant in enabled_assistants])
        
        context = {
            'repo_name': repo_name,
            'repo_url': repo_url,
            'workflow_filename': self.workflow_filename,
            'enabled_assistants': ', '.join(enabled_assistants) if enabled_assistants else 'None',
            'enabled_assistants_list': enabled_assistants_list,
            'api_secret_name': self.config.get('github_secret_token_name', 'AI_GH_TOKEN'),
        }
        
        # Add system default context
        default_context = self.email_system_config.get('default_context', {})
        context.update({
            'team_name': default_context.get('team_name', 'AI Code Review Team'),
            'contact_info': default_context.get('contact_info', 'dl.ai_code_review@amd.com'),
            'organization': default_context.get('organization', 'Organization'),
        })
        
        # Add PR-specific context if available
        if pr_url:
            pr_info = extract_pr_info(pr_url)
            context.update({
                'pr_url': pr_url,
                'pr_number': pr_info.get('pr_number', 'N/A'),
            })
        
        # Add error-specific context
        if error_message:
            context.update({
                'error_message': error_message,
                'error_type': error_type or 'Unknown Error',
            })
            
            # Add solutions list for error emails
            if error_type:
                error_handling = self.email_system_config.get('error_handling', {})
                error_info = error_handling.get('error_types', {}).get(error_type, {})
                solutions = error_info.get('solutions', [])
                solutions_list = '\n'.join([f'<li>{solution}</li>' for solution in solutions])
                context['solutions_list'] = f'<ul>\n{solutions_list}\n</ul>' if solutions else '<p>No specific solutions available.</p>'
            
            # Add permission-specific context for permission errors
            if error_type == 'permission_denied':
                context.update({
                    'required_action': 'Grant repository permissions',
                    'required_permissions_list': '''
                    <li>Repository admin access for the AI Code Review service account</li>
                    <li>GitHub Actions enabled for the repository</li>
                    <li>Required secrets configured in repository or organization</li>
                    '''
                })
        
        return context

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Self-enablement script for AI Code Review.')
    parser.add_argument('--ghe_token', required=True, help='GitHub token')
    parser.add_argument('--config_file_url', required=True, 
                       help='GitHub URL to the config file (e.g., https://github.com/org/repo/blob/main/.github/self_enablement_config.yaml)')
    parser.add_argument('--workflow_filename', default='ai-code-review-trigger.yml',
                       help='Name of the workflow file to create (default: ai-code-review-trigger.yml)')
    
    # Optional secret management parameters
    parser.add_argument('--gh_token_secret', 
                       help='GitHub token value for AI_GH_TOKEN secret (if not already configured)')
    parser.add_argument('--api_token_secret', 
                       help='API token value for AI Code Review services (if not already configured)')
    parser.add_argument('--llm_token_secret', 
                       help='LLM token value for AI model access (if not already configured)')
    parser.add_argument('--skip_secrets', action='store_true',
                       help='Skip secret management entirely')
    
    # Optional email notification parameters
    parser.add_argument('--disable_email', action='store_true',
                       help='Disable email notifications (overrides config file setting)')
    parser.add_argument('--email_recipient', action='append',
                       help='Additional email addresses for notifications (can be used multiple times)')
    
    args = parser.parse_args()
    
    # Prepare secret values if provided
    secret_values = {}
    if not args.skip_secrets:
        if args.gh_token_secret:
            secret_values['gh_token'] = args.gh_token_secret
        if args.api_token_secret:
            secret_values['api_token'] = args.api_token_secret
        if args.llm_token_secret:
            secret_values['llm_token'] = args.llm_token_secret
    
    script = SelfEnablementScript(args.ghe_token, args.config_file_url, args.workflow_filename)
    
    # Override email settings if command line parameters are provided
    if args.disable_email:
        script.config.setdefault('email_notifications', {})['enabled'] = False
    
    if args.email_recipient:
        script.config.setdefault('email_notifications', {}).setdefault('recipients', []).extend(args.email_recipient)
    
    script.run(secret_values)
