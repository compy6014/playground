# AI Code Review Self-Enablement via GitHub Actions

This guide shows you how to enable AI Code Review in your repository using the centralized GitHub Actions workflow from the AI Code Review repository.

## Quick Start

### How It Works

The AI Code Review Self-Enablement workflow runs **centrally from the AMD-SW-Infra/AICodeReview repository** and enables AI Code Review in your target repository by:

1. **Reading your configuration** from your repository's config file
2. **Generating the workflow** based on your settings
3. **Creating a pull request** in your repository with the AI Code Review workflow

### Prerequisites

Your target repository must have these secrets configured:

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `AI_GH_TOKEN` | GitHub token with repo permissions | ✅ Yes |
| `AI_REVIEW_COMMENT_FIX_APIKEY` | API token for AI services | ✅ Yes |
| `AI_LLM_TOKEN` | LLM token for AI model access | ✅ Yes |

### Step-by-Step Process

1. **Create your configuration file** in your repository (e.g., `.github/self_enablement_config.yaml`):

```yaml
ai_assistants:
  PRSummary:
    enable: true
    branches:
      - main
      - develop
  AICodeReview:
    enable: true
    branches:
      - main
      - release

github_secret_token_name: AI_GH_TOKEN

email_notifications:
  enabled: true
  recipients:
    - "team-lead@company.com"
    - "developer@company.com"
```

2. **Navigate to the AI Code Review repository**: Go to [AMD-SW-Infra/AICodeReview](https://github.com/AMD-SW-Infra/AICodeReview)

3. **Run the Self-Enablement workflow**:
   - Click on **Actions** tab
   - Select **"AI Code Review Self-Enablement"** workflow
   - Click **"Run workflow"**
   - Fill in the required parameters:
     - **Config file URL**: URL to your config file (e.g., `https://github.com/your-org/your-repo/blob/main/.github/self_enablement_config.yaml`)
     - **Workflow filename**: Name for the workflow file (default: `ai-code-review-trigger.yml`)
     - **Email settings**: Configure notifications as needed

4. **Monitor the workflow execution** in the Actions tab

5. **Check your repository** for the created pull request with the AI Code Review workflow

## Configuration Options

### Workflow Input Parameters

| Parameter | Description | Required | Default |
|-----------|-------------|----------|---------|
| `config_file_url` | GitHub URL to your repository's config file | ✅ Yes | - |
| `workflow_filename` | Name of the workflow file to create | No | `ai-code-review-trigger.yml` |
| `disable_email` | Disable email notifications | No | `false` |
| `email_recipient` | Additional email recipient | No | - |
| `skip_secrets` | Skip secret management (use existing secrets) | No | `true` |

### Example Configuration File URLs

```
# Public GitHub
https://github.com/your-org/your-repo/blob/main/.github/self_enablement_config.yaml

# GitHub Enterprise
https://github.amd.com/your-org/your-repo/blob/main/.github/ai_config.yaml

# Different branch
https://github.com/your-org/your-repo/blob/develop/config/ai_settings.yaml
```

## Usage Examples

### Basic Enablement

1. Go to [AMD-SW-Infra/AICodeReview Actions](https://github.com/AMD-SW-Infra/AICodeReview/actions)
2. Select "AI Code Review Self-Enablement"
3. Click "Run workflow"
4. Enter your config file URL: `https://github.com/your-org/your-repo/blob/main/.github/self_enablement_config.yaml`
5. Click "Run workflow"

### Custom Workflow Name

Same as above, but also specify:
- **Workflow filename**: `custom-ai-review.yml`

### With Additional Email Notifications

Same as above, but also specify:
- **Additional email recipient**: `extra-admin@company.com`

### Disable Email Notifications

Same as above, but check:
- **Disable email notifications**: `true`

## What Happens During Execution

### Workflow Steps

1. **Validation**: Validates input parameters and URL format
2. **Configuration Fetch**: Retrieves your config file from GitHub
3. **Workflow Generation**: Creates AI Code Review workflow based on your settings
4. **PR Creation**: Creates pull request in your repository
5. **Email Notification**: Sends success/error notifications (if enabled)
6. **Summary**: Provides execution summary with next steps

### Expected Outputs

#### Successful Run
- ✅ Pull request created in your repository
- ✅ Workflow file added to `.github/workflows/`
- ✅ Email notifications sent (if enabled)
- ✅ Summary with next steps provided

#### Pull Request Contents
The created PR will include:
- **Workflow File**: `.github/workflows/[your-filename].yml`
- **AI Assistant Configuration**: Based on your enabled assistants
- **Branch Configuration**: Optimized branch conditions
- **Secret Integration**: Uses your repository's existing secrets

## Troubleshooting

### Common Issues

1. **Invalid Config File URL**
   - Error: "Invalid config file URL format"
   - Solution: Ensure URL follows GitHub blob format: `https://github.com/org/repo/blob/branch/path/file.yaml`

2. **Config File Not Found**
   - Error: "Failed to fetch configuration"
   - Solution: Verify the config file exists and is accessible at the specified URL

3. **Missing Repository Secrets**
   - Error: "Required secrets are missing"
   - Solution: Add the required secrets to your target repository

4. **Permission Errors**
   - Error: "403 Forbidden"
   - Solution: Ensure the AI Code Review service has access to your repository

### URL Format Requirements

Your config file URL must follow this format:
```
https://[github-host]/[org]/[repo]/blob/[branch]/[path-to-file]
```

Examples:
- ✅ `https://github.com/myorg/myrepo/blob/main/.github/config.yaml`
- ✅ `https://github.amd.com/team/project/blob/develop/ai-config.yml`
- ❌ `https://github.com/myorg/myrepo/config.yaml` (missing blob/branch)
- ❌ `https://raw.githubusercontent.com/...` (raw URLs not supported)

### Getting Help

If you encounter issues:

1. **Check workflow logs** in the AMD-SW-Infra/AICodeReview Actions tab
2. **Review error messages** for specific guidance
3. **Verify your config file** is accessible and properly formatted
4. **Contact AI Code Review team** at `dl.ai_code_review@amd.com`

## Security Considerations

- **Centralized Execution**: The workflow runs from a trusted central repository
- **Token Usage**: Uses the AI Code Review service's tokens for API access
- **Repository Access**: Only accesses your repository to read config and create PRs
- **Secret Management**: Skips secret management by default (uses your existing secrets)

## Advanced Configuration

### Custom PR Metadata

You can customize the pull request created in your repository:

```yaml
# In your config file
pr_metadata:
  pr_title: "JIRA-123 - Enable AI Code Review"
  pr_description: |
    This PR enables AI Code Review for our team.
    
    ## Changes
    - Added workflow: `.github/workflows/{workflow_filename}`
    - Enabled assistants: {enabled_assistants}
  branch_name: "feature/enable-ai-review"
  commit_title: "feat: add AI Code Review workflow"
  labels: ["ai-tools", "automation"]
  reviewers: ["team-lead"]
  base_branch: "develop"
```

### Complex Branch Configurations

```yaml
# Different branches per assistant
ai_assistants:
  PRSummary:
    enable: true
    branches: [main, develop, feature]
  AICodeReview:
    enable: true
    branches: [main, develop]  # Only on stable branches
  AIReviewCommentFix:
    enable: true
    branches: [main, develop, feature, hotfix]
```

### Email Notifications

```yaml
email_notifications:
  enabled: true
  recipients:
    - "team1@company.com"
    - "team2@company.com"
    - "admin@company.com"
```

## Next Steps

After successful enablement:

1. **Review the PR**: Check the generated workflow file in your repository
2. **Test the configuration**: Verify the workflow matches your requirements
3. **Merge the PR**: Enable AI Code Review functionality
4. **Create a test PR**: Verify the AI Code Review workflow works
5. **Configure team access**: Ensure your team can access AI Code Review features
6. **Monitor usage**: Track AI Code Review effectiveness for your team

## Benefits of Centralized Approach

- **Consistency**: All teams use the same tested workflow
- **Security**: Centralized token management and access control
- **Maintenance**: Updates and improvements are automatically available
- **Support**: Easier troubleshooting and support for teams
- **Compliance**: Centralized logging and monitoring of enablement activities 