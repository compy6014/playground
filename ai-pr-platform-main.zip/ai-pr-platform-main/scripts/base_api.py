import requests  
import os  
import base64  
from urllib.parse import urlencode  
from utils.config_loader import ConfigLoader  
  
  
class BaseAPI:  
    def __init__(self, api_name, environment=None):  
        self.api_name = api_name  
        self.environment = environment  
        self.config = ConfigLoader.load_api_config(api_name)  
        self.session = requests.Session()  
        self.base_url = self._select_base_url()  
        self.verify_ssl = self.config.get("verify_ssl", False)  
  
    def _select_base_url(self):  
        """Select the correct base URL based on requested environment."""  
        base_url_config = self.config.get("base_url")  
  
        if isinstance(base_url_config, dict):  # If multiple environments exist  
            if self.environment in base_url_config:  
                return base_url_config[self.environment]  
            else:  
                raise ValueError(  
                    f"Environment '{self.environment}' not found for API '{self.api_name}'"  
                )  
  
        elif isinstance(base_url_config, str):  # Only one base URL is defined  
            return base_url_config  
  
        raise ValueError(f"Invalid base_url configuration for API '{self.api_name}'")  
  
    def _get_headers(self, header_type=None):    
        """Handle different authentication methods."""    
        auth_method = self.config.get("auth_method")    
        headers = {}    
    
        if auth_method == "bearer_token":    
            token = self._get_secret(self.config.get("token_from_secret"))    
            headers["Authorization"] = f"Bearer {token}"    
    
        elif auth_method == "basic_auth":    
            password = self._get_secret(self.config.get("password_from_secret"))    
            credentials = f"{self.config.get('username')}:{password}"    
            encoded = base64.b64encode(credentials.encode()).decode()    
            headers["Authorization"] = f"Basic {encoded}"    
    
        elif auth_method == "custom_header":  
            # Handle legacy single custom header format  
            if self.config.get("custom_header") and self.config.get("api_key_from_secret"):  
                api_key = self._get_secret(self.config.get("api_key_from_secret"))  
                headers[self.config.get("custom_header")] = api_key  
            
            # Handle new multiple custom headers format  
            custom_headers = self.config.get("custom_headers", {})  
            for header_name, header_value in custom_headers.items():  
                if isinstance(header_value, dict) and "from_env" in header_value:  
                    headers[header_name] = self._get_secret(header_value["from_env"])  
                else:  
                    headers[header_name] = header_value  
    
        # Apply additional headers if header_type is specified    
        if header_type:    
            custom_headers = self.config.get("headers", {}).get(header_type, {})    
            headers.update(custom_headers)    
    
        return headers           
  
    def _get_secret(self, secret_name):  
        """Retrieve secret from environment variables."""  
        secret_value = os.getenv(secret_name)  
  
        if not secret_value:  
            raise ValueError(f"Secret '{secret_name}' not defined in environment.")  
  
        return secret_value  
  
    def request(self, method, endpoint="", json=None, header_type=None):  
        """Send API request with retry and timeout handling."""  
        headers = self._get_headers(header_type)  
        url = f"{self.base_url}{endpoint}"  
  
        # Fix for custom header  
        if self.config.get("auth_method") == "custom_header" and json:  
            query_string = urlencode(json)  
            url = f"{url}?{query_string}"  
            json = None  
  
        retries = self.config.get("retries", 3)  
        timeout = self.config.get("timeout", 20)  
  
        for attempt in range(retries):  
            try:  
                response = self.session.request(  
                    method,  
                    url,  
                    json=json,  
                    headers=headers,  
                    timeout=timeout,  
                )  
                response.raise_for_status()  
                return response.json()  
            except requests.exceptions.RequestException as e:  
                if attempt == retries - 1:  
                    raise RuntimeError(f"API request failed: {e}")  
