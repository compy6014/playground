import json  
from utils.config_loader import ConfigLoader  
  
  
class Formatter:  
    def __init__(self, template_category, team_name=None, context=None):  
        """Initializes the formatter with specific team format template."""  
        self.template_category = template_category  
        self.team_name = team_name  
        self.context = context or {}  # Initialize context if not provided  
  
        all_templates = ConfigLoader.load_formatter_template(self.template_category)  
  
        # Load default templates  
        self.default_templates = all_templates.get("default", {})  
  
        # Load team-specific template (inline or external)  
        team_section = all_templates.get(self.team_name, {}) if self.team_name else {}  
  
        if isinstance(team_section, str) and team_section.strip().lower().startswith("external:"):  
            self.team_template = ConfigLoader.load_external_template(team_section, as_json=True)  
        elif isinstance(team_section, dict):  
            self.team_template = team_section  
        else:  
            self.team_template = {}  
  
    def update_context(self, new_context):  
        """Updates internal context with new values."""  
        self.context.update(new_context)  
  
    def format(self, template_name, additional_context=None):  
        """Formats template using team-oriented structure with support to external team templates."""  
        template = self.team_template.get(template_name, self.default_templates.get(template_name))  
  
        if template is None:  
            raise ValueError(  
                f"Template '{template_name}' not found for team '{self.team_name}' or in 'default'"  
            )  
  
        if isinstance(template, str) and template.strip().lower() == "skip":  
            return None  
  
        if isinstance(template, str) and template.strip().lower().startswith("external:"):  
            template = ConfigLoader.load_external_template(template)  
  
        if not isinstance(template, str):  
            return template  
  
        merged_context = {**self.context, **(additional_context or {})}  
        return template.format(**merged_context)  
