import os
import sys
import logging
import argparse

# Add the parent directory to sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.abspath(os.path.join(script_dir, '..'))
sys.path.insert(0, parent_dir)

from helpers.github_helper import GitHubHelper
from helpers.ai_comment_manager import AICommentManager

class TestClass:
    def __init__(self, ghe_token):
        # Set up logging
        logging.basicConfig(level=logging.DEBUG)
        self.logger = logging.getLogger('TestClass')

        self.comment_header = {
            'Authorization': f'token {ghe_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        self.gitHubHelper = GitHubHelper(ghe_token)
        self.comment_manager = AICommentManager()

        # Prepare test data
        self.owner = 'AMD-Radeon-Driver'
        self.repo = 'drivers'
        self.pr_number = '99786'
        self.commit_id = '8b14fea8c6ff0a5f249cb9448f3d611b43e9933b'

        # For testing, set the following to appropriate values
        self.review_suggestion_comment = "AI Review Comment Fix\n<details><summary>Click for details</summary>\n\n```suggestion\nconst CooperativeMatrixType* pType = nullptr;\nif (i < CooperativeMatrixTypesCount)\n{\n    pType = CooperativeMatrixTypes + i;\n}\nelse if (i < basicTypeCount)\n{\n    sat = true;\n    pType = CooperativeMatrixSaturatingTypes + i - CooperativeMatrixTypesCount;\n}\n#if VKI_KHR_BFLOAT16\nelse\n{\n    pType = CooperativeMatrixTypesBFloat + i - basicTypeCount;\n}\n#endif\npProperties[i].MSize = CooperativeMatrixDimension;\npProperties[i].NSize = CooperativeMatrixDimension;\npProperties[i].KSize = CooperativeMatrixDimension;\npProperties[i].AType = pType->a;\npProperties[i].BType = pType->b;\npProperties[i].CType = pType->c;\npProperties[i].ResultType = pType->c;\n```\n\n**Explanation:** Renamed the pointer variable 'type' to 'pType' to follow the naming convention where pointers have a 'p' prefix. Updated all references to 'type' in the code block accordingly.</details>"
        self.review_comment = {
            'commit_id': '8b14fea8c6ff0a5f249cb9448f3d611b43e9933b',
            'file_path': 'drivers/xgl/icd/api/vk_physical_device.cpp'
        }
        self.lines_to_post = [14044, 14044]
        self.side = 'RIGHT'

    def test_post_review_comment(self):
        # Create the comment body for the review comment
        self.position_review_comment = self.comment_manager.create_comment_body_for_position(
            self.review_suggestion_comment,
            self.review_comment['commit_id'],
            self.review_comment['file_path'],
            self.lines_to_post,
            self.side
        )
        self.reply_comment_data = {
            'position_review_comment': self.position_review_comment
        }

        self.logger.debug(f"Position review comment data: {self.reply_comment_data}")

        # Post the review comment
        try:
            response = self.gitHubHelper.post_commit_comment(
                self.owner,
                self.repo,
                self.commit_id,
                self.reply_comment_data['position_review_comment']
            )
            # Output the response
            print(f"Review comment posted successfully. Response URL: {response}")
        except Exception as e:
            self.logger.error(f"Failed to post review comment: {e}")

def main():
    parser = argparse.ArgumentParser(description='Run TestClass Script')
    parser.add_argument('--ghe_token', required=True, help='GitHub Enterprise token')
    args = parser.parse_args()

    test_class = TestClass(args.ghe_token)
    test_class.test_post_review_comment()

if __name__ == "__main__":
    main()
