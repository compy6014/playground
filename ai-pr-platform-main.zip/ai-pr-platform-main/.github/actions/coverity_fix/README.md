# Run Coverity Fix Action

This GitHub Action runs the Coverity Fix scripts with specified parameters.

## Inputs

| **Input Name**      | **Description**                                                                      | **Required** | **Default**                    |
|---------------------|--------------------------------------------------------------------------------------|--------------|--------------------------------|
| `coverity_token`    | Coverity token (used for authentication when accessing Coverity API)                 | **Yes**      | N/A                            |
| `ghe_token`         | GitHub token (used for authentication when accessing GitHub APIs)                    | **Yes**      | N/A                            |
| `json_path`         | Path to unfiltered JSON reports (if not using Artifactory)                           | **Yes**      | N/A                            |
| `pr_url`            | Pull Request URL                                                                     | **Yes**      | N/A                            |
| `run_json_filtering`| (Optional) Run JSON files filtering                                                  | **No**       | false                          |
| `post_summary`      | (Optional) Post Coverity Summary Report in PR                                        | **No**       | false                          |

## Usage

To use this action in your workflow, include it as a step:

```yaml
- name: Call Coverity Fix action
  uses: AMD-SW-Infra/ai-pr-platform/.github/actions/coverity_fix@main
  with:
    coverity_api_token: ${{ secrets.coverity_api_token }}
    ghe_token: ${{ secrets.ghe_token }}
    pr_url: ${{ github.event.pull_request.html_url }}
    json_path: ${{ path_to_json_files }}
    run_json_filtering: true
    post_summary: true
```

## Description

The **Coverity Fix Action** performs the following steps:

1. **Code Checkout**: The action checks out the specified repository and branch into the `AICodeReview` directory using `actions/checkout@v4.1.1`.

2. **Execute Coverity Filter Script**: Runs the `filter_cov_analysis_by_pr.py` script with the provided `json_path`. It will loop through every JSON file in provided path and filter out issues not relevent to PR.

3. **Execute Coverity Fix Script**: Runs the `pr_coverity_fix.py` script on filtered JSON files processed by `filter_cov_analysis_by_pr.py` script, creates comments with AI suggestions to found Coverity issues.


## Notes

- **Secret Management**: Ensure that `coverity_token` and `ghe_token` are stored securely as secrets in your GitHub repository settings.
- **Python Environment**: The runner must have Python installed and accessible via the `python` command.

## Troubleshooting

- **No JSON files**: Ensure that provided `json_path` contains JSON files for processing.
- **Authentication Errors**: If you receive authentication errors, confirm that the `coverity_token` and `ghe_token` are correct and have the necessary permissions.

---
